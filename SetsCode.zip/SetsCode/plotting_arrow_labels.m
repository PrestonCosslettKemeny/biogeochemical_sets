%% plotting_arrow_labels
% this script adds labels to the plotted arrows 

    % CLOSED SETS
    if   active_plot_number==101
           hp = patch([-3.10 -3.10 -1.05 -1.05]/3,0.04*[-1 1 1 -1],'w','edgecolor','none','facealpha',1);
                         
           spacer = 0.18; startpos = -0.07;
           text(-1.00,startpos+5*spacer,{'calcite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(-1.00,startpos+4*spacer,{'formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(-1.00,startpos+3*spacer,{'dolomite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(-1.00,startpos+2*spacer,{'formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(-1.00,startpos+1*spacer,{'siderite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);
           text(-1.00,startpos+0*spacer,{'formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);

           text(0.05,1.01-0*spacer,{'calcite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.05,1.01-1*spacer,{'metamorphism'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.05,1.01-2*spacer,{'dolomite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.05,1.01-3*spacer,{'metamorphism'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.05,1.01-4*spacer,{'siderite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);
           text(0.05,1.02-5*spacer,{'metamorphism'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);

           text(0.03,-0.12-0*spacer,{'Ca-silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.03,-0.12-1*spacer,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.03,-0.12-2*spacer,{'Ca/Mg-silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.03,-0.12-3*spacer,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.03,-0.12-4*spacer,{'Fe-silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);
           text(0.03,-0.12-5*spacer,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);


    elseif active_plot_number==102
           text(0.40,0.12,{'calcite','weathering'},'fontsize',fs_txt,'interpreter',interptype,'rotation',45,'color',col_3t_1v);
           text(+0.1,0.35,'dolomite','fontsize',fs_txt,'interpreter',interptype,'rotation',65,'color',col_3t_2v);
           text(+0.25,0.35,'weathering','fontsize',fs_txt,'interpreter',interptype,'rotation',60,'color',col_3t_2v);
           text(-0.18,0.10,{'siderite','weathering'},'fontsize',fs_txt,'interpreter',interptype,'rotation',90,'color',col_3t_3v);

           text(-0.95,-0.70,{'calcite','formation'},'fontsize',fs_txt,'interpreter',interptype,'rotation',45,'color',col_3t_1v);
           text(-0.54,-0.86,'dolomite','fontsize',fs_txt,'interpreter',interptype,'rotation',63,'color',col_3t_2v);
           text(-0.32,-0.9,'formation','fontsize',fs_txt,'interpreter',interptype,'rotation',67,'color',col_3t_2v);
           text(+0.2,-0.80,{'siderite','formation'},'fontsize',fs_txt,'interpreter',interptype,'rotation',90,'color',col_3t_3v);
                

    elseif active_plot_number==103
           text(0.34,1.30,{'Mg-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_1v);
           text(-1.30,1.35,{'Na-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_2v);
           text(-1.30,0.80,{'K-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_3v);
           text(-1.30,0.25,{'Fe-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_4v);

           text(-1.45,-1.3,{'Mg-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_1v);           
           text(0.15,-1.4,{'Na-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_2v);
           text(0.15,-0.85,{'K-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_3v);
           text(0.15,-0.3,{'Fe-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_4t_4v);
        

    elseif active_plot_number==104
           hp = patch(0.05*[-1 -1 1 1],[-0.98 -0.61 -0.61 -0.98],'w','edgecolor','none','facealpha',1);

           text(-1.05,-0.70,{'oxygenic photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v); 
           text(-0.87,-0.90,{'oxygenic photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           
           text(-0.76,0.91,{'aerobic','respiration'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(-1.05,-0.25,{'ferrous iron','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(0.12,0.5,{'ferric iron','reduction'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
                  

    elseif active_plot_number==105
           text(-2.0,-0.50,{'sulfide','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);

           text(+0.60,+1.95,{'sulfate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(+0.10,+1.65,{'reduction'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v); 

           text(+1.00,+0.69,{'sulfate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(+0.50,+0.37,{'reduction'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);            

           text(+0.55,-0.4,{'pyrite','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(-2.0,+0.80,{'pyrite','oxidation and','ferrous iron','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);

           text(0.12,-0.95,{'oxygenic'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(0.12,-1.30,{'photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);

           text(0.12,-1.65,{'oxygenic'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(0.12,-2.00,{'photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);           


    elseif active_plot_number==106
           text(0.10,0.6,{'  oxygenic','photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.15,1.6,{'$\rm{N_2}$ fixation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-2.1,-0.38,{'denitrification'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.52,-0.75,{'nitrification'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);


    elseif active_plot_number==107
           text(0.10,0.15,{' gypsum','dissolution'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(-0.8,0.15,{'gypsum','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(0.1,0.70,{' halite','dissolution'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(0.1,-0.70,{'halite','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);


    elseif active_plot_number==108
           text(0.35,-0.20,{'silica','dissolution'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(-1.05,0.35,{'silica','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);


    % EXCHANGE SETS
    elseif active_plot_number==201
           text(-1.7,-1.3,{'calcite','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.15,1.0,{'mantle $\rm{CO_2}$'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.32,-0.6,{'Ca-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           

    elseif active_plot_number==202
           text(-0.9,+0.8,{'mantle HCl'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.15,+0.22,{'Na-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-1.05,-0.22,{'halite','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);


    elseif active_plot_number==203
           text(0.1,+0.7,{'mantle $\rm{H_2S}$'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-0.95,+0.22,{'Fe-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(+0.37,-0.20,{'pyrite','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
        

    elseif active_plot_number==204
           text(0.05,+1.15,{'dolomite','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(-1.6,+0.45,{'Mg-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(0.6,+1.80,{'siderite','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(-2,+1.3,{'Fe-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           
           text(0.15,-0.3,{'Ca-silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(0.15,-0.7,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(0.45,-1.1,{'Ca-silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(0.45,-1.4,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);          
           
           text(-1.4,-0.90,{'calcite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(-1.4,-1.30,{'formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_2v);
           text(-2.0,-1.60,{'calcite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);
           text(-2.0,-2.00,{'formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_2t_1v);           


    elseif active_plot_number==205
           text(0.05,0.5,{'dolomite','and calcite','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.05,-0.35,{'oxygenic','photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-0.60,-0.15,{'Mg-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-0.75,+0.15,{'pyrite','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);     


    elseif active_plot_number==206
          hp = patch([-0.05  -0.05  0.05  0.05],[-0.25 -0.35 -0.35 -0.25],'w','edgecolor','none','facealpha',1);
           text(+0.22,-0.2,{'Fe-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(0.10,0.35,{'siderite','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-0.70,+0.15,{'ferrous iron','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);
           text(-0.65,-0.25,{'oxygenic','photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);


    % OPEN SETS
    elseif active_plot_number==301           
           
           spacer = 0.28;
           text(0.10,+1.62-0*spacer,{'oxygenic'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.10,+1.62-1*spacer,{'photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.10,+1.62-2*spacer,{'oxygenic'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.10,+1.62-3*spacer,{'photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.10,+1.62-4*spacer,{'oxygenic'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);
           text(0.10,+1.62-5*spacer,{'photosynthesis'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);           
           
           text(0.50,-0.2-0*spacer,{'siderite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.50,-0.2-1*spacer,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(0.30,-0.2-2*spacer,{'siderite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.30,-0.2-3*spacer,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(0.10,-0.2-4*spacer,{'dolomite'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);
           text(0.10,-0.2-5*spacer,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);

           text(-1.68,-1.2,{'ferrous iron','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_1v);
           text(-1.54,-0.6,{'Fe-reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_2v);
           text(-1.40,+0.7,{'Mg-reverse','weathering','and calcite','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_3t_3v);


    elseif active_plot_number==302                
           text(0.25,-0.6,{'Ca-silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype);
           text(-2.1,-0.40,{'pyrite','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',col_1t_1v);


    elseif active_plot_number==303
           text(0.2,1.4,{'  dolomite','weathering'},'fontsize',fs_txt,'interpreter',interptype);
           text(-1.9,-1.6,{'calcite','formation'},'fontsize',fs_txt,'interpreter',interptype);
           

    % CENOZOIC PANELS
    elseif active_plot_number==1001
           y0 = -0.4; yo = -0.45; 
           text(0.15,y0+0*yo,{'Urey set'},'fontsize',fs_txt,'interpreter',interptype,'color',c1);
           text(0.15,y0+1*yo,{'C$\rm_{org}$ set'},'fontsize',fs_txt,'interpreter',interptype,'color',c5);
           text(0.15,y0+2*yo,{'Carbonate set'},'fontsize',fs_txt,'interpreter',interptype,'color',c3);
           text(0.15,y0+3*yo,{'Reverse set'},'fontsize',fs_txt,'interpreter',interptype,'color',c2);
           text(0.15,y0+4*yo,{'Sulfur set'},'fontsize',fs_txt,'interpreter',interptype,'color',c4);        
        

    elseif active_plot_number==1002         
           text(-2.4,1.8,{'same silicate','fluxes as','initial case'},'fontsize',fs_txt,'interpreter',interptype,'color','k');
           text(0.1,+1.25,{'same','carbonate','metamorphism'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);
           text(-2.4,+0.5,{'same reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_reve);
           text(-2.2,-1.1,{'same','carbonate','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);            

           text(0.2,-0.4,{'same silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);
           text(0.2,-0.85,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);  
           text(0.4,-1.3,{'same silicate'},'fontsize',fs_txt,'interpreter',interptype,'color',c_reve);
           text(0.4,-1.75,{'weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_reve);             


    elseif active_plot_number==1003
           text(+0.3,+1.8,{'lower silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color','k');
           text(0.35,-0.8,{'reduced','silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_reve);
           text(-2.3,0.8,{'reduced','reverse','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_reve);


    elseif active_plot_number==1004
           text(-2.2,-1.8,{'enhanced','carbonate','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',c_carb);
           text(0.55,1.7,{'enhanced','carbonate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_carb);
           text(-2.3,+1.5,{'higher','carbonate','fluxes,','deeper CCD'},'fontsize',fs_txt,'interpreter',interptype,'color','k');
                   

    elseif active_plot_number==1008
           text(+0.2,+1.6,{'higher silicate','weathering,','higher $\rm{SO_{4}^{2-}}$,','lower $\rm{pO_{2}}$'},'fontsize',fs_txt,'interpreter',interptype,'color','k');         
           text(-2.1,0.5,{'enhanced','sulfide ox.'},         'fontsize',fs_txt,'interpreter',interptype,'color',c_sulf);
           text(0.35,-0.80,{'enhanced','silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);
          
           
   elseif active_plot_number==1009
           text(0.3,1.5,{'enhanced','organic C','oxidation'},'fontsize',fs_txt,'interpreter',interptype,'color',c_orgw);
           text(0.3,-1.95,{'enhanced','organic C','burial'},'fontsize',fs_txt,'interpreter',interptype,'color',c_orgw);
           text(0.3,-0.70,{'enhanced','silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey) ;
           text(-2.1,-1.85,{'enhanced','carbonate','formation'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);
           text(-2.45,+0.7,{'enhanced','calcite','metamorphism'},'fontsize',fs_txt,'interpreter',interptype,'color',c_Urey);
           text(-2.4,+2.0,{'higher silicate','weathering'},'fontsize',fs_txt,'interpreter',interptype,'color','k');         
    end    

    