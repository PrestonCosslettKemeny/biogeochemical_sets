%% calculate_results
% this script calculates some of the values referenced in the manuscript

l1 = length(var_list.closed); % 33 variables
l2 = length(process_list);    % 38 equations
% [l1 l2]

s1 = size(Aclosed);   % [33 x 38]
s2 = size(Aexchange); % [15 x 38]
s3 = size(Aopen);     % [02 x 38] 
% [s1; s2; s3]

r1 = rank(Aclosed);   % 20
r2 = rank(Aexchange); % 13
r3 = rank(Aopen);     % 02
% [r1; r2; r3]

r4 = rank(Aclosed_nullspace);   % 18, number of null sets
r5 = rank(Xclosed);             % 18, number of null sets
r6 = rank(Aexchange_nullspace); % 25, number of null sets + exchange sets
r7 = rank(Xexchange_isolated);  % 07, number of exchange sets
r8 = rank(Aopen_nullspace);     % 36, number of null sets + exchange sets + open sets
r9 = rank(Xopen_isolated);      % 11, number of open sets
% [r4; r5; r6; r7; r8; r9]

q1 = rank(Xclosed);   % 18
q2 = rank(Xexchange); % 25
q3 = rank(Xopen);     % 36
% [q1; q2; q3]

% the nullspace of Aopen  is 36 dimensions
Aopen_nullspace    = null(Aopen,'rational');
[~, sizeAopen]     = size(Aopen_nullspace);
rr = rank(Aopen); % 02
rs = sizeAopen;   % 36
% [rr, rs]

% null sets contain 2-5 biogeochemical processes
mm = [min(sum(Xclosed~=0,1)) max(sum(Xclosed~=0,1))]; % [2 5]

% number of processes in each closed set 
l01 = sum(x.closed.n01_Urey_Ca~=0);               % 4
l02 = sum(x.closed.n02_Urey_Mg~=0);               % 5
l03 = sum(x.closed.n03_Urey_Fe~=0);               % 4
l04 = sum(x.closed.n04_calcite_weath_form~=0);    % 2
l05 = sum(x.closed.n05_dolomite_weath_form~=0);   % 2
l06 = sum(x.closed.n06_siderite_weath_form~=0);   % 2
l07 = sum(x.closed.n07_Mg_slct_reverse_weath~=0); % 2
l08 = sum(x.closed.n08_Na_slct_reverse_weath~=0); % 2
l09 = sum(x.closed.n09_K_slct_reverse_weath~=0);  % 2
l10 = sum(x.closed.n10_Fe_slct_reverse_weath~=0); % 2
l11 = sum(x.closed.n11_photo_respir~=0);          % 2
l12 = sum(x.closed.n12_iron_cycle~=0);            % 3
l13 = sum(x.closed.n13_sulfur_cycle~=0);          % 3
l14 = sum(x.closed.n14_pyrite_weath_form~=0);     % 5
l15 = sum(x.closed.n15_nitrogen_cycle~=0);        % 4
l16 = sum(x.closed.n16_gypsum_form_weath~=0);     % 2
l17 = sum(x.closed.n17_halite_form_weath~=0);     % 2
l18 = sum(x.closed.n18_silica~=0);                % 2
% [l01 l02 l03 l04 l05 l06 l07 l08 l09 l10 l11 l12 l13 l14 l15 l16 l16 l18]
l19 = sum(x.exchange.ex19_degassing_Urey~=0);     % 4
l20 = sum(x.exchange.ex20_halite_build~=0);       % 4
l21 = sum(x.exchange.ex21_pyrite_mantle~=0);      % 4
l22 = sum(x.exchange.ex22_CaMg_switch~=0);        % 4
l23 = sum(x.exchange.ex23_CaFe_switch~=0);        % 4
l24 = sum(x.exchange.ex24_couple_CS~=0);          % 7
l25 = sum(x.exchange.ex25_couple_CFe~=0);         % 5
% [l19 l20 l21 l22 l23 l24 l25]
l26 = sum(x.open.op26_BK15_FeCO3_Fe2O3~=0);       % 3
l27 = sum(x.open.op27_sulfox~=0);                 % 2
l28 = sum(x.open.op28_catswitch~=0);              % 2
l29 = sum(x.open.op29_mantle_H2S~=0);             % 1
l30 = sum(x.open.op30_Ca_silicate~=0);            % 2
l31 = sum(x.open.op31_Na_silicate~=0);            % 2
l32 = sum(x.open.op32_K_silicate~=0);             % 2
l33 = sum(x.open.op33_Fe_silicate~=0);            % 2
l34 = sum(x.open.op34_Si_weathering~=0);          % 1
l35 = sum(x.open.op35_N2_fixation~=0);            % 2
l36 = sum(x.open.op36_nitrification~=0);          % 2
% [l26 l27 l28 l29 l30 l31 l32 l33 l34 l35 l36] 


closed_sets_2_process = closed_list(sum(Xclosed~=0,1)==2)';
    % {'04: calcite_form_weath'   } --> {'12: calcite_weathering'}      {'21: calcite_formation'}      % process_list(x.closed.n04_calcite_weath_form~=0)
    % {'05: dolomite_form_weath'  } --> {'13: dolomite_weathering'}     {'22: dolomite_formation'}     % process_list(x.closed.n05_dolomite_weath_form~=0)
    % {'06: siderite_form_weath'  } --> {'14: siderite_weathering'}     {'23: siderite_formation'}     % process_list(x.closed.n06_siderite_weath_form~=0)
    % {'07: Mg_slct_reverse_weath'} --> {'8: Mg_silicate_weathering'}   {'16: Mg_reverse_weathering'}  % process_list(x.closed.n07_Mg_slct_reverse_weath~=0)
    % {'08: Na_slct_reverse_weat' } --> {'9: Na_silicate_weathering'}   {'17: Na_reverse_weathering'}  % process_list(x.closed.n08_Na_slct_reverse_weath~=0)
    % {'09: K_slct_reverse_weath' } --> {'10: K_silicate_weathering'}   {'18: K_reverse_weathering'}   % process_list(x.closed.n09_K_slct_reverse_weath~=0)
    % {'10: Fe_slct_reverse_weath'} --> {'11: Fe_silicate_weathering'}  {'19: Fe_reverse_weathering'}  % process_list(x.closed.n10_Fe_slct_reverse_weath~=0)
    % {'11: photo_respir'         } --> {'24: oxygenic_photosynthesis'} {'25: aerobic_respiration'}    % process_list(x.closed.n11_photo_respir~=0)
    % {'16: gypsum_form_weath'    } --> {'32: gypsum_dissolution'}      {'33: gypsum_formation'}       % process_list(x.closed.n16_gypsum_form_weath~=0)
    % {'17: halite_form_weath'    } --> {'34: halite_dissolution'}      {'35: halite_formation'}       % process_list(x.closed.n17_halite_form_weath~=0)
    % {'18: silica_form_weath'    } --> {'15: silica_weathering'}       {'20: silica_formation'}       % process_list(x.closed.n18_silica~=0)
closed_sets_3_process = closed_list(sum(Xclosed~=0,1)==3)';
    % {'12: iron_cycle'  }          --> {'24: oxygenic_photosynthesis'} {'28: ferrous_iron_oxidation'}  {'29: ferric_iron_reduction'}   % process_list(x.closed.n12_iron_cycle~=0)
    % {'13: sulfur_cycle'}          --> {'24: oxygenic_photosynthesis'} {'26: sulfide_oxidation'}       {'27: sulfate_reduction'}       % process_list(x.closed.n13_sulfur_cycle~=0)
closed_sets_4_process = closed_list(sum(Xclosed~=0,1)==4)';
    % {'01: Urey_Ca'       }        --> {'4: calcite_metamorphism'}     {'7: Ca_silicate_weathering'}   {'20: silica_formation'}        {'21: calcite_formation'}  % process_list(x.closed.n01_Urey_Ca~=0)
    % {'03: Urey_Fe'       }        --> {'6: siderite_metamorphism'}    {'11: Fe_silicate_weathering'}  {'20: silica_formation'}        {'23: siderite_formation'} % process_list(x.closed.n03_Urey_Fe~=0)       
    % {'15: nitrogen_cycle'}        --> {'24: oxygenic_photosynthesis'} {'36: nitrogen_fixation'}       {'37: nitrification'}           {'38: denitrification'}    % process_list(x.closed.n15_nitrogen_cycle~=0)
closed_sets_5_process = closed_list(sum(Xclosed~=0,1)==5)';
    % {'02: Urey_Mg'              } --> {'5: dolomite_metamorphism'}    {'7: Ca_silicate_weathering'}   {'8: Mg_silicate_weathering'}   {'20: silica_formation'}    {'22: dolomite_formation'} % process_list(x.closed.n02_Urey_Mg~=0)
    % {'14: pyrite_form_oxidation'} --> {'24: oxygenic_photosynthesis'} {'27: sulfate_reduction'}       {'28: ferrous_iron_oxidation'}  {'30: pyrite_oxidation'}    {'31: pyrite_formation'}   % process_list(x.closed.n14_pyrite_weath_form~=0)
    

% Reactions and alpha values for Table 2 and supplement
reactions.n19_degassing_Urey;
%    {'17: CaCO3'       }    {[ 1]}
%    {'20: CaSiO3'      }    {[-1]}
%    {'25: SiO2 (solid)'}    {[ 1]}
%    {'31: mantle_CO2'  }    {[-1]}

reactions.n20_halite_build;
%    {'16: H2O'         }    {[ 1]}
%    {'22: Na2SiO3'     }    {[-1]}
%    {'25: SiO2 (solid)'}    {[ 1]}
%    {'30: NaCl'        }    {[ 2]}
%    {'32: mantle_HCl'  }    {[-2]}

reactions.n21_pyrite_mantle;
%    {'16: H2O'         }    {[ 2]}
%    {'24: FeSiO3'      }    {[ 1]}
%    {'25: SiO2 (solid)'}    {[-1]}
%    {'27: FeS2'        }    {[ 1]}
%    {'28: Fe2O3'       }    {[-1]}
%    {'33: mantle_H2S'  }    {[-2]}

reactions.n22_CaMg_switch;
%    {'17: CaCO3'   }    {[ 2]}
%    {'18: CaMgCO32'}    {[-1]}
%    {'20: CaSiO3'  }    {[-1]}
%    {'21: MgSiO3'  }    {[ 1]}

reactions.n23_CaFe_switch;
%    {'17: CaCO3' }    {[ 1]}
%    {'19: FeCO3' }    {[-1]}
%    {'20: CaSiO3'}    {[-1]}
%    {'24: FeSiO3'}    {[ 1]}

reactions.FeCaMg_sub;
%    {'17: CaCO3'   }    {[ 1]}
%    {'18: CaMgCO32'}    {[-1]}
%    {'19: FeCO3'   }    {[ 1]}
%    {'21: MgSiO3'  }    {[ 1]}
%    {'24: FeSiO3'  }    {[-1]}
[[1:ll_exchange]' alpha.exchange.FeCaMg_carb_slct_sub];
% alpha_6 = alpha_10 = alpha_22 = 1, alpha_23 = -1

reactions.n24_couple_CS;
%    {'16: H2O'         }    {[-31]}
%    {'17: CaCO3'       }    {[ -1]}
%    {'18: CaMgCO32'    }    {[ -7]}
%    {'21: MgSiO3'      }    {[  7]}
%    {'25: SiO2 (solid)'}    {[ -7]}
%    {'26: CH2O'        }    {[ 15]}
%    {'27: FeS2'        }    {[ -4]}
%    {'28: Fe2O3'       }    {[  2]}
%    {'29: CaSO4_2H2O'  }    {[  8]}

reactions.couple_CS_reverse;
%    {'16: H2O'         }    {[ 31]}
%    {'17: CaCO3'       }    {[  1]}
%    {'18: CaMgCO32'    }    {[  7]}
%    {'21: MgSiO3'      }    {[ -7]}
%    {'25: SiO2 (solid)'}    {[  7]}
%    {'26: CH2O'        }    {[-15]}
%    {'27: FeS2'        }    {[  4]}
%    {'28: Fe2O3'       }    {[ -2]}
%    {'29: CaSO4_2H2O'  }    {[ -8]}
[[1:ll_exchange]' alpha.exchange.couple_CS_reverse];
% alpha_4 = alpha_14 = 1, alpha_5 = alpha_7 = alpha_18 = 7, alpha_16 = 8, alpha_24 = -1

reactions.n25_couple_CFe;
%    {'16: H2O'         }    {[-1]}
%    {'19: FeCO3'       }    {[-1]}
%    {'24: FeSiO3'      }    {[-3]}
%    {'25: SiO2 (solid)'}    {[ 3]}
%    {'26: CH2O'        }    {[ 1]}
%    {'28: Fe2O3'       }    {[ 2]}

reactions.couple_CFe_reverse;
%    {'16: H2O'         }    {[ 1]}
%    {'19: FeCO3'       }    {[ 1]}
%    {'24: FeSiO3'      }    {[ 3]}
%    {'25: SiO2 (solid)'}    {[-3]}
%    {'26: CH2O'        }    {[-1]}
%    {'28: Fe2O3'       }    {[-2]}
[[1:ll_exchange]' alpha.exchange.couple_CFe_reverse];
% alpha_6 = alpha_12 = 1, alpha_10 = alpha_18 = 3, alpha_25 = -1

reactions.couple_CFe2;
%    {'16: H2O'         }    {[-1]}
%    {'17: CaCO3'       }    {[ 1]}
%    {'18: CaMgCO32'    }    {[-1]}
%    {'21: MgSiO3'      }    {[ 1]}
%    {'24: FeSiO3'      }    {[-4]}
%    {'25: SiO2 (solid)'}    {[ 3]}
%    {'26: CH2O'        }    {[ 1]}
%    {'28: Fe2O3'       }    {[ 2]}
[[1:ll_exchange]' alpha.exchange.couple_CFe2];
% alpha_10 = alpha_22 = alpha_25 = 1, alpha_23 = -1

reactions.couple_SFe;
%    {'16: H2O'         }    {[ -4]}
%    {'20: CaSiO3'      }    {[ -2]}
%    {'24: FeSiO3'      }    {[ 15]}
%    {'25: SiO2 (solid)'}    {[-13]}
%    {'27: FeS2'        }    {[ -1]}
%    {'28: Fe2O3'       }    {[ -7]}
%    {'29: CaSO4_2H2O'  }    {[  2]}
[[1:ll_exchange]' alpha.exchange.couple_SFe*4];
% alpha_4 = -1/4, alpha_10 = alpha_18 = 45/4, alpha_12 = alpha_23 = 15/4,
% alpha_22 = -7/4, alpha_24 = 1/4, alpha_25 = -15/4 

reactions.n26_BK15_FeCO3_Fe2O3;
%    {'9: O2'    }    {[ 3]}
%    {'16: H2O'  }    {[-4]}
%    {'19: FeCO3'}    {[-4]}
%    {'26: CH2O' }    {[ 4]}
%    {'28: Fe2O3'}    {[ 2]}

reactions.BK15_FeCO3_FeSiO3;
%    {'8: SiO2 (aq)'}    {[-1]}
%    {'9: O2'       }    {[ 1]}
%    {'16: H2O'     }    {[-1]}
%    {'19: FeCO3'   }    {[-1]}
%    {'24: FeSiO3'  }    {[ 1]}
%    {'26: CH2O'    }    {[ 1]}
[[1:ll_open]' alpha.open.BK15_FeCO3_FeSiO3*3];
% alpha_10 = alpha_18 = 1, alpha_25 = -1/3, alpha_26 = 1/3, alpha_34 = -1

reactions.BK15_CaMgCO3_MgSiO3;
%    {'8: SiO2 (aq)'}    {[-1]}
%    {'9: O2'       }    {[ 1]}
%    {'16: H2O'     }    {[-1]}
%    {'17: CaCO3'   }    {[ 1]}
%    {'18: CaMgCO32'}    {[-1]}
%    {'21: MgSiO3'  }    {[ 1]}
%    {'26: CH2O'    }    {[ 1]}
[[1:ll_open]' alpha.open.BK15_CaMgCO3_MgSiO3*3];
% alpha_10 = alpha_18 = alpha_22 = 1, alpha_23 = -1, alpha_25 = -1/3, alpha_26 = 1/3, alpha_34 = -1

reactions.n27_sulfox;
%    {'3: Ca'       }    {[  8]}
%    {'8: SiO2 (aq)'}    {[  8]}
%    {'9: O2'       }    {[-15]}
%    {'10: SO4'     }    {[  8]}
%    {'20: CaSiO3'  }    {[ -8]}
%    {'27: FeS2'    }    {[ -4]}
%    {'28: Fe2O3'   }    {[  2]}

reactions.n28_catswitch;
%    {'3: Ca'       }    {[-1]}
%    {'4: Mg'       }    {[ 1]}
%    {'17: CaCO3'   }    {[ 2]}
%    {'18: CaMgCO32'}    {[-1]}

reactions.n29_mantle_H2S;
%    {'11: H2S'       }    {[ 1]}
%    {'33: mantle_H2S'}    {[-1]}

reactions.n30_Ca_silicate;
%    {'3: Ca'         }    {[ 1]}
%    {'8: SiO2 (aq)'  }    {[ 1]}
%    {'12: Cl'        }    {[ 2]}
%    {'16: H2O'       }    {[ 1]}
%    {'20: CaSiO3'    }    {[-1]}
%    {'32: mantle_HCl'}    {[-2]}

reactions.n31_Na_silicate;
%    {'5: Na'         }    {[ 2]}
%    {'8: SiO2 (aq)'  }    {[ 1]}
%    {'12: Cl'        }    {[ 2]}
%    {'16: H2O'       }    {[ 1]}
%    {'22: Na2SiO3'   }    {[-1]}
%    {'32: mantle_HCl'}    {[-2]}

reactions.n32_K_silicate;
%    {'6: K'          }    {[ 2]}
%    {'8: SiO2 (aq)'  }    {[ 1]}
%    {'12: Cl'        }    {[ 2]}
%    {'16: H2O'       }    {[ 1]}
%    {'23: K2SiO3'    }    {[-1]}
%    {'32: mantle_HCl'}    {[-2]}

reactions.n33_Fe_silicate;
%    {'7: Fe2'        }    {[ 1]}
%    {'8: SiO2 (aq)'  }    {[ 1]}
%    {'12: Cl'        }    {[ 2]}
%    {'16: H2O'       }    {[ 1]}
%    {'24: FeSiO3'    }    {[-1]}
%    {'32: mantle_HCl'}    {[-2]}

reactions.n34_Si_weathering;
%    {'8: SiO2 (aq)'    }    {[ 1]}
%    {'25: SiO2 (solid)'}    {[-1]}

reactions.n35_N2_fixation;
%    {'9: O2'         }    {[ 3]}
%    {'12: Cl'        }    {[ 4]}
%    {'13: N2'        }    {[-2]}
%    {'14: NH4'       }    {[ 4]}
%    {'16: H2O'       }    {[-6]}
%    {'32: mantle_HCl'}    {[-4]}

reactions.n36_nitrification;
%    {'9: O2'  }    {[-1]}
%    {'13: N2' }    {[-2]}
%    {'14: NH4'}    {[ 2]}
%    {'15: NO3'}    {[ 2]}
%    {'16: H2O'}    {[-4]}


% consider how rank and nullity change when using net fluxes instead of gross fluxes
Aclosed_prime_CaCO3           = Aclosed(:,[1:20,22:38]); % remove process #21 (calcite formation), leaving matrix with dimensions 33x37
Aclosed_prime_NaCl            = Aclosed(:,[1:34,36:38]); % remove process #35 (halite formation), leaving matrix with dimensions 33x37
Aclosed_nullspace             = null(Aclosed);
Aclosed_prime_nullspace_CaCO3 = null(Aclosed_prime_CaCO3);
Aclosed_prime_nullspace_NaCl  = null(Aclosed_prime_NaCl);
list_rank    = [rank(Aclosed)           rank(Aclosed_prime_CaCO3)            rank(Aclosed_prime_NaCl)];           % [20 20 20]
list_nullity = [rank(Aclosed_nullspace) rank(Aclosed_prime_nullspace_CaCO3)  rank(Aclosed_prime_nullspace_NaCl)]; % [18 17 17]
% these examples demonstrate that using gross fluxes instead of net fluxes
% does not modify the rank of the A matricies but reduces nullity. 
