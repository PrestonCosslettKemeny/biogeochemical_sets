%% plotting_Cenozoic_vectors
% this script sets up the size and colors of arrows for Fig. 6

    % set up special arrows
    if    active_plot_number > 1000
    
          arrowtype  = {};
          lw_list    = [];  
          hl_list    = [];
          hw_list    = [];

          xvals_plot = NaN;
          yvals_plot = NaN;

          if     plotspecialontop == 0
                 lw_default = 2;  lw_special = 2.5;
                 hl_default = 7;  hl_special = 9;
                 hw_default = 7;  hw_special = 9;
          elseif plotspecialontop==1
                 lw_default = 2;  lw_special = 2;
                 hl_default = 9;  hl_special = 9;
                 hw_default = 9;  hw_special = 9;
          end                       
    
          % set the plotting colors
          col5t  = [0.84314     0.098039      0.1098;
                    0.99216      0.68235      0.38039;
                    0.67059      0.86667      0.64314;
                    0.16863      0.51373      0.72941]; % brewermap(4,'spectral');
          col11  = [0.61961    0.0039216      0.25882;
                    0.83529      0.24314       0.3098;
                    0.95686      0.42745      0.26275;
                    0.99216      0.68235      0.38039;
                    0.99608      0.87843       0.5451;
                          1            1      0.74902;
                    0.90196      0.96078      0.59608;
                    0.67059      0.86667      0.64314;
                        0.4      0.76078      0.64706;
                    0.19608      0.53333      0.74118;
                    0.36863       0.3098      0.63529]; % brewermap(11,'spectral');

          col5   = [col5t; col11(11,:)];
          col5   = col5/1.25;
          
          c_Urey = col5(1,:); % red
          c_reve = col5(2,:); % yellow
          c_carb = col5(3,:); % green
          c_sulf = col5(4,:); % blue
          c_orgw = col5(5,:); % purple

          if     active_plot_number == 1001                   
                 c1 = col5(1,:); % red
                 c2 = col5(2,:); % yellow
                 c3 = col5(3,:); % green
                 c4 = col5(4,:); % blue
                 c5 = col5(5,:); % purple
          elseif active_plot_number > 1001
                 greyscale = 0.85;
                 c1 = greyscale*[1 1 1]; % grey
                 c2 = greyscale*[1 1 1]; % grey
                 c3 = greyscale*[1 1 1]; % grey
                 c4 = greyscale*[1 1 1]; % grey
                 c5 = greyscale*[1 1 1]; % grey
          end
          count = 0;     
          specialist = [];

          % (1) the Urey closed set arrows
          % (1.1) metamorphism
          count = count+1;
          xvals_plot_end(1,count) = 0.0;
          yvals_plot_end(1,count) = 0.6;              
          colset(count,:)         = c1;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;
          specialist(count)       = 0; 
          if active_plot_number == 1002
             colset(count,:)   = c_Urey; 
             lw_list(count)    = lw_special;
             hl_list(count)    = hl_special;
             hw_list(count)    = hw_special;
             specialist(count) = 1;        
          end    
          if active_plot_number == 1009
                 colset(count,:)         = c_Urey;
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = 0.0;
                 yvals_plot_end(1,count) = 1.1;
          end
                        
    
          % (1.2) silicate weathering
          count = count+1;
          xvals_plot_end(1,count) = 1.2;
          yvals_plot_end(1,count) = 0.0;

          colset(count,:)         = c1;                 
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;      
          specialist(count)       = 0; 
          if     active_plot_number == 1002
                 colset(count,:)         = c_Urey;          
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;
                 specialist(count)       = 1;
          elseif active_plot_number ==1008
                 colset(count,:)         = c_Urey;
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = 2.2;
                 yvals_plot_end(1,count) = 0.0;
          elseif active_plot_number == 1009
                 colset(count,:)         = c_Urey;
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = 2.2;
                 yvals_plot_end(1,count) = 0.0;
          end
              
    
          % (1.3) carbonate formation
          count = count+1;
          xvals_plot_end(1,count) = -1.2; 
          yvals_plot_end(1,count) = -0.6;                   
          colset(count,:)  = c1;
          arrowtype{count} = '-';
          lw_list(count)   = lw_default;
          hl_list(count)   = hl_default;
          hw_list(count)   = hw_default;
          specialist(count)= 0; 
          if     active_plot_number == 1002
                 colset(count,:)         = c_Urey; 
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;  
                 specialist(count)       = 1;
                            
          elseif active_plot_number == 1009
                 colset(count,:)         = c_Urey;
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = -2.2;
                 yvals_plot_end(1,count) = -1.1;                              
          end                            
    

          % (2) carbonate weathering and formation
          % (2.1) carbonate weathering
          count = count+1;
          xvals_plot_end(1,count) = 0.8;  
          yvals_plot_end(1,count) = 0.4;
          colset(count,:)         = c3;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;  
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;     
          specialist(count)       = 0; 
          if active_plot_number==1004
             colset(count,:)         = c_carb; 
             lw_list(count)          = lw_special;
             hl_list(count)          = hl_special;
             hw_list(count)          = hw_special;   
             specialist(count)       = 1;
             xvals_plot_end(1,count) = 2.00;
             yvals_plot_end(1,count) = 1.00;                   
          end
    
          % (2.2) carbonate formation
          count = count+1;   
          xvals_plot_end(1,count) = -0.8; 
          yvals_plot_end(1,count) = -0.4;              
          colset(count,:)         = c3;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;    
          specialist(count)       = 0; 
          if active_plot_number==1004
             colset(count,:)         = c_carb; 
             lw_list(count)          = lw_special;
             hl_list(count)          = hl_special;
             hw_list(count)          = hw_special; 
             specialist(count)       = 1;
             xvals_plot_end(1,count) = -2.00; 
             yvals_plot_end(1,count) = -1.00;                  
          end                
        
          % (3) the S cycle
          % (3.1) photosynthesis
          count = count+1;
          xvals_plot_end(1,count) =  0.0; 
          yvals_plot_end(1,count) = -0.8;              
          colset(count,:)         = c4;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;    
          specialist(count)       = 0; 
            
    
          % (3.2) sulfate reduction
          count = count+1;
          xvals_plot_end(1,count) = 0.8; 
          yvals_plot_end(1,count) = 0.8;              
          colset(count,:)         = c4;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;  
          specialist(count)       = 0; 
                     
    
          % (3.3) sulfide oxidation
          count = count+1;
          xvals_plot_end(1,count) = -0.8;
          yvals_plot_end(1,count) =  0.0;              
          colset(count,:)         = c4;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default; 
          specialist(count)       = 0;       
          if active_plot_number==1008 
             colset(count,:)         = c_sulf; 
             lw_list(count)          = lw_special;
             hl_list(count)          = hl_special;
             hw_list(count)          = hw_special;    
             specialist(count)       = 1;
             xvals_plot_end(1,count) = -1.8;
             yvals_plot_end(1,count) =  0.0;                 
          end             
              
    
          % (4) reverse weathering
          % (4.1) silicate weathering
          count = count+1;
          xvals_plot_end(1,count) = 1.55; 
          yvals_plot_end(1,count) = 0.0;              
          colset(count,:)         = c2;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;              
          specialist(count)       = 0; 
          if     active_plot_number == 1002
                 colset(count,:)         = c_reve; 
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;  
                 specialist(count)       = 1;                 
          elseif active_plot_number==1003
                 colset(count,:)         = c_reve; 
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special; 
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = 0.65;
                 yvals_plot_end(1,count) = 0.0;                     
          end               
              
          % (4.2) reverse weathering
          count = count+1;
          xvals_plot_end(1,count) = -1.55; 
          yvals_plot_end(1,count) =  0.0;              
          colset(count,:)         = c2;
          arrowtype{count}        = '-'; 
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;   
          specialist(count)       = 0; 
          if     active_plot_number == 1002
                 colset(count,:)        = c_reve;
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;
                 specialist(count)       = 1;
          elseif active_plot_number==1003
                 colset(count,:)         = c_reve; 
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special; 
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = -0.65; 
                 yvals_plot_end(1,count) =  0.0;                             
          end     
    
          % (5) Corg oxidation and reduction
          % (5.1) respiration
          count = count+1;
          xvals_plot_end(1,count) = 0.0; 
          yvals_plot_end(1,count) = 1.25;              
          colset(count,:)         = c5;
          arrowtype{count}        = '-';
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;
          specialist(count)       = 0; 
          
          if active_plot_number == 1009
                 colset(count,:)         = c_orgw; 
                 lw_list(count)          = lw_special;
                 hl_list(count)          = hl_special;
                 hw_list(count)          = hw_special;  
                 specialist(count)       = 1;
                 xvals_plot_end(1,count) = 0.00; 
                 yvals_plot_end(1,count) = 1.75;                         
          end                  
    
          % (5.2) photosynthesis
          count = count+1;
          xvals_plot_end(1,count) =  0.00; 
          yvals_plot_end(1,count) = -1.25;              
          colset(count,:)         = c5;
          arrowtype{count}        = '-'; 
          lw_list(count)          = lw_default;
          hl_list(count)          = hl_default;
          hw_list(count)          = hw_default;  
          specialist(count)       = 0;

          if active_plot_number==1009
             colset(count,:)         = c_orgw; 
             lw_list(count)          = lw_special;
             hl_list(count)          = hl_special;
             hw_list(count)          = hw_special;
             specialist(count)       = 1;
             xvals_plot_end(1,count) =  0.0; 
             yvals_plot_end(1,count) = -1.75;                 
          end
   
    else
        xvals_plot_end   = xvals_plot; 
        yvals_plot_end   = yvals_plot; 
    end