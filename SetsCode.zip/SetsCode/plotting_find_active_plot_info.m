%% plotting_find_active_plot_info
% this script identifies the current plotting request and information
% regarding which chemical species to plot and with which colors

    % CLOSED SETS
    % urey sets
    if      active_plot_number==101      
            number_sets = 3;
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1.50/3; col1 = col_3t_1v;            
            name2 = 'closed.n02_Urey_Mg'; scale2 = 0.65/3; col2 = col_3t_2v;            
            name3 = 'closed.n03_Urey_Fe'; scale3 = 0.45/3; col3 = col_3t_3v;
            xvar  = 'ALK'; 
            yvar  = 'FIC'; 
            tit   = '\bf{A}\rm: Urey sets: \overrightarrow{\it{x\:}}$\!_{1}$, \overrightarrow{\it{x\:}}$\!_{2}$, \overrightarrow{\it{x\:}}$\!_{3}$';              
            xlab  = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];    
            pname = 'null_n1_n2_n3_Urey_DIC_ALK';

    % carbonate sets
    elseif  active_plot_number==102      
            number_sets    = 3;
            name1 = 'closed.n04_calcite_weath_form';  scale1 = 1;   col1 = col_3t_1v;
            name2 = 'closed.n05_dolomite_weath_form'; scale2 = 1/2; col2 = col_3t_2v;
            name3 = 'closed.n06_siderite_weath_form'; scale3 = 1;   col3 = col_3t_3v;         
            xvar = 'Ca'; 
            yvar = 'FIC'; 
            tit = '\bf{B}\rm: Carbonate sets: \overrightarrow{\it{x\:}}$\!_{4}$, \overrightarrow{\it{x\:}}$\!_{5}$, \overrightarrow{\it{x\:}}$\!_{6}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(Ca$^{2+}$) $\longrightarrow$ +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];              
            pname = 'null_n4_n5_n6_carbonates_DIC_Ca';

    % reverse weathering sets
    elseif  active_plot_number==103
            number_sets = 4;
            name1 = 'closed.n07_Mg_slct_reverse_weath'; scale1 = 1.0; col1 = col_4t_1v;
            name2 = 'closed.n08_Na_slct_reverse_weath'; scale2 = 1.5; col2 = col_4t_2v;
            name3 = 'closed.n09_K_slct_reverse_weath';  scale3 = 1.0; col3 = col_4t_3v;                    
            name4 = 'closed.n10_Fe_slct_reverse_weath'; scale4 = 0.5; col4 = col_4t_4v;                     
            xvar = 'Mg'; 
            yvar = 'SiO2 (aq)'; 
            tit = '\bf{C}\rm: Silicate sets: \overrightarrow{\it{x\:}}$\!_{7}$, \overrightarrow{\it{x\:}}$\!_{8}$, \overrightarrow{\it{x\:}}$\!_{9}$, \overrightarrow{\it{x\:}}$\!_{10}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(Mg$^{2+}$) $\longrightarrow$ +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(SiO$_2$ (aq)) $\longrightarrow$  +'];                          
            pname = 'null_n7_n8_n9_n10_reverse_sets_SiO2_Mg';

    % organic carbon and iron sets
    elseif  active_plot_number==104
            number_sets = 2;
            name1 = 'closed.n11_photo_respir'; scale1 = 1.0; col1 = col_2t_1v;
            name2 = 'closed.n12_iron_cycle';   scale2 = 0.6; col2 = col_2t_2v;
            xvar = 'O2';
            yvar = 'FIC'; 
            tit = '\bf{D}\rm: Organic, iron sets: \overrightarrow{\it{x\:}}$\!_{11}$, \overrightarrow{\it{x\:}}$\!_{12}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(O$_{2}$) $\longrightarrow$ +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];
            pname = 'null_n11_n12_photo_Fe_DIC_O2';
   
    % sulfur and pyrite sets
    elseif  active_plot_number==105
            number_sets  = 2;
            name1 = 'closed.n13_sulfur_cycle';      scale1 = 1;    col1 = col_2t_1v;            
            name2 = 'closed.n14_pyrite_weath_form'; scale2 = 1/14; col2 = col_2t_2v;    
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{E}\rm: Sulfur sets: \overrightarrow{\it{x\:}}$\!_{13}$, \overrightarrow{\it{x\:}}$\!_{14}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];
            pname = 'null_n13_14_sulfur_pyrite_cycles_ALK_DIC';        

    % nitrogen set
    elseif  active_plot_number==106
            name1 = 'closed.n15_nitrogen_cycle'; scale1 = 1/4; col1 = col_1t_1v;
            number_sets   = 1;
            xvar = 'NO3'; 
            yvar = 'O2';  
            tit = '\bf{F}\rm: Nitrogen set: \overrightarrow{\it{x\:}}$\!_{15}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(NO$_3^-$) $\longrightarrow$ +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(O$_2$) $\longrightarrow$  +'];
            pname = 'null_n15_nitrogen_cycle_O2_NO3';   

    % evaporite set
    elseif  active_plot_number==107
            number_sets   = 2;
            name1 = 'closed.n16_gypsum_form_weath'; scale1 = 1.0; col1 = col_2t_1v;
            name2 = 'closed.n17_halite_form_weath'; scale2 = 1.0; col2 = col_2t_2v;            
            xvar = 'SO4'; 
            yvar = 'Cl';              
            tit = '\bf{G}\rm: Evaporite sets: \overrightarrow{\it{x\:}}$\!_{16}$, \overrightarrow{\it{x\:}}$\!_{17}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(SO$_4^{2-}$) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(Cl$^{-}$) $\longrightarrow$ +'];            
            pname = 'null_n16_n17_salt_Cl_SO4';     

    % silica set
    elseif  active_plot_number==108
            number_sets   = 1;
            name1 = 'closed.n18_silica'; scale1 = 1.0; col1 = col_1t_1v;
            xvar = 'SiO2 (aq)'; 
            yvar = 'SiO2 (solid)';              
            tit = '\bf{H}\rm: Silica set: \overrightarrow{\it{x\:}}$\!_{18}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(SiO$_{2}$ (aq)) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(SiO$_{2}$ (solid)) $\longrightarrow$ +'];            
            pname = 'null_n18_silica_Si_Si';           


    % EXCHANGE SETS
    % mantle Urey set
    elseif  active_plot_number==201
            number_sets = 1;
            name1 = 'exchange.ex19_degassing_Urey'; scale1 = 1; col1 = col_1t_1v;
            xvar  = 'ALK'; 
            yvar  = 'FIC'; 
            tit   = '\bf{A}\rm: Mantle Urey set: \overrightarrow{\it{x\:}}$\!_{19}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];    
            pname = 'exchange_19_degassing_urey_DIC_ALK';

    % halite formation set
    elseif  active_plot_number==202
            number_sets = 1;
            name1 = 'exchange.ex20_halite_build'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'Na'; 
            yvar = 'Cl'; 
            tit  = '\bf{B}\rm: Halite formation set: \overrightarrow{\it{x\:}}$\!_{20}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(Na$^{+}$) $\longrightarrow$  +'];      
            ylab = ['- $\longleftarrow$ \(\Delta \)(Cl$^{-}$) $\longrightarrow$ +'];                                  
            pname = 'exchange_20_halite_build_Cl_Na';           

     % oyrite formation set
     elseif active_plot_number==203
            number_sets = 1;
            name1 = 'exchange.ex21_pyrite_mantle'; scale1 = 3/6; col1 = col_1t_1v;
            xvar  = 'ALK'; 
            yvar  = 'H2S'; 
            tit   = '\bf{C}\rm: Pyrite formation set: \overrightarrow{\it{x\:}}$\!_{21}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(H$_{2}$S) $\longrightarrow$ +'];       
            pname = 'exchange_21_pyrite_mantle_H2S_ALK';   

     % cation substitution sets
     elseif active_plot_number==204
            number_sets = 2;
            name1 = 'exchange.ex23_CaFe_switch'; scale1 = 1.50/1.5;  col1 = col_2t_1v;            
            name2 = 'exchange.ex22_CaMg_switch'; scale2 = 0.6/1.5;   col2 = col_2t_2v;            
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{D}\rm: Cation substitution: \overrightarrow{\it{x\:}}$\!_{22}$, \overrightarrow{\it{x\:}}$\!_{23}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];        
            pname = 'exchange_22_23_CaMg_CaFe_switch_DIC_ALK'; 

     % C/S redox coupling set
     elseif active_plot_number==205
            number_sets = 1;
            name1 = 'exchange.ex24_couple_CS'; scale1 = 1/40; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit   = '\bf{E}\rm: C/S redox coupling: \overrightarrow{\it{x\:}}$\!_{24}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];        
            pname = 'exchange_24_couple_CS_DIC_ALK';
            
     % C/Fe redox coupling set
     elseif active_plot_number==206
            number_sets = 1;
            name1 = 'exchange.ex25_couple_CFe'; scale1 = 1/5; col1 = col_1t_1v;
            xvar = 'Fe2'; 
            yvar = 'FIC';           
            tit   = '\bf{F}\rm: C/Fe redox coupling: \overrightarrow{\it{x\:}}$\!_{25}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(Fe$^{2+}$) $\longrightarrow$  +'];                  
            ylab  = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];        
            pname = 'exchange_25_couple_CFe_DIC_ALK';    


    % OPEN SETS
    % O2 production open sets
    elseif  active_plot_number==301
            number_sets = 3;       
            name1 = 'open.op26_BK15_FeCO3_Fe2O3';  scale1 = 1.0/5; col1 = col_3t_1v;
            name2 = 'open.BK15_FeCO3_FeSiO3';      scale2 = 3.5/5; col2 = col_3t_2v;
            name3 = 'open.BK15_CaMgCO3_MgSiO3';    scale3 = 1.4/5; col3 = col_3t_3v;                        
            xvar = 'ALK'; 
            yvar = 'O2'; 
            tit = '\bf{A}\rm: O$_2$ production: \overrightarrow{\it{x\:}}$\!_{26}$, $\Sigma$\overrightarrow{\it{x\:}}$\!_{\rm{i}}$, $\Sigma$\overrightarrow{\it{x\:}}$\!_{\rm{i}}$';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(O$_2$) $\longrightarrow$  +'];            
            pname = 'open1_BK15_FeCO3_Fe2O3_O2_Fe2';           

    % FeS2 oxidation with silicate weathering set
    elseif  active_plot_number==302
            number_sets = 1;    
            name1 = 'open.op27_sulfox'; scale1 = 1/8; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'O2'; 
            tit = '\bf{B}\rm: FeS$_2$ ox. w/ silicate weath: \overrightarrow{\it{x\:}}$\!_{27}$';            
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(O$_2$) $\longrightarrow$  +'];            
            pname = 'open4_sulfox_O2_ALK';

    % rising Mg/Ca open set
    elseif  active_plot_number==303
            number_sets = 1;       
            name1 = 'open.op28_catswitch'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{C}\rm: Rising Mg$^{2+}$/Ca$^{2+}$: \overrightarrow{\it{x\:}}$\!_{28}$';
            xlab  = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$ +'];
            ylab  = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$  +'];        
            pname = 'open5_revweath_DIC_ALK';           


    % CENOZOIC PANELS
    % stable initial condition
    elseif  active_plot_number==1001
            number_sets = 1;       
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{A}\rm: Stable initial condition';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$ +'];                  
            pname = 'Cenozoic_1_base_case';                  
              
    % enhanced weatherability
    elseif  active_plot_number==1002
            number_sets = 1;       
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{B}\rm: Enhanced weatherability';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$ +'];                  
            pname = 'Cenozoic_2_weatherability';              

    % reduced reverse weathering
    elseif  active_plot_number==1003
            number_sets = 1;       
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{C}\rm: Reduced reverse weathering';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$ +'];                  
            pname = 'Cenozoic_3_reverse'; 
              
    % enhanced carbonate weathering
    elseif  active_plot_number==1004
            number_sets = 1;       
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{D}\rm: Enhanced carbonate weath.';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$ +'];                  
            pname = 'Cenozoic_4_carbonate'; 
          
   % enhanced sulfide oxidation    
   elseif  active_plot_number==1008
            number_sets = 1;       
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{F}\rm: Enhanced sulfide oxidation';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$ +'];                  
            pname = 'Cenozoic_5_sulfide_oxidation';       

    % enhanced metamorphism/Corg oxidation/Corg burial
    elseif  active_plot_number==1009
            number_sets = 1;       
            name1 = 'closed.n01_Urey_Ca'; scale1 = 1/2; col1 = col_1t_1v;
            xvar = 'ALK'; 
            yvar = 'FIC'; 
            tit = '\bf{E}\rm: Enhanced meta., C$\rm_{org}$ ox./burial';
            xlab = ['- $\longleftarrow$ \(\Delta \)(ALK) $\longrightarrow$  +'];
            ylab = ['- $\longleftarrow$ \(\Delta \)(FIC) $\longrightarrow$ +'];                  
            pname = 'Cenozoic_10_meta_organic_carbon';  
            
    else
        disp('could not find this plot request');
    end