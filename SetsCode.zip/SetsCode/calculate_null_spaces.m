%% calculate_null_spaces
% this script calculates the null spaces of Aclosed, Aexchange, and Aopen, 
% and then converts these null space vectors into the new basis x.

%% (1) calculate the rational null space of Aclosed
Aclosed_nullspace          = null(Aclosed,'rational');
[~, sizeAclosed]           = size(Aclosed_nullspace);
expanded_Aclosed_nullspace = nullCellExpand({cat(2,'eq.#',process_list)' [1:sizeAclosed; Aclosed_nullspace]});

% save the individual Aclosed nullspace vectors to the workspace as 'psi' variables
clear psi*; 
for i=1:sizeAclosed; eval([sprintf('psi_%i',i) '= Aclosed_nullspace(:,i);']); end 
closed_list = {};

% calculate an alternative set of null space vectors (x1 - x18)
% compare this code to equations S1 - S18 of the supplement
x.closed.n01_Urey_Ca               = psi_8+psi_9;         closed_list{01} = '01: Urey_Ca';             
x.closed.n02_Urey_Mg               = 2*psi_8+psi_10;      closed_list{02} = '02: Urey_Mg';             
x.closed.n03_Urey_Fe               = psi_8+psi_11;        closed_list{03} = '03: Urey_Fe';             
x.closed.n04_calcite_weath_form    = psi_9;               closed_list{04} = '04: calcite_form_weath';  
x.closed.n05_dolomite_weath_form   = psi_1+psi_10;        closed_list{05} = '05: dolomite_form_weath'; 
x.closed.n06_siderite_weath_form   = psi_2+psi_11;        closed_list{06} = '06: siderite_form_weath'; 
x.closed.n07_Mg_slct_reverse_weath = psi_4;               closed_list{07} = '07: Mg_slct_reverse_weath';
x.closed.n08_Na_slct_reverse_weath = psi_5;               closed_list{08} = '08: Na_slct_reverse_weat'; 
x.closed.n09_K_slct_reverse_weath  = psi_6;               closed_list{09} = '09: K_slct_reverse_weath'; 
x.closed.n10_Fe_slct_reverse_weath = psi_7;               closed_list{10} = '10: Fe_slct_reverse_weath';
x.closed.n11_photo_respir          = psi_12;              closed_list{11} = '11: photo_respir';         
x.closed.n12_iron_cycle            = psi_14;              closed_list{12} = '12: iron_cycle';           
x.closed.n13_sulfur_cycle          = psi_13;              closed_list{13} = '13: sulfur_cycle';         
x.closed.n14_pyrite_weath_form     = 4*psi_15+8*psi_13;   closed_list{14} = '14: pyrite_form_oxidation';
x.closed.n15_nitrogen_cycle        = psi_18;              closed_list{15} = '15: nitrogen_cycle';       
x.closed.n16_gypsum_form_weath     = psi_16;              closed_list{16} = '16: gypsum_form_weath';    
x.closed.n17_halite_form_weath     = psi_17;              closed_list{17} = '17: halite_form_weath';    
x.closed.n18_silica                = psi_3+psi_8;         closed_list{18} = '18: silica_form_weath';    

% combine the new null space vectors into a matrix
Xclosed = [x.closed.n01_Urey_Ca...
           x.closed.n02_Urey_Mg...
           x.closed.n03_Urey_Fe...
           x.closed.n04_calcite_weath_form ...
           x.closed.n05_dolomite_weath_form ...
           x.closed.n06_siderite_weath_form ...
           x.closed.n07_Mg_slct_reverse_weath ...
           x.closed.n08_Na_slct_reverse_weath ... 
           x.closed.n09_K_slct_reverse_weath  ...
           x.closed.n10_Fe_slct_reverse_weath ...
           x.closed.n11_photo_respir ...
           x.closed.n12_iron_cycle ...
           x.closed.n13_sulfur_cycle ...
           x.closed.n14_pyrite_weath_form ...         
           x.closed.n15_nitrogen_cycle ...
           x.closed.n16_gypsum_form_weath ...
           x.closed.n17_halite_form_weath...         
           x.closed.n18_silica ...
           ];

% check that the rank of the new basis matches the rank of the old basis
if  rank(Aclosed_nullspace)~=rank(Xclosed)
    disp('warning! rank of new basis set does not match rank of old basis'); 
end

% view the original null space basis vectors
nullCellExpand({process_list' psi_1});
nullCellExpand({process_list' psi_2});
nullCellExpand({process_list' psi_3});
nullCellExpand({process_list' psi_4});
nullCellExpand({process_list' psi_5});
nullCellExpand({process_list' psi_6});
nullCellExpand({process_list' psi_7});
nullCellExpand({process_list' psi_8});
nullCellExpand({process_list' psi_9});
nullCellExpand({process_list' psi_10});
nullCellExpand({process_list' psi_11});
nullCellExpand({process_list' psi_12});
nullCellExpand({process_list' psi_13});
nullCellExpand({process_list' psi_14});
nullCellExpand({process_list' psi_15});
nullCellExpand({process_list' psi_16});
nullCellExpand({process_list' psi_17});
nullCellExpand({process_list' psi_18});

% view the new null space basis vectors
nullCellExpand({process_list' x.closed.n01_Urey_Ca});
nullCellExpand({process_list' x.closed.n02_Urey_Mg});
nullCellExpand({process_list' x.closed.n03_Urey_Fe});
nullCellExpand({process_list' x.closed.n04_calcite_weath_form});
nullCellExpand({process_list' x.closed.n05_dolomite_weath_form});
nullCellExpand({process_list' x.closed.n06_siderite_weath_form});
nullCellExpand({process_list' x.closed.n07_Mg_slct_reverse_weath});
nullCellExpand({process_list' x.closed.n08_Na_slct_reverse_weath});
nullCellExpand({process_list' x.closed.n09_K_slct_reverse_weath});
nullCellExpand({process_list' x.closed.n10_Fe_slct_reverse_weath});
nullCellExpand({process_list' x.closed.n11_photo_respir});
nullCellExpand({process_list' x.closed.n12_iron_cycle});
nullCellExpand({process_list' x.closed.n13_sulfur_cycle});
nullCellExpand({process_list' x.closed.n14_pyrite_weath_form});
nullCellExpand({process_list' x.closed.n15_nitrogen_cycle});
nullCellExpand({process_list' x.closed.n16_gypsum_form_weath});
nullCellExpand({process_list' x.closed.n17_halite_form_weath});
nullCellExpand({process_list' x.closed.n18_silica});


%% (2) calculate the rational null space of Aexchange
Aexchange_nullspace          = null(Aexchange,'rational');
[~, sizeAexchangenull]       = size(Aexchange_nullspace); ll_exchange = sizeAexchangenull;
% The null space of Aexchange has dimensions 38 x 25. Of the 25 dimensions, 18 are the closed sets, leaving 7 new vectors. 
expanded_Aexchange_nullspace = nullCellExpand({cat(2,'eq.#',process_list)' [1:sizeAexchangenull; Aexchange_nullspace]});
    % for ease of visualization: 
     expanded_Aexchange_nullspace1 = nullCellExpand({cat(2,'eq.#',process_list)' [01:sizeAexchangenull; Aexchange_nullspace(:,01:end)]});
     expanded_Aexchange_nullspace2 = nullCellExpand({cat(2,'eq.#',process_list)' [11:sizeAexchangenull; Aexchange_nullspace(:,11:end)]});
     expanded_Aexchange_nullspace3 = nullCellExpand({cat(2,'eq.#',process_list)' [21:sizeAexchangenull; Aexchange_nullspace(:,21:end)]});

% save the individual Aexchange nullspace vectors with 'phi' abbreviations
clear phi*;
for i=1:sizeAexchangenull; eval([sprintf('phi_%i',i) '= Aexchange_nullspace(:,i);']); end

% to calculate the existing closed set vector from the phi vectors
% compare this code to equations S19 - S36 of the supplement
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n01_Urey_Ca,2)];               % (phi_1 + phi_11 + phi_12)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n02_Urey_Mg,2)];               % (phi_2 + 2*phi_11 + phi_13)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n03_Urey_Fe,2)];               % (phi_3 + phi_11 + phi_14)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n04_calcite_weath_form,2)];    % (phi_12)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n05_dolomite_weath_form,2)];   % (phi_4 + phi_13)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n06_siderite_weath_form,2)];   % (phi_5 + phi_14)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n07_Mg_slct_reverse_weath,2)]; % (phi_7)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n08_Na_slct_reverse_weath,2)]; % (phi_8)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n09_K_slct_reverse_weath,2)];  % (phi_9)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n10_Fe_slct_reverse_weath,2)]; % (phi_10)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n11_photo_respir,2)];          % (phi_15)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n12_iron_cycle,2)];            % (phi_17 + phi_18)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n13_sulfur_cycle,2)];          % (phi_16)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n14_pyrite_weath_form,2)];     % (8*phi_16 + phi_17 + phi_19 + 4*phi_20)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n15_nitrogen_cycle,2)];        % (phi_25)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n16_gypsum_form_weath,2)];     % (phi_21 + phi_22)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n17_halite_form_weath,2)];     % (phi_23 + phi_24)
 [[1:ll_exchange]' round(Aexchange_nullspace\x.closed.n18_silica,2)];                % (phi_6 +  phi_11)

% calculate the exchange sets from the phi vectors, compare to eqs. S37 - S43
% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_degassing_Urey,2)]
x.exchange.ex19_degassing_Urey = phi_11+phi_12;                   
closed_list{19} = '19: degassing_Urey';

% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_halite_formation,2)]
x.exchange.ex20_halite_build = phi_11+2*phi_24;                 
closed_list{20} = '20: halite_build';

% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_pyrite_mantle,2)]
x.exchange.ex21_pyrite_mantle = phi_6+phi_10+phi_20;             
closed_list{21} = '21: pyrite_mantle';

% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_CaMg_sub,2)]
x.exchange.ex22_CaMg_switch = phi_4+phi_7+2*phi_12;            
closed_list{22} = '22: CaMg_sub';

% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_CaFe_sub,2)]
x.exchange.ex23_CaFe_switch = phi_5+phi_10+phi_12;             
closed_list{23} = '23: CaFe_sub';

% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_couple_CS,2)]
x.exchange.ex24_couple_CS = (7*phi_4)+(7*phi_6)+(7*phi_7)+(1*phi_19)+(8*phi_22); 
closed_list{24} = '24: CS couple';

% [[1:ll_exchange]' round(Aexchange_nullspace\x.manual.exchange_couple_CFe,2)]
x.exchange.ex25_couple_CFe = (1*phi_5)+(3*phi_11)+(1*phi_17);           
closed_list{25} = '25: CFe couple';

% view the new null space basis vectors
nullCellExpand({process_list' x.exchange.ex19_degassing_Urey});
nullCellExpand({process_list' x.exchange.ex20_halite_build});
nullCellExpand({process_list' x.exchange.ex21_pyrite_mantle});
nullCellExpand({process_list' x.exchange.ex22_CaMg_switch});
nullCellExpand({process_list' x.exchange.ex23_CaFe_switch});
nullCellExpand({process_list' x.exchange.ex24_couple_CS});
nullCellExpand({process_list' x.exchange.ex25_couple_CFe});

% combine the new null space vectors into a matrix
Xexchange_isolated = [x.exchange.ex19_degassing_Urey ...
                      x.exchange.ex20_halite_build ...
                      x.exchange.ex21_pyrite_mantle ...              
                      x.exchange.ex22_CaMg_switch ...
                      x.exchange.ex23_CaFe_switch ...
                      x.exchange.ex24_couple_CS ...
                      x.exchange.ex25_couple_CFe ...             
                      ];

% combine the new null space vectors with the closed set vectors and check 
% that the rank of the new basis matches the rank of the old basis
Xexchange = [Xclosed Xexchange_isolated];
if rank(Xexchange)~=rank(Aexchange_nullspace)
    disp('warning! rank of new exchange basis set does not match rank of old exchange basis'); 
end


%% (3) calculate the rational null space of Aopen
Aopen_nullspace          = null(Aopen,'rational');
[~, sizeAopennull]       = size(Aopen_nullspace); ll_open = sizeAopennull;
% The null space has dimensions of 38 x 36. of the 36 vectors, 18 are the closed sets 
% and 7 are exchange sets, meaning there are 11 linearly independent new vectors. 
expanded_Aopen_nullspace = nullCellExpand({cat(2,'eq.#',process_list)' [1:sizeAopennull; Aopen_nullspace]});
    % for ease of visualization: 
      expanded_Aopen_nullspace1 = nullCellExpand({cat(2,'eq.#',process_list)' [01:sizeAopennull; Aopen_nullspace(:,01:end)]});
      expanded_Aopen_nullspace2 = nullCellExpand({cat(2,'eq.#',process_list)' [11:sizeAopennull; Aopen_nullspace(:,11:end)]});
      expanded_Aopen_nullspace3 = nullCellExpand({cat(2,'eq.#',process_list)' [21:sizeAopennull; Aopen_nullspace(:,21:end)]});
      expanded_Aopen_nullspace4 = nullCellExpand({cat(2,'eq.#',process_list)' [31:sizeAopennull; Aopen_nullspace(:,31:end)]});

% save the individual Aopen nullspace vectors with 'ksi' abbreviations
clear ksi*;
for i=1:sizeAopennull; eval([sprintf('ksi_%i',i) '= Aopen_nullspace(:,i);']); end

% to calculate each null vector from the phi vectors: [[1:ll_open]' round(Aopen_nullspace\Xfull,2)]
% compare this code to equations S47 - S64 of the supplement
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n01_Urey_Ca,2)];               % (ksi_2 + ksi_5 + ksi_18 + ksi_19)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n02_Urey_Mg,2)];               % (ksi_3 + ksi_5 + ksi_6 + 2*ksi_18 + ksi_20)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n03_Urey_Fe,2)];               % (ksi_4 + ksi_9 + ksi_18 + ksi_21)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n04_calcite_weath_form,2)];    % (ksi_10 + ksi_19)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n05_dolomite_weath_form,2)];   % (ksi_11 + ksi_20)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n06_siderite_weath_form,2)];   % (ksi_12 + ksi_21)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n07_Mg_slct_reverse_weath,2)]; % (ksi_6 + ksi_14)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n08_Na_slct_reverse_weath,2)]; % (ksi_7 + ksi_15)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n09_K_slct_reverse_weath,2)];  % (ksi_8 + ksi_16)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n10_Fe_slct_reverse_weath,2)]; % (ksi_9 + ksi_17)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n11_photo_respir,2)];          % (ksi_22 + ksi_23)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n12_iron_cycle,2)];            % (ksi_22 + ksi_26 + ksi_27)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n13_sulfur_cycle,2)];          % (2*ksi_22 + ksi_24 + ksi_25)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n14_pyrite_weath_form,2)];     % (16*ksi_22 + 8*ksi_25 + ksi_26 + kis_28 + 4*ksi_29)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n15_nitrogen_cycle,2)];        % (5*ksi_22 + ksi_34 + 4*ksi_35 + ksi_36)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n16_gypsum_form_weath,2)];     % (ksi_30 + ksi_31)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n17_halite_form_weath,2)];     % (ksi_32 + ksi_33)
 [[1:ll_open]' round(Aopen_nullspace\x.closed.n18_silica,2)];                % (ksi_13 + ksi_18)

% compare this code to equations S65 - S71 of the supplement
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex19_degassing_Urey,2)];     % (ksi_5 + ksi_18 + ksi_19)
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex20_halite_build,2)];       % (ksi_7 + ksi_18 + 2*ksi_33)
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex21_pyrite_mantle,2)];      % (2*ksi_1 + ksi_13 + ksi_17 + ksi_29)
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex22_CaMg_switch,2)];        % (ksi_5 + ksi_11 + ksi_14 + 2*ksi_19)
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex23_CaFe_switch,2)];        % (ksi_5 + ksi_12 + ksi_17 + ksi_19)
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex24_couple_CS,2)];          % (ksi_10 + 7*ksi_11 + 7*ksi_13 + 7*ksi_14 + 15*ksi_22 + ksi_28 + 8*ksi_31)
 [[1:ll_open]' round(Aopen_nullspace\x.exchange.ex25_couple_CFe,2)];         % (3*ksi_9 + ksi_12 + 3*ksi_18 + ksi_22 + ksi_26)

% define a new list for the open sets
open_list = closed_list;

% calculate the open sets from the ksi vectors, compare to eqs. S72 - S82
% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_BK15_FeCO3_Fe2O3,2)]
x.open.op26_BK15_FeCO3_Fe2O3 = 4*ksi_12 + 4*ksi_22 + ksi_26;  
open_list{26} = '26: FeCO3_Fe2O3';      

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_sulfox,2)]
x.open.op27_sulfox = 8*ksi_5 + ksi_28;              
open_list{27} = '27: Sulfox';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_catswitch,2)]
x.open.op28_catswitch = ksi_11 + 2*ksi_19;            
open_list{28} = '28: carbonate cat switching';
 
% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_mantle_H2S,2)]
x.open.op29_mantle_H2S = ksi_1;                         
open_list{29} = '29: mantle H2S';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_Ca_silicate,2)]
x.open.op30_Ca_silicate = ksi_5;                         
open_list{30} = '30: Ca-silicate';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_Na_silicate,2)]
x.open.op31_Na_silicate = ksi_7;                         
open_list{31} = '31: Na-silicate';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_K_silicate,2)]
x.open.op32_K_silicate = ksi_8;                         
open_list{32} = '32: K-silicate';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_Fe_silicate,2)]
x.open.op33_Fe_silicate = ksi_9;                         
open_list{33} = '33: Fe-silicate';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_Si_weathering,2)]
x.open.op34_Si_weathering = ksi_13;                        
open_list{34} = '34: Silica weathering';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_N2_fixation,2)]
x.open.op35_N2_fixation = ksi_34;                        
open_list{35} = '35: N2 fixation';

% [[1:ll_open]' round(Aopen_nullspace\x.manual.open_nitrification,2)]
x.open.op36_nitrification = ksi_34+2*ksi_35;               
open_list{36} = '36: nitrification';

% view the new null space basis vectors
nullCellExpand({process_list' x.open.op26_BK15_FeCO3_Fe2O3});
nullCellExpand({process_list' x.open.op27_sulfox});
nullCellExpand({process_list' x.open.op28_catswitch});
nullCellExpand({process_list' x.open.op29_mantle_H2S});
nullCellExpand({process_list' x.open.op30_Ca_silicate});
nullCellExpand({process_list' x.open.op31_Na_silicate});
nullCellExpand({process_list' x.open.op32_K_silicate});
nullCellExpand({process_list' x.open.op33_Fe_silicate});
nullCellExpand({process_list' x.open.op34_Si_weathering});
nullCellExpand({process_list' x.open.op35_N2_fixation});
nullCellExpand({process_list' x.open.op36_nitrification});

% combine the new null space vectors into a matrix
Xopen_isolated  = [x.open.op26_BK15_FeCO3_Fe2O3 ...
                   x.open.op27_sulfox ...
                   x.open.op28_catswitch ...              
                   x.open.op29_mantle_H2S  ...
                   x.open.op30_Ca_silicate ...
                   x.open.op31_Na_silicate ...
                   x.open.op32_K_silicate ...             
                   x.open.op33_Fe_silicate ...             
                   x.open.op34_Si_weathering  ...             
                   x.open.op35_N2_fixation ...             
                   x.open.op36_nitrification ...             
                   ];

% combine the new null space vectors with the closed and exchange set vectors and check 
% that the rank of the new basis matches the rank of the old basis
Xopen = [Xclosed Xexchange_isolated Xopen_isolated];
if rank(Xopen)~=rank(Aopen_nullspace)
    disp('warning! rank of new open basis set does not match rank of old open basis'); 
end


%% now calculate how to express other reactions in term of x1 through x36 
clear alpha; alpha = struct;

% exchange sets
    x.exchange.FeCaMg_sub               = x.manual.exchange_FeCaMg_sub;
    x.exchange.couple_CS_reverse        = x.manual.exchange_couple_CS_reverse;
    x.exchange.couple_CFe_reverse       = x.manual.exchange_couple_CFe_reverse;
    x.exchange.couple_CFe2              = x.manual.exchange_couple_CFe2;
    x.exchange.couple_SFe               = x.manual.exchange_couple_SFe;   
    
    alpha.exchange.FeCaMg_carb_slct_sub = round(Xexchange\x.exchange.FeCaMg_sub,10);         % nullCellExpand({round(Xexchange\x.exchange.FeCaMg_sub,10)         round(Xopen\x.exchange.FeCaMg_sub,10)});
    alpha.exchange.couple_CS_reverse    = round(Xexchange\x.exchange.couple_CS_reverse,10);  % nullCellExpand({round(Xexchange\x.exchange.couple_CS_reverse,10)  round(Xopen\x.exchange.couple_CS_reverse,10)});
    alpha.exchange.couple_CFe_reverse   = round(Xexchange\x.exchange.couple_CFe_reverse,10); % nullCellExpand({round(Xexchange\x.exchange.couple_CFe_reverse,10) round(Xopen\x.exchange.couple_CFe_reverse,10)});
    alpha.exchange.couple_CFe2          = round(Xexchange\x.exchange.couple_CFe2,10);        % nullCellExpand({round(Xexchange\x.exchange.couple_CFe2,10)        round(Xopen\x.exchange.couple_CFe2,10)});
    alpha.exchange.couple_SFe           = round(Xexchange\x.exchange.couple_SFe,10);         % nullCellExpand({round(Xexchange\x.exchange.couple_SFe,10)         round(Xopen\x.exchange.couple_SFe,10)});
    
    if abs(sum(x.exchange.FeCaMg_sub         - (Xexchange*alpha.exchange.FeCaMg_carb_slct_sub)))  > 1e-10; keyboard; end
    if abs(sum(x.exchange.couple_CS_reverse  - (Xexchange*alpha.exchange.couple_CS_reverse)))     > 1e-10; keyboard; end
    if abs(sum(x.exchange.couple_CFe_reverse - (Xexchange*alpha.exchange.couple_CFe_reverse)))    > 1e-10; keyboard; end
    if abs(sum(x.exchange.couple_CFe2        - (Xexchange*alpha.exchange.couple_CFe2)))           > 1e-10; keyboard; end
    if abs(sum(x.exchange.couple_SFe         - (Xexchange*alpha.exchange.couple_SFe)))            > 1e-10; keyboard; end    
        
    
% open sets
    x.open.BK15_FeCO3_FeSiO3       = x.manual.open_BK15_FeCO3_FeSiO3;
    x.open.BK15_CaMgCO3_MgSiO3     = x.manual.open_BK15_CaMgCO3_MgSiO3;
         
    alpha.open.BK15_FeCO3_FeSiO3   = round(Xopen\x.open.BK15_FeCO3_FeSiO3,10);
    alpha.open.BK15_CaMgCO3_MgSiO3 = round(Xopen\x.open.BK15_CaMgCO3_MgSiO3,10);
    
    if abs(sum(x.open.BK15_FeCO3_FeSiO3   - (Xopen*alpha.open.BK15_FeCO3_FeSiO3)))   > 1e-10; keyboard; end
    if abs(sum(x.open.BK15_CaMgCO3_MgSiO3 - (Xopen*alpha.open.BK15_CaMgCO3_MgSiO3))) > 1e-10; keyboard; end
   

%% (5) clean up the workspace
clear psi_*
clear phi_*
clear ksi_*
clear i
