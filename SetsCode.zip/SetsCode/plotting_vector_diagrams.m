%% plotting_vector_diagrams
% this script plots vector diagrams

% make a plot
close all; clear active_plot_number number_sets name* xvar yvar tit xlab ylab pname
ra = char(8594); la = char(8592);

%plotlist = [101:108];             % closed sets (Fig. 3 panels)
%plotlist = [201:206];             % exchange sets (Fig. 4 panels)
%plotlist = [301:303];             % open sets (Fig. 5 panels)
%plotlist = [1001:1004 1008:1009]; % Cenozoic sets (Fig. 6 panels)
plotlist = [101:108 201:206 301:303 1001:1004 1008:1009]; % plot panels for Figs. 3-6

displayvectorinfo      = 0; % display vector information on command line
keyboardeachset        = 0; % stop on each set
includeticks           = 0; % include tick marks

colbackgroundlines = 0.75*[1 1 1]; % background line color
colorscheme = 'cb'; %'black','colors','spectral','cb'
  
if isequal(colorscheme,'black')
       col_1t_1v_0 = 0.00*[1 1 1]; 
       col_2t_1v_0 = 0.00*[1 1 1];
       col_2t_2v_0 = 0.40*[1 1 1];
       col_3t_1v_0 = 0.00*[1 1 1];
       col_3t_2v_0 = 0.20*[1 1 1];
       col_3t_3v_0 = 0.40*[1 1 1];
       col_4t_1v_0 = 0.00*[1 1 1];
       col_4t_2v_0 = 0.15*[1 1 1];
       col_4t_3v_0 = 0.30*[1 1 1];
       col_4t_4v_0 = 0.45*[1 1 1];
elseif isequal(colorscheme,'colors')
       basecol   = [0.7 0 0];   
       col_1t_1v_0 = [0 0 0]; 
       col_2t_1v_0 = basecol*0/1;
       col_2t_2v_0 = basecol*1/1;
       col_3t_1v_0 = basecol*0/2;
       col_3t_2v_0 = basecol*1.5/2;
       col_3t_3v_0 = basecol*2/2;
       col_4t_1v_0 = basecol*0/3;
       col_4t_2v_0 = basecol*1/3;
       col_4t_3v_0 = basecol*2/3;
       col_4t_4v_0 = basecol*3/3;
elseif isequal(colorscheme,'spectral')
       c1 = [1         1         0.74902]; % brewermap(1,'Spectral');
       c2 = [0.95686   0.42745   0.26275;
             0.4       0.76078   0.64706]; % brewermap(2,'Spectral');          
       c3 = [0.98824   0.55294   0.34902;
             1         1         0.74902;
             0.6       0.83529   0.58039]; % brewermap(3,'Spectral');          
       c4 = [0.84314   0.098039  0.1098
             0.99216   0.68235   0.38039
             0.67059   0.86667   0.64314
             0.16863   0.51373   0.72941]; % brewermap(4,'Spectral');
       col_1t_1v_0 = c1; 
       col_2t_1v_0 = c2(1,:);
       col_2t_2v_0 = c2(2,:);
       col_3t_1v_0 = c3(1,:);
       col_3t_2v_0 = c3(2,:);
       col_3t_3v_0 = c3(3,:);
       col_4t_1v_0 = c4(1,:);
       col_4t_2v_0 = c4(2,:);
       col_4t_3v_0 = c4(3,:);
       col_4t_4v_0 = c4(4,:);
elseif isequal(colorscheme,'cb')
       color_black  = [0 0 0];
       color_blue   = [31,120,180]/255;
       color_orange = [252,141,98]/255;
       color_green  = [102,194,165]/255*0.75;
       color_purple = [117,107,177]/255;
       col_1t_1v_0 = color_black; 
       col_2t_1v_0 = color_black;
       col_2t_2v_0 = color_blue;
       col_3t_1v_0 = color_black;
       col_3t_2v_0 = color_blue;
       col_3t_3v_0 = color_orange;
       col_4t_1v_0 = color_black;
       col_4t_2v_0 = color_blue;
       col_4t_3v_0 = color_orange;
       col_4t_4v_0 = color_green;             
end
colorgrey = 0.0*[1 1 1];

c3   =   [0.98824   0.55294   0.34902;
          1         1         0.74902;
          0.6       0.83529   0.58039]; %brewermap(3,'Spectral');

for ni=1:length(plotlist)
    active_plot_number = plotlist(ni); clc;

    % whether or not to plot arrows tip to tail
    if   active_plot_number<1000
         arrowstiptotail  = 1; % when plotting multiple sets, each set should be tip-to-tial
         plotspecialontop = 0; % no special vectors for closed, exchange, and open sets
    else   
         arrowstiptotail  = 0; % all the Cenozoic vector occur as one set, turn off tip-to-tail plotting
         plotspecialontop = 1; % the Cenozoic panels have special vectors
    end

    % special colors for the reverse sets
    if     active_plot_number==103 
           col_4t_1v = color_blue;
           col_4t_2v = color_green;
           col_4t_3v = color_black;
           col_4t_4v = color_orange;   
    elseif active_plot_number==104
           col_2t_1v = color_black;
           col_2t_2v = color_orange;  
    elseif active_plot_number==105
           col_2t_1v = color_purple;
           col_2t_2v = color_orange;        
    elseif active_plot_number==107
           col_2t_1v = color_purple;
           col_2t_2v = color_green;            
    elseif active_plot_number==204
           col_2t_1v = color_orange;
           col_2t_2v = color_blue;         
    elseif active_plot_number==301
           col_3t_1v = color_orange;
           col_3t_2v = color_green;
           col_3t_3v = color_blue;   
    else
           col_1t_1v = col_1t_1v_0; 
           col_2t_1v = col_2t_1v_0;
           col_2t_2v = col_2t_2v_0;
           col_3t_1v = col_3t_1v_0;
           col_3t_2v = col_3t_2v_0;
           col_3t_3v = col_3t_3v_0;
           col_4t_1v = col_4t_1v_0;
           col_4t_2v = col_4t_2v_0;
           col_4t_3v = col_4t_3v_0;
           col_4t_4v = col_4t_4v_0;   
    end

    % first, find the information for this plot number
    plotting_find_active_plot_info; 

    % make a figure and set plotting parameters
    hf = figure(active_plot_number); clf;
    fs = 10; fs_txt = 10; lw = 1.5; ms = 5; mw = 1.0;

    % loop over each set to be plotted
    for active_set_number=1:number_sets        

        % get the vector for this particular set
        currentname  = eval(sprintf('name%i',active_set_number));
        x_active     = eval(sprintf('x.%s',currentname)); 
        currentscale = eval(sprintf('scale%i',active_set_number));
        currentcol   = eval(sprintf('col%i',active_set_number));

        % isolate the values to be plotted
        aproc        = process_list(x_active~=0);
        xint         = x_active(x_active~=0)';
        xint         = xint*currentscale;
        xvals_stoich = Aclosed(ismember(var_list.search_closed,xvar),x_active~=0);
        yvals_stoich = Aclosed(ismember(var_list.search_closed,yvar),x_active~=0);        
        xvals_plot   = xvals_stoich.*xint;
        yvals_plot   = yvals_stoich.*xint;      

        % set a scaler for axis size
        xyscaler = 1.1;
        xylim = xyscaler*max(abs([xvals_plot yvals_plot]));
        if active_plot_number>1000; xylim = xylim*2.3; end        
        rm = (xvals_plot==0 & yvals_plot==0);
        xvals_plot = xvals_plot(~rm);
        yvals_plot = yvals_plot(~rm);    
        aproc_plot = aproc(~rm);

        % scale the axes
        if     active_set_number == 1; xylimmax = xylim; 
        elseif xylim>xylimmax;         xylimmax = xylim; 
        end

        % set default arrow information
        colset    = repmat(currentcol,length(xvals_plot),1);        
        lw_list   = repmat(2,length(xvals_plot),1);
        hl_list   = repmat(7,length(xvals_plot),1);
        hw_list   = repmat(7,length(xvals_plot),1);
        arrowtype = {}; for jj=1:length(xvals_plot); arrowtype{jj} = '-'; end
        
        % manually switch around any particularly troublesome arrows
        if active_plot_number==205                       
            xvals_plot0 = xvals_plot; xvals_plot_temp = xvals_plot; xvals_plot_temp(1) = xvals_plot(2); xvals_plot_temp(2) = xvals_plot(1); xvals_plot = xvals_plot_temp;
            yvals_plot0 = yvals_plot; yvals_plot_temp = yvals_plot; yvals_plot_temp(1) = yvals_plot(2); yvals_plot_temp(2) = yvals_plot(1); yvals_plot = yvals_plot_temp;
            aproc_plot0 = aproc_plot; aproc_plot_temp = aproc_plot; aproc_plot_temp{1} = aproc_plot{2}; aproc_plot_temp{2} = aproc_plot{1}; aproc_plot = aproc_plot_temp;
        end

        % check if this is a Cenozoic panel (when number is > 1000)
        plotting_Cenozoic_vectors; 
        xvals_plot_start = zeros(size(xvals_plot_end));
        yvals_plot_start = zeros(size(xvals_plot_end));        

        % stacking / tip-to-tail
        angles = atand(yvals_plot_end./xvals_plot_end);
        angles(yvals_plot_end<0  & xvals_plot_end<0) = angles(yvals_plot_end<0 & xvals_plot_end<0)+180;
        angles(yvals_plot_end==0 & xvals_plot_end<0) = angles(yvals_plot_end==0 & xvals_plot_end<0)+180;
        angles(xvals_plot_end<0  & yvals_plot_end>0) = angles(xvals_plot_end<0  & yvals_plot_end>0)+180;
        % for any double angles, stack the arrows one after another        
        if arrowstiptotail==1
            for active_angle=1:length(angles)
                countprior = sum(angles(active_angle)==angles(1:active_angle))-1;            
                if  countprior>0                
                    findangle_pos        = find(angles(active_angle)==angles(1:active_angle));
                    currentangle_findpos = find(findangle_pos==active_angle);
                    lastpos_findpos      = findangle_pos(currentangle_findpos-1);
                    xvals_plot_start(active_angle) = xvals_plot_end(lastpos_findpos);
                    yvals_plot_start(active_angle) = yvals_plot_end(lastpos_findpos);
                    xvals_plot_end(active_angle)   = xvals_plot_end(lastpos_findpos)+xvals_plot_end(active_angle);
                    yvals_plot_end(active_angle)   = yvals_plot_end(lastpos_findpos)+yvals_plot_end(active_angle);                
                end
            end
            orderlist = 1:length(angles);        
        else % when not plotting tip-to-tail, stack the arrows by magnitude
            orderlist = NaN(1,length(angles));
            uniqueangles = unique(angles);
            countt = 0; 
            for uangleindx = 1:length(uniqueangles)
                uangle = uniqueangles(uangleindx);
                upos   = find(angles==uangle);
                magn   = sqrt(xvals_plot_end(upos).^2 + yvals_plot_end(upos).^2);
                [sortedmagn, sortedmagnindx] = sort(magn,'descend');
                orderlist(countt+1:countt+length(upos)) = upos(sortedmagnindx);                
                countt = countt+length(upos);
            end            
        end

        % for the Cenozoic panels, move the special arrows to the
        % end of the plotting order vector so that they appear most visibly
        if plotspecialontop == 1
            l                           = length(orderlist);
            numberspec                  = sum(specialist);
            orderlist0                  = orderlist; 
            orderlist                   = NaN(size(orderlist));
            positionspecial             = find(ismember(orderlist0,find(specialist)));
            orderlist(1:l-numberspec)   = orderlist0(~ismember(1:l,positionspecial));
            orderlist(l-numberspec+1:l) = orderlist0(positionspecial);
        end
           
        % plot the arrows and adjust their colors, thickness, etc.
        for ivalindx=1:size(colset,1)
            ival = orderlist(ivalindx);
            if ~isnan(xvals_plot_end(ival))
                ha = annotation('arrow',[0 0],[1 1],'color',colset(ival,:),'linewidth',lw); hold on;
                ha.Parent = hf.CurrentAxes;  % associate annotation with current axes
                ha.X = [xvals_plot_start(ival) xvals_plot_end(ival)]; % reorient the arrow
                ha.Y = [yvals_plot_start(ival) yvals_plot_end(ival)]; % reorient the arrow   
                ha.HeadLength = hl_list(ival); % default
                ha.HeadWidth  = hw_list(ival); % default
                ha.HeadStyle  = 'plain'; % cback1, cback2, cback3, vback1, vback2, vback3   
                ha.LineStyle  = arrowtype{ival};
                ha.LineWidth  = lw_list(ival); 
            end           
        end        
        
        if keyboardeachset ==1
            % stop on each figure, if desired
            set(gca,'xlim',[-3 3],'ylim',[-3 3])
            keyboard               
        end
        if displayvectorinfo==1   
           lproc = cat(2,{currentname},aproc_plot);
           lxvals = xvals_plot; lxvals(2:end+1) = lxvals; lxvals(1) = NaN;
           lyvals = yvals_plot; lyvals(2:end+1) = lyvals; lyvals(1) = NaN;
           langle = angles;     langle(2:end+1) = langle; langle(1) = NaN;
           CellExpand({lproc' lxvals' lyvals' langle'})
        end
    end
    
    % plot a point at the origin
    plot(0,0,'o','markersize',ms,'markerfacecolor','k','markeredgecolor','w','linewidth',mw);

    % plot background lines
    hp = plot(xylimmax*[-1 1],[0 0],'color',colbackgroundlines,'linewidth',lw); uistack(hp,'bottom'); hold on; 
    hp = plot([0 0],xylimmax*[-1 1],'color',colbackgroundlines,'linewidth',lw); uistack(hp,'bottom'); hold on; 
       
    % plot cosmetics
    xlabel(xlab,'interpreter','latex','fontsize',fs);
    ylabel(ylab,'interpreter','latex','fontsize',fs);    
    interptype = 'latex';

    % add labels to the arrows
    plotting_arrow_labels

    % add title, more cosmetics
    t = title(tit,'interpreter','latex'); 
    set(t,'FontSize',fs+2)   
    set(gca,'fontsize',fs,'linewidth',1.2)
    set(gca,'xlim',xylimmax*[-1 1],'ylim',xylimmax*[-1 1])
    box on
    
    % add or remove marks, as desired
    if includeticks==1   
        if     round(xylimmax)==1; spacer = 0.5;  
        elseif round(xylimmax)==2; spacer = 1.0; 
        end
    set(gca,'xtick',[-2:spacer:2],'yticklabel',''); set(gca,'ytick',[-2:spacer:2],'xticklabel','')
    else
    set(gca,'xtick',[]); set(gca,'ytick',[])
    end

    % final figure cosmetics
    set(gca,'layer','top')
    set(gcf,'renderer','painters')

    % print the figure
    cd VectorDiagrams % go into the figures folder
    set(gcf,'PaperUnits','inches','PaperPosition',[0 0 2.5 2.5]);
    if active_plot_number<1000
        print('-depsc',sprintf('set_%s',pname),'-r500');
    else
        print('-depsc',sprintf('set_%s_tip%i_spec%i',pname,arrowstiptotail,plotspecialontop),'-r500');
    end
    cd ../
end
