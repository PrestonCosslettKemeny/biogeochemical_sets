function newcell = nullCellExpand(din)

hspace = 0;
vspace = 0;

newcell = {};
for i = 1:height(din)
    for j=1:width(din)
         activecell = din{i,j};
         if iscell(activecell) == 0
             try  
                  activecell = nulldouble2cell(activecell);
             catch
             end
          end
         [a, b] = size(activecell);
         newcell(vspace+1:a+vspace,hspace+1:b+hspace) = activecell;
         hspace = hspace+b;
    end
    hspace = 0;
    vspace = vspace + a;
end
       
 