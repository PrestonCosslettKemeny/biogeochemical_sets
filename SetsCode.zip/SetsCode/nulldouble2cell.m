function [newmatrix] = nulldouble2cell(datain)
    newmatrix = {};
    dim = size(datain);
    for i = 1:dim(1)
        for j = 1:dim(2)
           newmatrix{i,j} = datain(i,j);
        end
    end
end