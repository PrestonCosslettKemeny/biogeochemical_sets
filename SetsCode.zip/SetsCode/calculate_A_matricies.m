%% calculate_A_matricies
% this script defines biogeochemical reaction coefficients and arranges that information 
% into matrix form. the first part of the script defines the stoichiometric coefficients for 
% each of the 38 biogeochemical processes described in table 1 of the main text. 
% the second part of the script then organizes the reaction information into the three
% matricies - Aopen, Aexchange, and Aclosed.

% clear the process structure
clear process; process = struct; 

%% 1. define biogeochemical processes

% reaction #1: mantle degassing of CO2
process.mantle_CO2.ALK        = +0; % #01 
process.mantle_CO2.FIC        = +1; % #02
process.mantle_CO2.Ca         = +0; % #03
process.mantle_CO2.Mg         = +0; % #04
process.mantle_CO2.Na         = +0; % #05
process.mantle_CO2.K          = +0; % #06
process.mantle_CO2.Fe2        = +0; % #07
process.mantle_CO2.SiO2_aq    = +0; % #08
process.mantle_CO2.O2         = +0; % #09
process.mantle_CO2.SO4        = +0; % #10
process.mantle_CO2.H2S        = +0; % #11
process.mantle_CO2.Cl         = +0; % #12
process.mantle_CO2.N2         = +0; % #13
process.mantle_CO2.NH4        = +0; % #14
process.mantle_CO2.NO3        = +0; % #15
process.mantle_CO2.H2O        = +0; % #16
process.mantle_CO2.CaCO3      = +0; % #17
process.mantle_CO2.CaMgCO32   = +0; % #18
process.mantle_CO2.FeCO3      = +0; % #19
process.mantle_CO2.CaSiO3     = +0; % #20
process.mantle_CO2.MgSiO3     = +0; % #21
process.mantle_CO2.Na2SiO3    = +0; % #22
process.mantle_CO2.K2SiO3     = +0; % #23
process.mantle_CO2.FeSiO3     = +0; % #24
process.mantle_CO2.SiO2_solid = +0; % #25
process.mantle_CO2.CH2O       = +0; % #26
process.mantle_CO2.FeS2       = +0; % #27
process.mantle_CO2.Fe2O3      = +0; % #28
process.mantle_CO2.CaSO4_2H2O = +0; % #29
process.mantle_CO2.NaCl       = +0; % #30
process.mantle_CO2.mantle_CO2 = -1; % #31
process.mantle_CO2.mantle_HCl = +0; % #32
process.mantle_CO2.mantle_H2S = +0; % #33

% reaction #2: mantle degassing of HCl
process.mantle_HCl.ALK        = -1; % #01 
process.mantle_HCl.FIC        = +0; % #02
process.mantle_HCl.Ca         = +0; % #03 
process.mantle_HCl.Mg         = +0; % #04
process.mantle_HCl.Na         = +0; % #05
process.mantle_HCl.K          = +0; % #06
process.mantle_HCl.Fe2        = +0; % #07
process.mantle_HCl.SiO2_aq    = +0; % #08
process.mantle_HCl.O2         = +0; % #09
process.mantle_HCl.SO4        = +0; % #10
process.mantle_HCl.H2S        = +0; % #11
process.mantle_HCl.Cl         = +1; % #12
process.mantle_HCl.N2         = +0; % #13
process.mantle_HCl.NH4        = +0; % #14
process.mantle_HCl.NO3        = +0; % #15
process.mantle_HCl.H2O        = +0; % #16
process.mantle_HCl.CaCO3      = +0; % #17
process.mantle_HCl.CaMgCO32   = +0; % #18
process.mantle_HCl.FeCO3      = +0; % #19
process.mantle_HCl.CaSiO3     = +0; % #20
process.mantle_HCl.MgSiO3     = +0; % #21
process.mantle_HCl.Na2SiO3    = +0; % #22
process.mantle_HCl.K2SiO3     = +0; % #23
process.mantle_HCl.FeSiO3     = +0; % #24
process.mantle_HCl.SiO2_solid = +0; % #25
process.mantle_HCl.CH2O       = +0; % #26
process.mantle_HCl.FeS2       = +0; % #27
process.mantle_HCl.Fe2O3      = +0; % #28
process.mantle_HCl.CaSO4_2H2O = +0; % #29
process.mantle_HCl.NaCl       = +0; % #30
process.mantle_HCl.mantle_CO2 = +0; % #31
process.mantle_HCl.mantle_HCl = -1; % #32
process.mantle_HCl.mantle_H2S = +0; % #33


% reaction #3: mantle degassing of H2S
process.mantle_H2S.ALK        = +0; % #01 
process.mantle_H2S.FIC        = +0; % #02
process.mantle_H2S.Ca         = +0; % #03 
process.mantle_H2S.Mg         = +0; % #04 
process.mantle_H2S.Na         = +0; % #05 
process.mantle_H2S.K          = +0; % #06 
process.mantle_H2S.Fe2        = +0; % #07 
process.mantle_H2S.SiO2_aq    = +0; % #08 
process.mantle_H2S.O2         = +0; % #09 
process.mantle_H2S.SO4        = +0; % #10 
process.mantle_H2S.H2S        = +1; % #11 
process.mantle_H2S.Cl         = +0; % #12 
process.mantle_H2S.N2         = +0; % #13 
process.mantle_H2S.NH4        = +0; % #14 
process.mantle_H2S.NO3        = +0; % #15 
process.mantle_H2S.H2O        = +0; % #16 
process.mantle_H2S.CaCO3      = +0; % #17 
process.mantle_H2S.CaMgCO32   = +0; % #18 
process.mantle_H2S.FeCO3      = +0; % #19 
process.mantle_H2S.CaSiO3     = +0; % #20 
process.mantle_H2S.MgSiO3     = +0; % #21 
process.mantle_H2S.Na2SiO3    = +0; % #22 
process.mantle_H2S.K2SiO3     = +0; % #23 
process.mantle_H2S.FeSiO3     = +0; % #24 
process.mantle_H2S.SiO2_solid = +0; % #25 
process.mantle_H2S.CH2O       = +0; % #26 
process.mantle_H2S.FeS2       = +0; % #27 
process.mantle_H2S.Fe2O3      = +0; % #28 
process.mantle_H2S.CaSO4_2H2O = +0; % #29 
process.mantle_H2S.NaCl       = +0; % #30 
process.mantle_H2S.mantle_CO2 = +0; % #31 
process.mantle_H2S.mantle_HCl = +0; % #32 
process.mantle_H2S.mantle_H2S = -1; % #33 


% reaction #4: calcite metamorphism
process.calcite_metamorphism.ALK        = +0; % #01 
process.calcite_metamorphism.FIC        = +1; % #02
process.calcite_metamorphism.Ca         = +0; % #03 
process.calcite_metamorphism.Mg         = +0; % #04 
process.calcite_metamorphism.Na         = +0; % #05 
process.calcite_metamorphism.K          = +0; % #06 
process.calcite_metamorphism.Fe2        = +0; % #07 
process.calcite_metamorphism.SiO2_aq    = +0; % #08 
process.calcite_metamorphism.O2         = +0; % #09 
process.calcite_metamorphism.SO4        = +0; % #10 
process.calcite_metamorphism.H2S        = +0; % #11 
process.calcite_metamorphism.Cl         = +0; % #12 
process.calcite_metamorphism.N2         = +0; % #13 
process.calcite_metamorphism.NH4        = +0; % #14 
process.calcite_metamorphism.NO3        = +0; % #15 
process.calcite_metamorphism.H2O        = +0; % #16 
process.calcite_metamorphism.CaCO3      = -1; % #17 
process.calcite_metamorphism.CaMgCO32   = +0; % #18 
process.calcite_metamorphism.FeCO3      = +0; % #19 
process.calcite_metamorphism.CaSiO3     = +1; % #20 
process.calcite_metamorphism.MgSiO3     = +0; % #21 
process.calcite_metamorphism.Na2SiO3    = +0; % #22 
process.calcite_metamorphism.K2SiO3     = +0; % #23 
process.calcite_metamorphism.FeSiO3     = +0; % #24 
process.calcite_metamorphism.SiO2_solid = -1; % #25 
process.calcite_metamorphism.CH2O       = +0; % #26 
process.calcite_metamorphism.FeS2       = +0; % #27 
process.calcite_metamorphism.Fe2O3      = +0; % #28 
process.calcite_metamorphism.CaSO4_2H2O = +0; % #29 
process.calcite_metamorphism.NaCl       = +0; % #30 
process.calcite_metamorphism.mantle_CO2 = +0; % #31 
process.calcite_metamorphism.mantle_HCl = +0; % #32 
process.calcite_metamorphism.mantle_H2S = +0; % #33 


% reaction #5: dolomite metamorphism
process.dolomite_metamorphism.ALK        = +0; % #01 
process.dolomite_metamorphism.FIC        = +2; % #02
process.dolomite_metamorphism.Ca         = +0; % #03 
process.dolomite_metamorphism.Mg         = +0; % #04
process.dolomite_metamorphism.Na         = +0; % #05 
process.dolomite_metamorphism.K          = +0; % #06 
process.dolomite_metamorphism.Fe2        = +0; % #07 
process.dolomite_metamorphism.SiO2_aq    = +0; % #08 
process.dolomite_metamorphism.O2         = +0; % #09 
process.dolomite_metamorphism.SO4        = +0; % #10 
process.dolomite_metamorphism.H2S        = +0; % #11 
process.dolomite_metamorphism.Cl         = +0; % #12 
process.dolomite_metamorphism.N2         = +0; % #13 
process.dolomite_metamorphism.NH4        = +0; % #14 
process.dolomite_metamorphism.NO3        = +0; % #15 
process.dolomite_metamorphism.H2O        = +0; % #16 
process.dolomite_metamorphism.CaCO3      = +0; % #17 
process.dolomite_metamorphism.CaMgCO32   = -1; % #18 
process.dolomite_metamorphism.FeCO3      = +0; % #19 
process.dolomite_metamorphism.CaSiO3     = +1; % #20 
process.dolomite_metamorphism.MgSiO3     = +1; % #21 
process.dolomite_metamorphism.Na2SiO3    = +0; % #22 
process.dolomite_metamorphism.K2SiO3     = +0; % #23 
process.dolomite_metamorphism.FeSiO3     = +0; % #24 
process.dolomite_metamorphism.SiO2_solid = -2; % #25 
process.dolomite_metamorphism.CH2O       = +0; % #26 
process.dolomite_metamorphism.FeS2       = +0; % #27 
process.dolomite_metamorphism.Fe2O3      = +0; % #28 
process.dolomite_metamorphism.CaSO4_2H2O = +0; % #29 
process.dolomite_metamorphism.NaCl       = +0; % #30 
process.dolomite_metamorphism.mantle_CO2 = +0; % #31 
process.dolomite_metamorphism.mantle_HCl = +0; % #32 
process.dolomite_metamorphism.mantle_H2S = +0; % #33 


% reaction #6: siderite metamorphism
process.siderite_metamorphism.ALK        = +0; % #01 
process.siderite_metamorphism.FIC        = +1; % #02
process.siderite_metamorphism.Ca         = +0; % #03 
process.siderite_metamorphism.Mg         = +0; % #04 
process.siderite_metamorphism.Na         = +0; % #05 
process.siderite_metamorphism.K          = +0; % #06 
process.siderite_metamorphism.Fe2        = +0; % #07 
process.siderite_metamorphism.SiO2_aq    = +0; % #08 
process.siderite_metamorphism.O2         = +0; % #09 
process.siderite_metamorphism.SO4        = +0; % #10 
process.siderite_metamorphism.H2S        = +0; % #11 
process.siderite_metamorphism.Cl         = +0; % #12 
process.siderite_metamorphism.N2         = +0; % #13 
process.siderite_metamorphism.NH4        = +0; % #14 
process.siderite_metamorphism.NO3        = +0; % #15 
process.siderite_metamorphism.H2O        = +0; % #16 
process.siderite_metamorphism.CaCO3      = +0; % #17 
process.siderite_metamorphism.CaMgCO32   = +0; % #18 
process.siderite_metamorphism.FeCO3      = -1; % #19 
process.siderite_metamorphism.CaSiO3     = +0; % #20 
process.siderite_metamorphism.MgSiO3     = +0; % #21 
process.siderite_metamorphism.Na2SiO3    = +0; % #22 
process.siderite_metamorphism.K2SiO3     = +0; % #23 
process.siderite_metamorphism.FeSiO3     = +1; % #24 
process.siderite_metamorphism.SiO2_solid = -1; % #25 
process.siderite_metamorphism.CH2O       = +0; % #26 
process.siderite_metamorphism.FeS2       = +0; % #27 
process.siderite_metamorphism.Fe2O3      = +0; % #28 
process.siderite_metamorphism.CaSO4_2H2O = +0; % #29 
process.siderite_metamorphism.NaCl       = +0; % #30 
process.siderite_metamorphism.mantle_CO2 = +0; % #31 
process.siderite_metamorphism.mantle_HCl = +0; % #32 
process.siderite_metamorphism.mantle_H2S = +0; % #33 


% reaction #7: Ca-silicate weathering
process.Ca_silicate_weathering.ALK        = +2; % #01 
process.Ca_silicate_weathering.FIC        = +0; % #02
process.Ca_silicate_weathering.Ca         = +1; % #03 
process.Ca_silicate_weathering.Mg         = +0; % #04
process.Ca_silicate_weathering.Na         = +0; % #05
process.Ca_silicate_weathering.K          = +0; % #06
process.Ca_silicate_weathering.Fe2        = +0; % #07
process.Ca_silicate_weathering.SiO2_aq    = +1; % #08
process.Ca_silicate_weathering.O2         = +0; % #09
process.Ca_silicate_weathering.SO4        = +0; % #10
process.Ca_silicate_weathering.H2S        = +0; % #11
process.Ca_silicate_weathering.Cl         = +0; % #12
process.Ca_silicate_weathering.N2         = +0; % #13
process.Ca_silicate_weathering.NH4        = +0; % #14
process.Ca_silicate_weathering.NO3        = +0; % #15
process.Ca_silicate_weathering.H2O        = +1; % #16
process.Ca_silicate_weathering.CaCO3      = +0; % #17
process.Ca_silicate_weathering.CaMgCO32   = +0; % #18
process.Ca_silicate_weathering.FeCO3      = +0; % #19
process.Ca_silicate_weathering.CaSiO3     = -1; % #20
process.Ca_silicate_weathering.MgSiO3     = +0; % #21
process.Ca_silicate_weathering.Na2SiO3    = +0; % #22
process.Ca_silicate_weathering.K2SiO3     = +0; % #23
process.Ca_silicate_weathering.FeSiO3     = +0; % #24
process.Ca_silicate_weathering.SiO2_solid = +0; % #25
process.Ca_silicate_weathering.CH2O       = +0; % #26
process.Ca_silicate_weathering.FeS2       = +0; % #27
process.Ca_silicate_weathering.Fe2O3      = +0; % #28
process.Ca_silicate_weathering.CaSO4_2H2O = +0; % #29
process.Ca_silicate_weathering.NaCl       = +0; % #30
process.Ca_silicate_weathering.mantle_CO2 = +0; % #31
process.Ca_silicate_weathering.mantle_HCl = +0; % #32
process.Ca_silicate_weathering.mantle_H2S = +0; % #33


% reaction #8: Mg-silicate weathering
process.Mg_silicate_weathering.ALK        = +2; % #01 
process.Mg_silicate_weathering.FIC        = +0; % #02
process.Mg_silicate_weathering.Ca         = +0; % #03
process.Mg_silicate_weathering.Mg         = +1; % #04 
process.Mg_silicate_weathering.Na         = +0; % #05
process.Mg_silicate_weathering.K          = +0; % #06
process.Mg_silicate_weathering.Fe2        = +0; % #07
process.Mg_silicate_weathering.SiO2_aq    = +1; % #08
process.Mg_silicate_weathering.O2         = +0; % #09
process.Mg_silicate_weathering.SO4        = +0; % #10
process.Mg_silicate_weathering.H2S        = +0; % #11
process.Mg_silicate_weathering.Cl         = +0; % #12
process.Mg_silicate_weathering.N2         = +0; % #13
process.Mg_silicate_weathering.NH4        = +0; % #14
process.Mg_silicate_weathering.NO3        = +0; % #15
process.Mg_silicate_weathering.H2O        = +1; % #16
process.Mg_silicate_weathering.CaCO3      = +0; % #17
process.Mg_silicate_weathering.CaMgCO32   = +0; % #18
process.Mg_silicate_weathering.FeCO3      = +0; % #19
process.Mg_silicate_weathering.CaSiO3     = +0; % #20
process.Mg_silicate_weathering.MgSiO3     = -1; % #21
process.Mg_silicate_weathering.Na2SiO3    = +0; % #22
process.Mg_silicate_weathering.K2SiO3     = +0; % #23
process.Mg_silicate_weathering.FeSiO3     = +0; % #24
process.Mg_silicate_weathering.SiO2_solid = +0; % #25
process.Mg_silicate_weathering.CH2O       = +0; % #26
process.Mg_silicate_weathering.FeS2       = +0; % #27
process.Mg_silicate_weathering.Fe2O3      = +0; % #28
process.Mg_silicate_weathering.CaSO4_2H2O = +0; % #29
process.Mg_silicate_weathering.NaCl       = +0; % #30
process.Mg_silicate_weathering.mantle_CO2 = +0; % #31
process.Mg_silicate_weathering.mantle_HCl = +0; % #32
process.Mg_silicate_weathering.mantle_H2S = +0; % #33


% reaction #9: Na-silicate weathering
process.Na_silicate_weathering.ALK        = +2; % #01 
process.Na_silicate_weathering.FIC        = +0; % #02
process.Na_silicate_weathering.Ca         = +0; % #03 
process.Na_silicate_weathering.Mg         = +0; % #04 
process.Na_silicate_weathering.Na         = +2; % #05 
process.Na_silicate_weathering.K          = +0; % #06 
process.Na_silicate_weathering.Fe2        = +0; % #07 
process.Na_silicate_weathering.SiO2_aq    = +1; % #08 
process.Na_silicate_weathering.O2         = +0; % #09 
process.Na_silicate_weathering.SO4        = +0; % #10 
process.Na_silicate_weathering.H2S        = +0; % #11 
process.Na_silicate_weathering.Cl         = +0; % #12 
process.Na_silicate_weathering.N2         = +0; % #13 
process.Na_silicate_weathering.NH4        = +0; % #14 
process.Na_silicate_weathering.NO3        = +0; % #15 
process.Na_silicate_weathering.H2O        = +1; % #16 
process.Na_silicate_weathering.CaCO3      = +0; % #17 
process.Na_silicate_weathering.CaMgCO32   = +0; % #18 
process.Na_silicate_weathering.FeCO3      = +0; % #19 
process.Na_silicate_weathering.CaSiO3     = +0; % #20 
process.Na_silicate_weathering.MgSiO3     = +0; % #21 
process.Na_silicate_weathering.Na2SiO3    = -1; % #22 
process.Na_silicate_weathering.K2SiO3     = +0; % #23 
process.Na_silicate_weathering.FeSiO3     = +0; % #24 
process.Na_silicate_weathering.SiO2_solid = +0; % #25 
process.Na_silicate_weathering.CH2O       = +0; % #26 
process.Na_silicate_weathering.FeS2       = +0; % #27 
process.Na_silicate_weathering.Fe2O3      = +0; % #28 
process.Na_silicate_weathering.CaSO4_2H2O = +0; % #29 
process.Na_silicate_weathering.NaCl       = +0; % #30 
process.Na_silicate_weathering.mantle_CO2 = +0; % #31 
process.Na_silicate_weathering.mantle_HCl = +0; % #32 
process.Na_silicate_weathering.mantle_H2S = +0; % #33 


% reaction #10: K-silicate weathering
process.K_silicate_weathering.ALK        = +2; % #01 
process.K_silicate_weathering.FIC        = +0; % #02
process.K_silicate_weathering.Ca         = +0; % #03 
process.K_silicate_weathering.Mg         = +0; % #04
process.K_silicate_weathering.Na         = +0; % #05
process.K_silicate_weathering.K          = +2; % #06 
process.K_silicate_weathering.Fe2        = +0; % #07 
process.K_silicate_weathering.SiO2_aq    = +1; % #08 
process.K_silicate_weathering.O2         = +0; % #09 
process.K_silicate_weathering.SO4        = +0; % #10 
process.K_silicate_weathering.H2S        = +0; % #11 
process.K_silicate_weathering.Cl         = +0; % #12 
process.K_silicate_weathering.N2         = +0; % #13 
process.K_silicate_weathering.NH4        = +0; % #14 
process.K_silicate_weathering.NO3        = +0; % #15 
process.K_silicate_weathering.H2O        = +1; % #16 
process.K_silicate_weathering.CaCO3      = +0; % #17 
process.K_silicate_weathering.CaMgCO32   = +0; % #18 
process.K_silicate_weathering.FeCO3      = +0; % #19 
process.K_silicate_weathering.CaSiO3     = +0; % #20 
process.K_silicate_weathering.MgSiO3     = +0; % #21 
process.K_silicate_weathering.Na2SiO3    = +0; % #22 
process.K_silicate_weathering.K2SiO3     = -1; % #23 
process.K_silicate_weathering.FeSiO3     = +0; % #24 
process.K_silicate_weathering.SiO2_solid = +0; % #25 
process.K_silicate_weathering.CH2O       = +0; % #26 
process.K_silicate_weathering.FeS2       = +0; % #27 
process.K_silicate_weathering.Fe2O3      = +0; % #28 
process.K_silicate_weathering.CaSO4_2H2O = +0; % #29 
process.K_silicate_weathering.NaCl       = +0; % #30 
process.K_silicate_weathering.mantle_CO2 = +0; % #31 
process.K_silicate_weathering.mantle_HCl = +0; % #32 
process.K_silicate_weathering.mantle_H2S = +0; % #33 


% reaction #11: Fe-silicate weathering
process.Fe_silicate_weathering.ALK        = +2; % #01 
process.Fe_silicate_weathering.FIC        = +0; % #02
process.Fe_silicate_weathering.Ca         = +0; % #03
process.Fe_silicate_weathering.Mg         = +0; % #04 
process.Fe_silicate_weathering.Na         = +0; % #05
process.Fe_silicate_weathering.K          = +0; % #06
process.Fe_silicate_weathering.Fe2        = +1; % #07
process.Fe_silicate_weathering.SiO2_aq    = +1; % #08
process.Fe_silicate_weathering.O2         = +0; % #09
process.Fe_silicate_weathering.SO4        = +0; % #10
process.Fe_silicate_weathering.H2S        = +0; % #11
process.Fe_silicate_weathering.Cl         = +0; % #12
process.Fe_silicate_weathering.N2         = +0; % #13
process.Fe_silicate_weathering.NH4        = +0; % #14
process.Fe_silicate_weathering.NO3        = +0; % #15
process.Fe_silicate_weathering.H2O        = +1; % #16
process.Fe_silicate_weathering.CaCO3      = +0; % #17
process.Fe_silicate_weathering.CaMgCO32   = +0; % #18
process.Fe_silicate_weathering.FeCO3      = +0; % #19
process.Fe_silicate_weathering.CaSiO3     = +0; % #20
process.Fe_silicate_weathering.MgSiO3     = +0; % #21
process.Fe_silicate_weathering.Na2SiO3    = +0; % #22
process.Fe_silicate_weathering.K2SiO3     = +0; % #23
process.Fe_silicate_weathering.FeSiO3     = -1; % #24
process.Fe_silicate_weathering.SiO2_solid = +0; % #25
process.Fe_silicate_weathering.CH2O       = +0; % #26
process.Fe_silicate_weathering.FeS2       = +0; % #27
process.Fe_silicate_weathering.Fe2O3      = +0; % #28
process.Fe_silicate_weathering.CaSO4_2H2O = +0; % #29
process.Fe_silicate_weathering.NaCl       = +0; % #30
process.Fe_silicate_weathering.mantle_CO2 = +0; % #31
process.Fe_silicate_weathering.mantle_HCl = +0; % #32
process.Fe_silicate_weathering.mantle_H2S = +0; % #33


% reaction #12: calcite weathering
process.calcite_weathering.ALK        = +2; % #01 
process.calcite_weathering.FIC        = +1; % #02
process.calcite_weathering.Ca         = +1; % #03
process.calcite_weathering.Mg         = +0; % #04
process.calcite_weathering.Na         = +0; % #05
process.calcite_weathering.K          = +0; % #06
process.calcite_weathering.Fe2        = +0; % #07
process.calcite_weathering.SiO2_aq    = +0; % #08
process.calcite_weathering.O2         = +0; % #09
process.calcite_weathering.SO4        = +0; % #10
process.calcite_weathering.H2S        = +0; % #11
process.calcite_weathering.Cl         = +0; % #12
process.calcite_weathering.N2         = +0; % #13
process.calcite_weathering.NH4        = +0; % #14
process.calcite_weathering.NO3        = +0; % #15
process.calcite_weathering.H2O        = +1; % #16
process.calcite_weathering.CaCO3      = -1; % #17
process.calcite_weathering.CaMgCO32   = +0; % #18
process.calcite_weathering.FeCO3      = +0; % #19
process.calcite_weathering.CaSiO3     = +0; % #20
process.calcite_weathering.MgSiO3     = +0; % #21
process.calcite_weathering.Na2SiO3    = +0; % #22
process.calcite_weathering.K2SiO3     = +0; % #23
process.calcite_weathering.FeSiO3     = +0; % #24
process.calcite_weathering.SiO2_solid = +0; % #25
process.calcite_weathering.CH2O       = +0; % #26
process.calcite_weathering.FeS2       = +0; % #27
process.calcite_weathering.Fe2O3      = +0; % #28
process.calcite_weathering.CaSO4_2H2O = +0; % #29
process.calcite_weathering.NaCl       = +0; % #30
process.calcite_weathering.mantle_CO2 = +0; % #31
process.calcite_weathering.mantle_HCl = +0; % #32
process.calcite_weathering.mantle_H2S = +0; % #33


% reaction #13: dolomite weathering
process.dolomite_weathering.ALK        = +4; % #01 
process.dolomite_weathering.FIC        = +2; % #02
process.dolomite_weathering.Ca         = +1; % #03 
process.dolomite_weathering.Mg         = +1; % #04
process.dolomite_weathering.Na         = +0; % #05
process.dolomite_weathering.K          = +0; % #06
process.dolomite_weathering.Fe2        = +0; % #07
process.dolomite_weathering.SiO2_aq    = +0; % #08
process.dolomite_weathering.O2         = +0; % #09
process.dolomite_weathering.SO4        = +0; % #10
process.dolomite_weathering.H2S        = +0; % #11
process.dolomite_weathering.Cl         = +0; % #12
process.dolomite_weathering.N2         = +0; % #13
process.dolomite_weathering.NH4        = +0; % #14
process.dolomite_weathering.NO3        = +0; % #15
process.dolomite_weathering.H2O        = +2; % #16
process.dolomite_weathering.CaCO3      = +0; % #17
process.dolomite_weathering.CaMgCO32   = -1; % #18
process.dolomite_weathering.FeCO3      = +0; % #19
process.dolomite_weathering.CaSiO3     = +0; % #20
process.dolomite_weathering.MgSiO3     = +0; % #21
process.dolomite_weathering.Na2SiO3    = +0; % #22
process.dolomite_weathering.K2SiO3     = +0; % #23
process.dolomite_weathering.FeSiO3     = +0; % #24
process.dolomite_weathering.SiO2_solid = +0; % #25
process.dolomite_weathering.CH2O       = +0; % #26
process.dolomite_weathering.FeS2       = +0; % #27
process.dolomite_weathering.Fe2O3      = +0; % #28
process.dolomite_weathering.CaSO4_2H2O = +0; % #29
process.dolomite_weathering.NaCl       = +0; % #30
process.dolomite_weathering.mantle_CO2 = +0; % #31
process.dolomite_weathering.mantle_HCl = +0; % #32
process.dolomite_weathering.mantle_H2S = +0; % #33


% reaction #14: siderite weathering
process.siderite_weathering.ALK        = +2; % #01 
process.siderite_weathering.FIC        = +1; % #02
process.siderite_weathering.Ca         = +0; % #03
process.siderite_weathering.Mg         = +0; % #04
process.siderite_weathering.Na         = +0; % #05
process.siderite_weathering.K          = +0; % #06
process.siderite_weathering.Fe2        = +1; % #07
process.siderite_weathering.SiO2_aq    = +0; % #08
process.siderite_weathering.O2         = +0; % #09
process.siderite_weathering.SO4        = +0; % #10
process.siderite_weathering.H2S        = +0; % #11
process.siderite_weathering.Cl         = +0; % #12
process.siderite_weathering.N2         = +0; % #13
process.siderite_weathering.NH4        = +0; % #14
process.siderite_weathering.NO3        = +0; % #15
process.siderite_weathering.H2O        = +1; % #16
process.siderite_weathering.CaCO3      = +0; % #17
process.siderite_weathering.CaMgCO32   = +0; % #18
process.siderite_weathering.FeCO3      = -1; % #19
process.siderite_weathering.CaSiO3     = +0; % #20
process.siderite_weathering.MgSiO3     = +0; % #21
process.siderite_weathering.Na2SiO3    = +0; % #22
process.siderite_weathering.K2SiO3     = +0; % #23
process.siderite_weathering.FeSiO3     = +0; % #24
process.siderite_weathering.SiO2_solid = +0; % #25
process.siderite_weathering.CH2O       = +0; % #26
process.siderite_weathering.FeS2       = +0; % #27
process.siderite_weathering.Fe2O3      = +0; % #28
process.siderite_weathering.CaSO4_2H2O = +0; % #29
process.siderite_weathering.NaCl       = +0; % #30
process.siderite_weathering.mantle_CO2 = +0; % #31
process.siderite_weathering.mantle_HCl = +0; % #32
process.siderite_weathering.mantle_H2S = +0; % #33


% reaction #15: silica weathering
process.silica_weathering.ALK        = +0; % #01 
process.silica_weathering.FIC        = +0; % #02
process.silica_weathering.Ca         = +0; % #03
process.silica_weathering.Mg         = +0; % #04
process.silica_weathering.Na         = +0; % #05
process.silica_weathering.K          = +0; % #06
process.silica_weathering.Fe2        = +0; % #07
process.silica_weathering.SiO2_aq    = +1; % #08
process.silica_weathering.O2         = +0; % #09
process.silica_weathering.SO4        = +0; % #10 
process.silica_weathering.H2S        = +0; % #11
process.silica_weathering.Cl         = +0; % #12
process.silica_weathering.N2         = +0; % #13
process.silica_weathering.NH4        = +0; % #14
process.silica_weathering.NO3        = +0; % #15
process.silica_weathering.H2O        = +0; % #16
process.silica_weathering.CaCO3      = +0; % #17
process.silica_weathering.CaMgCO32   = +0; % #18
process.silica_weathering.FeCO3      = +0; % #19
process.silica_weathering.CaSiO3     = +0; % #20
process.silica_weathering.MgSiO3     = +0; % #21
process.silica_weathering.Na2SiO3    = +0; % #22
process.silica_weathering.K2SiO3     = +0; % #23
process.silica_weathering.FeSiO3     = +0; % #24
process.silica_weathering.SiO2_solid = -1; % #25
process.silica_weathering.CH2O       = +0; % #26
process.silica_weathering.FeS2       = +0; % #27
process.silica_weathering.Fe2O3      = +0; % #28
process.silica_weathering.CaSO4_2H2O = +0; % #29
process.silica_weathering.NaCl       = +0; % #30
process.silica_weathering.mantle_CO2 = +0; % #31
process.silica_weathering.mantle_HCl = +0; % #32
process.silica_weathering.mantle_H2S = +0; % #33


% reaction #16: Mg-reverse weathering
process.Mg_reverse_weathering.ALK        = -2; % #01 
process.Mg_reverse_weathering.FIC        = +0; % #02
process.Mg_reverse_weathering.Ca         = +0; % #03 
process.Mg_reverse_weathering.Mg         = -1; % #04
process.Mg_reverse_weathering.Na         = +0; % #05
process.Mg_reverse_weathering.K          = +0; % #06
process.Mg_reverse_weathering.Fe2        = +0; % #07
process.Mg_reverse_weathering.SiO2_aq    = -1; % #08
process.Mg_reverse_weathering.O2         = +0; % #09
process.Mg_reverse_weathering.SO4        = +0; % #10
process.Mg_reverse_weathering.H2S        = +0; % #11
process.Mg_reverse_weathering.Cl         = +0; % #12
process.Mg_reverse_weathering.N2         = +0; % #13
process.Mg_reverse_weathering.NH4        = +0; % #14
process.Mg_reverse_weathering.NO3        = +0; % #15
process.Mg_reverse_weathering.H2O        = -1; % #16
process.Mg_reverse_weathering.CaCO3      = +0; % #17
process.Mg_reverse_weathering.CaMgCO32   = +0; % #18
process.Mg_reverse_weathering.FeCO3      = +0; % #19
process.Mg_reverse_weathering.CaSiO3     = +0; % #20
process.Mg_reverse_weathering.MgSiO3     = +1; % #21
process.Mg_reverse_weathering.Na2SiO3    = +0; % #22
process.Mg_reverse_weathering.K2SiO3     = +0; % #23
process.Mg_reverse_weathering.FeSiO3     = +0; % #24
process.Mg_reverse_weathering.SiO2_solid = +0; % #25
process.Mg_reverse_weathering.CH2O       = +0; % #26
process.Mg_reverse_weathering.FeS2       = +0; % #27
process.Mg_reverse_weathering.Fe2O3      = +0; % #28
process.Mg_reverse_weathering.CaSO4_2H2O = +0; % #29
process.Mg_reverse_weathering.NaCl       = +0; % #30
process.Mg_reverse_weathering.mantle_CO2 = +0; % #31
process.Mg_reverse_weathering.mantle_HCl = +0; % #32
process.Mg_reverse_weathering.mantle_H2S = +0; % #33


% reaction #17: Na-reverse weathering
process.Na_reverse_weathering.ALK        = -2; % #01 
process.Na_reverse_weathering.FIC        = +0; % #02
process.Na_reverse_weathering.Ca         = +0; % #03
process.Na_reverse_weathering.Mg         = +0; % #04
process.Na_reverse_weathering.Na         = -2; % #05
process.Na_reverse_weathering.K          = +0; % #06
process.Na_reverse_weathering.Fe2        = +0; % #07
process.Na_reverse_weathering.SiO2_aq    = -1; % #08
process.Na_reverse_weathering.O2         = +0; % #09
process.Na_reverse_weathering.SO4        = +0; % #10
process.Na_reverse_weathering.H2S        = +0; % #11
process.Na_reverse_weathering.Cl         = +0; % #12
process.Na_reverse_weathering.N2         = +0; % #13
process.Na_reverse_weathering.NH4        = +0; % #14
process.Na_reverse_weathering.NO3        = +0; % #15
process.Na_reverse_weathering.H2O        = -1; % #16
process.Na_reverse_weathering.CaCO3      = +0; % #17
process.Na_reverse_weathering.CaMgCO32   = +0; % #18
process.Na_reverse_weathering.FeCO3      = +0; % #19
process.Na_reverse_weathering.CaSiO3     = +0; % #20
process.Na_reverse_weathering.MgSiO3     = +0; % #21
process.Na_reverse_weathering.Na2SiO3    = +1; % #22
process.Na_reverse_weathering.K2SiO3     = +0; % #23
process.Na_reverse_weathering.FeSiO3     = +0; % #24
process.Na_reverse_weathering.SiO2_solid = +0; % #25
process.Na_reverse_weathering.CH2O       = +0; % #26
process.Na_reverse_weathering.FeS2       = +0; % #27
process.Na_reverse_weathering.Fe2O3      = +0; % #28
process.Na_reverse_weathering.CaSO4_2H2O = +0; % #29
process.Na_reverse_weathering.NaCl       = +0; % #30
process.Na_reverse_weathering.mantle_CO2 = +0; % #31
process.Na_reverse_weathering.mantle_HCl = +0; % #32
process.Na_reverse_weathering.mantle_H2S = +0; % #33

% reaction #18: K-reverse weathering
process.K_reverse_weathering.ALK        = -2; % #01  
process.K_reverse_weathering.FIC        = +0; % #02
process.K_reverse_weathering.Ca         = +0; % #03
process.K_reverse_weathering.Mg         = +0; % #04
process.K_reverse_weathering.Na         = +0; % #05
process.K_reverse_weathering.K          = -2; % #06
process.K_reverse_weathering.Fe2        = +0; % #07
process.K_reverse_weathering.SiO2_aq    = -1; % #08
process.K_reverse_weathering.O2         = +0; % #09
process.K_reverse_weathering.SO4        = +0; % #10
process.K_reverse_weathering.H2S        = +0; % #11
process.K_reverse_weathering.Cl         = +0; % #12
process.K_reverse_weathering.N2         = +0; % #13
process.K_reverse_weathering.NH4        = +0; % #14
process.K_reverse_weathering.NO3        = +0; % #15
process.K_reverse_weathering.H2O        = -1; % #16
process.K_reverse_weathering.CaCO3      = +0; % #17
process.K_reverse_weathering.CaMgCO32   = +0; % #18
process.K_reverse_weathering.FeCO3      = +0; % #19
process.K_reverse_weathering.CaSiO3     = +0; % #20
process.K_reverse_weathering.MgSiO3     = +0; % #21
process.K_reverse_weathering.Na2SiO3    = +0; % #22
process.K_reverse_weathering.K2SiO3     = +1; % #23
process.K_reverse_weathering.FeSiO3     = +0; % #24
process.K_reverse_weathering.SiO2_solid = +0; % #25
process.K_reverse_weathering.CH2O       = +0; % #26
process.K_reverse_weathering.FeS2       = +0; % #27
process.K_reverse_weathering.Fe2O3      = +0; % #28
process.K_reverse_weathering.CaSO4_2H2O = +0; % #29
process.K_reverse_weathering.NaCl       = +0; % #30
process.K_reverse_weathering.mantle_CO2 = +0; % #31
process.K_reverse_weathering.mantle_HCl = +0; % #32
process.K_reverse_weathering.mantle_H2S = +0; % #33


% reaction #19: Fe-reverse weathering
process.Fe_reverse_weathering.ALK        = -2; % #01  
process.Fe_reverse_weathering.FIC        = +0; % #02
process.Fe_reverse_weathering.Ca         = +0; % #03
process.Fe_reverse_weathering.Mg         = +0; % #04
process.Fe_reverse_weathering.Na         = +0; % #05
process.Fe_reverse_weathering.K          = +0; % #06
process.Fe_reverse_weathering.Fe2        = -1; % #07
process.Fe_reverse_weathering.SiO2_aq    = -1; % #08
process.Fe_reverse_weathering.O2         = +0; % #09
process.Fe_reverse_weathering.SO4        = +0; % #10
process.Fe_reverse_weathering.H2S        = +0; % #11
process.Fe_reverse_weathering.Cl         = +0; % #12
process.Fe_reverse_weathering.N2         = +0; % #13
process.Fe_reverse_weathering.NH4        = +0; % #14
process.Fe_reverse_weathering.NO3        = +0; % #15
process.Fe_reverse_weathering.H2O        = -1; % #16
process.Fe_reverse_weathering.CaCO3      = +0; % #17
process.Fe_reverse_weathering.CaMgCO32   = +0; % #18
process.Fe_reverse_weathering.FeCO3      = +0; % #19
process.Fe_reverse_weathering.CaSiO3     = +0; % #20
process.Fe_reverse_weathering.MgSiO3     = +0; % #21
process.Fe_reverse_weathering.Na2SiO3    = +0; % #22
process.Fe_reverse_weathering.K2SiO3     = +0; % #23
process.Fe_reverse_weathering.FeSiO3     = +1; % #24
process.Fe_reverse_weathering.SiO2_solid = +0; % #25
process.Fe_reverse_weathering.CH2O       = +0; % #26
process.Fe_reverse_weathering.FeS2       = +0; % #27
process.Fe_reverse_weathering.Fe2O3      = +0; % #28
process.Fe_reverse_weathering.CaSO4_2H2O = +0; % #29
process.Fe_reverse_weathering.NaCl       = +0; % #30
process.Fe_reverse_weathering.mantle_CO2 = +0; % #31
process.Fe_reverse_weathering.mantle_HCl = +0; % #32
process.Fe_reverse_weathering.mantle_H2S = +0; % #33


% reaction #20: silica formation
process.silica_formation.ALK        = +0; % #01  
process.silica_formation.FIC        = +0; % #02
process.silica_formation.Ca         = +0; % #03
process.silica_formation.Mg         = +0; % #04
process.silica_formation.Na         = +0; % #05
process.silica_formation.K          = +0; % #06
process.silica_formation.Fe2        = +0; % #07
process.silica_formation.SiO2_aq    = -1; % #08
process.silica_formation.O2         = +0; % #09
process.silica_formation.SO4        = +0; % #10
process.silica_formation.H2S        = +0; % #11
process.silica_formation.Cl         = +0; % #12
process.silica_formation.N2         = +0; % #13
process.silica_formation.NH4        = +0; % #14
process.silica_formation.NO3        = +0; % #15
process.silica_formation.H2O        = +0; % #16
process.silica_formation.CaCO3      = +0; % #17
process.silica_formation.CaMgCO32   = +0; % #18
process.silica_formation.FeCO3      = +0; % #19
process.silica_formation.CaSiO3     = +0; % #20
process.silica_formation.MgSiO3     = +0; % #21
process.silica_formation.Na2SiO3    = +0; % #22
process.silica_formation.K2SiO3     = +0; % #23
process.silica_formation.FeSiO3     = +0; % #24
process.silica_formation.SiO2_solid = +1; % #25
process.silica_formation.CH2O       = +0; % #26
process.silica_formation.FeS2       = +0; % #27
process.silica_formation.Fe2O3      = +0; % #28
process.silica_formation.CaSO4_2H2O = +0; % #29
process.silica_formation.NaCl       = +0; % #30
process.silica_formation.mantle_CO2 = +0; % #31
process.silica_formation.mantle_HCl = +0; % #32
process.silica_formation.mantle_H2S = +0; % #33


% reaction #21: calcite formation
process.calcite_formation.ALK        = -2; % #01 
process.calcite_formation.FIC        = -1; % #02
process.calcite_formation.Ca         = -1; % #03
process.calcite_formation.Mg         = +0; % #04
process.calcite_formation.Na         = +0; % #05
process.calcite_formation.K          = +0; % #06
process.calcite_formation.Fe2        = +0; % #07
process.calcite_formation.SiO2_aq    = +0; % #08
process.calcite_formation.O2         = +0; % #09
process.calcite_formation.SO4        = +0; % #10
process.calcite_formation.H2S        = +0; % #11
process.calcite_formation.Cl         = +0; % #12
process.calcite_formation.N2         = +0; % #13
process.calcite_formation.NH4        = +0; % #14
process.calcite_formation.NO3        = +0; % #15
process.calcite_formation.H2O        = -1; % #16
process.calcite_formation.CaCO3      = +1; % #17
process.calcite_formation.CaMgCO32   = +0; % #18
process.calcite_formation.FeCO3      = +0; % #19
process.calcite_formation.CaSiO3     = +0; % #20
process.calcite_formation.MgSiO3     = +0; % #21
process.calcite_formation.Na2SiO3    = +0; % #22
process.calcite_formation.K2SiO3     = +0; % #23
process.calcite_formation.FeSiO3     = +0; % #24
process.calcite_formation.SiO2_solid = +0; % #25
process.calcite_formation.CH2O       = +0; % #26
process.calcite_formation.FeS2       = +0; % #27
process.calcite_formation.Fe2O3      = +0; % #28
process.calcite_formation.CaSO4_2H2O = +0; % #29
process.calcite_formation.NaCl       = +0; % #30
process.calcite_formation.mantle_CO2 = +0; % #31
process.calcite_formation.mantle_HCl = +0; % #32
process.calcite_formation.mantle_H2S = +0; % #33


% reaction #22: dolomite formation
process.dolomite_formation.ALK        = -4; % #01 
process.dolomite_formation.FIC        = -2; % #02
process.dolomite_formation.Ca         = -1; % #03
process.dolomite_formation.Mg         = -1; % #04
process.dolomite_formation.Na         = +0; % #05
process.dolomite_formation.K          = +0; % #06
process.dolomite_formation.Fe2        = +0; % #07
process.dolomite_formation.SiO2_aq    = +0; % #08
process.dolomite_formation.O2         = +0; % #09
process.dolomite_formation.SO4        = +0; % #10
process.dolomite_formation.H2S        = +0; % #11
process.dolomite_formation.Cl         = +0; % #12
process.dolomite_formation.N2         = +0; % #13
process.dolomite_formation.NH4        = +0; % #14
process.dolomite_formation.NO3        = +0; % #15
process.dolomite_formation.H2O        = -2; % #16
process.dolomite_formation.CaCO3      = +0; % #17
process.dolomite_formation.CaMgCO32   = +1; % #18
process.dolomite_formation.FeCO3      = +0; % #19
process.dolomite_formation.CaSiO3     = +0; % #20
process.dolomite_formation.MgSiO3     = +0; % #21
process.dolomite_formation.Na2SiO3    = +0; % #22
process.dolomite_formation.K2SiO3     = +0; % #23
process.dolomite_formation.FeSiO3     = +0; % #24
process.dolomite_formation.SiO2_solid = +0; % #25
process.dolomite_formation.CH2O       = +0; % #26
process.dolomite_formation.FeS2       = +0; % #27
process.dolomite_formation.Fe2O3      = +0; % #28
process.dolomite_formation.CaSO4_2H2O = +0; % #29
process.dolomite_formation.NaCl       = +0; % #30
process.dolomite_formation.mantle_CO2 = +0; % #31
process.dolomite_formation.mantle_HCl = +0; % #32
process.dolomite_formation.mantle_H2S = +0; % #33


% reaction #23: siderite formation
process.siderite_formation.ALK        = -2; % #01 
process.siderite_formation.FIC        = -1; % #02
process.siderite_formation.Ca         = +0; % #03
process.siderite_formation.Mg         = +0; % #04 
process.siderite_formation.Na         = +0; % #05
process.siderite_formation.K          = +0; % #06
process.siderite_formation.Fe2        = -1; % #07
process.siderite_formation.SiO2_aq    = +0; % #08
process.siderite_formation.O2         = +0; % #09
process.siderite_formation.SO4        = +0; % #10
process.siderite_formation.H2S        = +0; % #11
process.siderite_formation.Cl         = +0; % #12
process.siderite_formation.N2         = +0; % #13
process.siderite_formation.NH4        = +0; % #14
process.siderite_formation.NO3        = +0; % #15
process.siderite_formation.H2O        = -1; % #16
process.siderite_formation.CaCO3      = +0; % #17
process.siderite_formation.CaMgCO32   = +0; % #18
process.siderite_formation.FeCO3      = +1; % #19
process.siderite_formation.CaSiO3     = +0; % #20
process.siderite_formation.MgSiO3     = +0; % #21
process.siderite_formation.Na2SiO3    = +0; % #22
process.siderite_formation.K2SiO3     = +0; % #23
process.siderite_formation.FeSiO3     = +0; % #24
process.siderite_formation.SiO2_solid = +0; % #25
process.siderite_formation.CH2O       = +0; % #26
process.siderite_formation.FeS2       = +0; % #27
process.siderite_formation.Fe2O3      = +0; % #28
process.siderite_formation.CaSO4_2H2O = +0; % #29
process.siderite_formation.NaCl       = +0; % #30
process.siderite_formation.mantle_CO2 = +0; % #31
process.siderite_formation.mantle_HCl = +0; % #32
process.siderite_formation.mantle_H2S = +0; % #33


% reaction #24: oxygenic photosynthesis
process.oxygenic_photosynthesis.ALK        = +0; % #01 
process.oxygenic_photosynthesis.FIC        = -1; % #02
process.oxygenic_photosynthesis.Ca         = +0; % #03
process.oxygenic_photosynthesis.Mg         = +0; % #04
process.oxygenic_photosynthesis.Na         = +0; % #05
process.oxygenic_photosynthesis.K          = +0; % #06
process.oxygenic_photosynthesis.Fe2        = +0; % #07
process.oxygenic_photosynthesis.SiO2_aq    = +0; % #08
process.oxygenic_photosynthesis.O2         = +1; % #09
process.oxygenic_photosynthesis.SO4        = +0; % #10
process.oxygenic_photosynthesis.H2S        = +0; % #11
process.oxygenic_photosynthesis.Cl         = +0; % #12
process.oxygenic_photosynthesis.N2         = +0; % #13
process.oxygenic_photosynthesis.NH4        = +0; % #14
process.oxygenic_photosynthesis.NO3        = +0; % #15
process.oxygenic_photosynthesis.H2O        = -1; % #16
process.oxygenic_photosynthesis.CaCO3      = +0; % #17
process.oxygenic_photosynthesis.CaMgCO32   = +0; % #18
process.oxygenic_photosynthesis.FeCO3      = +0; % #19
process.oxygenic_photosynthesis.CaSiO3     = +0; % #20
process.oxygenic_photosynthesis.MgSiO3     = +0; % #21
process.oxygenic_photosynthesis.Na2SiO3    = +0; % #22
process.oxygenic_photosynthesis.K2SiO3     = +0; % #23
process.oxygenic_photosynthesis.FeSiO3     = +0; % #24
process.oxygenic_photosynthesis.SiO2_solid = +0; % #25
process.oxygenic_photosynthesis.CH2O       = +1; % #26
process.oxygenic_photosynthesis.FeS2       = +0; % #27
process.oxygenic_photosynthesis.Fe2O3      = +0; % #28
process.oxygenic_photosynthesis.CaSO4_2H2O = +0; % #29
process.oxygenic_photosynthesis.NaCl       = +0; % #30
process.oxygenic_photosynthesis.mantle_CO2 = +0; % #31
process.oxygenic_photosynthesis.mantle_HCl = +0; % #32
process.oxygenic_photosynthesis.mantle_H2S = +0; % #33


% reaction #25: aerobic respiration
process.aerobic_respiration.ALK        = +0; % #01 
process.aerobic_respiration.FIC        = +1; % #02
process.aerobic_respiration.Ca         = +0; % #03
process.aerobic_respiration.Mg         = +0; % #04
process.aerobic_respiration.Na         = +0; % #05
process.aerobic_respiration.K          = +0; % #06
process.aerobic_respiration.Fe2        = +0; % #07
process.aerobic_respiration.SiO2_aq    = +0; % #08
process.aerobic_respiration.O2         = -1; % #09
process.aerobic_respiration.SO4        = +0; % #10
process.aerobic_respiration.H2S        = +0; % #11
process.aerobic_respiration.Cl         = +0; % #12
process.aerobic_respiration.N2         = +0; % #13
process.aerobic_respiration.NH4        = +0; % #14
process.aerobic_respiration.NO3        = +0; % #15
process.aerobic_respiration.H2O        = +1; % #16
process.aerobic_respiration.CaCO3      = +0; % #17
process.aerobic_respiration.CaMgCO32   = +0; % #18
process.aerobic_respiration.FeCO3      = +0; % #19
process.aerobic_respiration.CaSiO3     = +0; % #20
process.aerobic_respiration.MgSiO3     = +0; % #21
process.aerobic_respiration.Na2SiO3    = +0; % #22
process.aerobic_respiration.K2SiO3     = +0; % #23
process.aerobic_respiration.FeSiO3     = +0; % #24
process.aerobic_respiration.SiO2_solid = +0; % #25
process.aerobic_respiration.CH2O       = -1; % #26
process.aerobic_respiration.FeS2       = +0; % #27
process.aerobic_respiration.Fe2O3      = +0; % #28
process.aerobic_respiration.CaSO4_2H2O = +0; % #29
process.aerobic_respiration.NaCl       = +0; % #30
process.aerobic_respiration.mantle_CO2 = +0; % #31
process.aerobic_respiration.mantle_HCl = +0; % #32
process.aerobic_respiration.mantle_H2S = +0; % #33


% reaction #26: sulfide oxidation
process.sulfide_oxidation.ALK        = -2; % #01 
process.sulfide_oxidation.FIC        = +0; % #02
process.sulfide_oxidation.Ca         = +0; % #03
process.sulfide_oxidation.Mg         = +0; % #04
process.sulfide_oxidation.Na         = +0; % #05
process.sulfide_oxidation.K          = +0; % #06
process.sulfide_oxidation.Fe2        = +0; % #07
process.sulfide_oxidation.SiO2_aq    = +0; % #08
process.sulfide_oxidation.O2         = -2; % #09
process.sulfide_oxidation.SO4        = +1; % #10
process.sulfide_oxidation.H2S        = -1; % #11
process.sulfide_oxidation.Cl         = +0; % #12
process.sulfide_oxidation.N2         = +0; % #13
process.sulfide_oxidation.NH4        = +0; % #14
process.sulfide_oxidation.NO3        = +0; % #15
process.sulfide_oxidation.H2O        = +0; % #16
process.sulfide_oxidation.CaCO3      = +0; % #17
process.sulfide_oxidation.CaMgCO32   = +0; % #18
process.sulfide_oxidation.FeCO3      = +0; % #19
process.sulfide_oxidation.CaSiO3     = +0; % #20
process.sulfide_oxidation.MgSiO3     = +0; % #21
process.sulfide_oxidation.Na2SiO3    = +0; % #22
process.sulfide_oxidation.K2SiO3     = +0; % #23
process.sulfide_oxidation.FeSiO3     = +0; % #24
process.sulfide_oxidation.SiO2_solid = +0; % #25
process.sulfide_oxidation.CH2O       = +0; % #26
process.sulfide_oxidation.FeS2       = +0; % #27
process.sulfide_oxidation.Fe2O3      = +0; % #28
process.sulfide_oxidation.CaSO4_2H2O = +0; % #29
process.sulfide_oxidation.NaCl       = +0; % #30
process.sulfide_oxidation.mantle_CO2 = +0; % #31
process.sulfide_oxidation.mantle_HCl = +0; % #32
process.sulfide_oxidation.mantle_H2S = +0; % #33


% reaction #27: sulfate reduction
process.sulfate_reduction.ALK        = +2; % #01 
process.sulfate_reduction.FIC        = +2; % #02
process.sulfate_reduction.Ca         = +0; % #03 
process.sulfate_reduction.Mg         = +0; % #04
process.sulfate_reduction.Na         = +0; % #05
process.sulfate_reduction.K          = +0; % #06
process.sulfate_reduction.Fe2        = +0; % #07
process.sulfate_reduction.SiO2_aq    = +0; % #08
process.sulfate_reduction.O2         = +0; % #09
process.sulfate_reduction.SO4        = -1; % #10
process.sulfate_reduction.H2S        = +1; % #11
process.sulfate_reduction.Cl         = +0; % #12
process.sulfate_reduction.N2         = +0; % #13
process.sulfate_reduction.NH4        = +0; % #14
process.sulfate_reduction.NO3        = +0; % #15
process.sulfate_reduction.H2O        = +2; % #16
process.sulfate_reduction.CaCO3      = +0; % #17
process.sulfate_reduction.CaMgCO32   = +0; % #18
process.sulfate_reduction.FeCO3      = +0; % #19
process.sulfate_reduction.CaSiO3     = +0; % #20
process.sulfate_reduction.MgSiO3     = +0; % #21
process.sulfate_reduction.Na2SiO3    = +0; % #22
process.sulfate_reduction.K2SiO3     = +0; % #23
process.sulfate_reduction.FeSiO3     = +0; % #24
process.sulfate_reduction.SiO2_solid = +0; % #25
process.sulfate_reduction.CH2O       = -2; % #26
process.sulfate_reduction.FeS2       = +0; % #27
process.sulfate_reduction.Fe2O3      = +0; % #28
process.sulfate_reduction.CaSO4_2H2O = +0; % #29
process.sulfate_reduction.NaCl       = +0; % #30
process.sulfate_reduction.mantle_CO2 = +0; % #31
process.sulfate_reduction.mantle_HCl = +0; % #32
process.sulfate_reduction.mantle_H2S = +0; % #33


% reaction #28: ferrous iron oxidation
process.ferrous_iron_oxidation.ALK        = -8; % #01 
process.ferrous_iron_oxidation.FIC        = +0; % #02
process.ferrous_iron_oxidation.Ca         = +0; % #03
process.ferrous_iron_oxidation.Mg         = +0; % #04
process.ferrous_iron_oxidation.Na         = +0; % #05
process.ferrous_iron_oxidation.K          = +0; % #06
process.ferrous_iron_oxidation.Fe2        = -4; % #07
process.ferrous_iron_oxidation.SiO2_aq    = +0; % #08
process.ferrous_iron_oxidation.O2         = -1; % #09
process.ferrous_iron_oxidation.SO4        = +0; % #10
process.ferrous_iron_oxidation.H2S        = +0; % #11
process.ferrous_iron_oxidation.Cl         = +0; % #12
process.ferrous_iron_oxidation.N2         = +0; % #13
process.ferrous_iron_oxidation.NH4        = +0; % #14
process.ferrous_iron_oxidation.NO3        = +0; % #15
process.ferrous_iron_oxidation.H2O        = -4; % #16
process.ferrous_iron_oxidation.CaCO3      = +0; % #17
process.ferrous_iron_oxidation.CaMgCO32   = +0; % #18
process.ferrous_iron_oxidation.FeCO3      = +0; % #19
process.ferrous_iron_oxidation.CaSiO3     = +0; % #20
process.ferrous_iron_oxidation.MgSiO3     = +0; % #21
process.ferrous_iron_oxidation.Na2SiO3    = +0; % #22
process.ferrous_iron_oxidation.K2SiO3     = +0; % #23
process.ferrous_iron_oxidation.FeSiO3     = +0; % #24
process.ferrous_iron_oxidation.SiO2_solid = +0; % #25
process.ferrous_iron_oxidation.CH2O       = +0; % #26
process.ferrous_iron_oxidation.FeS2       = +0; % #27
process.ferrous_iron_oxidation.Fe2O3      = +2; % #28
process.ferrous_iron_oxidation.CaSO4_2H2O = +0; % #29
process.ferrous_iron_oxidation.NaCl       = +0; % #30
process.ferrous_iron_oxidation.mantle_CO2 = +0; % #31
process.ferrous_iron_oxidation.mantle_HCl = +0; % #32
process.ferrous_iron_oxidation.mantle_H2S = +0; % #33


% reaction #29: ferric iron reduction
process.ferric_iron_reduction.ALK        = +8; % #01 
process.ferric_iron_reduction.FIC        = +1; % #02
process.ferric_iron_reduction.Ca         = +0; % #03
process.ferric_iron_reduction.Mg         = +0; % #04
process.ferric_iron_reduction.Na         = +0; % #05
process.ferric_iron_reduction.K          = +0; % #06
process.ferric_iron_reduction.Fe2        = +4; % #07
process.ferric_iron_reduction.SiO2_aq    = +0; % #08
process.ferric_iron_reduction.O2         = +0; % #09
process.ferric_iron_reduction.SO4        = +0; % #10
process.ferric_iron_reduction.H2S        = +0; % #11
process.ferric_iron_reduction.Cl         = +0; % #12
process.ferric_iron_reduction.N2         = +0; % #13
process.ferric_iron_reduction.NH4        = +0; % #14
process.ferric_iron_reduction.NO3        = +0; % #15
process.ferric_iron_reduction.H2O        = +5; % #16
process.ferric_iron_reduction.CaCO3      = +0; % #17
process.ferric_iron_reduction.CaMgCO32   = +0; % #18
process.ferric_iron_reduction.FeCO3      = +0; % #19
process.ferric_iron_reduction.CaSiO3     = +0; % #20
process.ferric_iron_reduction.MgSiO3     = +0; % #21
process.ferric_iron_reduction.Na2SiO3    = +0; % #22
process.ferric_iron_reduction.K2SiO3     = +0; % #23
process.ferric_iron_reduction.FeSiO3     = +0; % #24
process.ferric_iron_reduction.SiO2_solid = +0; % #25
process.ferric_iron_reduction.CH2O       = -1; % #26
process.ferric_iron_reduction.FeS2       = +0; % #27
process.ferric_iron_reduction.Fe2O3      = -2; % #28
process.ferric_iron_reduction.CaSO4_2H2O = +0; % #29
process.ferric_iron_reduction.NaCl       = +0; % #30
process.ferric_iron_reduction.mantle_CO2 = +0; % #31
process.ferric_iron_reduction.mantle_HCl = +0; % #32
process.ferric_iron_reduction.mantle_H2S = +0; % #33


% reaction #30: pyrite oxidation
process.pyrite_oxidation.ALK        = -16; % #01 
process.pyrite_oxidation.FIC        = +0;  % #02
process.pyrite_oxidation.Ca         = +0;  % #03
process.pyrite_oxidation.Mg         = +0;  % #04
process.pyrite_oxidation.Na         = +0;  % #05
process.pyrite_oxidation.K          = +0;  % #06
process.pyrite_oxidation.Fe2        = +0;  % #07
process.pyrite_oxidation.SiO2_aq    = +0;  % #08
process.pyrite_oxidation.O2         = -15; % #09
process.pyrite_oxidation.SO4        = +8;  % #10
process.pyrite_oxidation.H2S        = +0;  % #11
process.pyrite_oxidation.Cl         = +0;  % #12
process.pyrite_oxidation.N2         = +0;  % #13
process.pyrite_oxidation.NH4        = +0;  % #14
process.pyrite_oxidation.NO3        = +0;  % #15
process.pyrite_oxidation.H2O        = -8;  % #16
process.pyrite_oxidation.CaCO3      = +0;  % #17
process.pyrite_oxidation.CaMgCO32   = +0;  % #18
process.pyrite_oxidation.FeCO3      = +0;  % #19
process.pyrite_oxidation.CaSiO3     = +0;  % #20
process.pyrite_oxidation.MgSiO3     = +0;  % #21
process.pyrite_oxidation.Na2SiO3    = +0;  % #22
process.pyrite_oxidation.K2SiO3     = +0;  % #23
process.pyrite_oxidation.FeSiO3     = +0;  % #24
process.pyrite_oxidation.SiO2_solid = +0;  % #25
process.pyrite_oxidation.CH2O       = +0;  % #26
process.pyrite_oxidation.FeS2       = -4;  % #27
process.pyrite_oxidation.Fe2O3      = +2;  % #28
process.pyrite_oxidation.CaSO4_2H2O = +0;  % #29
process.pyrite_oxidation.NaCl       = +0;  % #30
process.pyrite_oxidation.mantle_CO2 = +0;  % #31
process.pyrite_oxidation.mantle_HCl = +0;  % #32
process.pyrite_oxidation.mantle_H2S = +0;  % #33


% reaction #31: pyrite formation
process.pyrite_formation.ALK        = +2; % #01 
process.pyrite_formation.FIC        = +0; % #02
process.pyrite_formation.Ca         = +0; % #03
process.pyrite_formation.Mg         = +0; % #04
process.pyrite_formation.Na         = +0; % #05
process.pyrite_formation.K          = +0; % #06
process.pyrite_formation.Fe2        = +1; % #07
process.pyrite_formation.SiO2_aq    = +0; % #08
process.pyrite_formation.O2         = +0; % #09
process.pyrite_formation.SO4        = +0; % #10
process.pyrite_formation.H2S        = -2; % #11
process.pyrite_formation.Cl         = +0; % #12
process.pyrite_formation.N2         = +0; % #13
process.pyrite_formation.NH4        = +0; % #14
process.pyrite_formation.NO3        = +0; % #15
process.pyrite_formation.H2O        = +3; % #16
process.pyrite_formation.CaCO3      = +0; % #17
process.pyrite_formation.CaMgCO32   = +0; % #18
process.pyrite_formation.FeCO3      = +0; % #19
process.pyrite_formation.CaSiO3     = +0; % #20
process.pyrite_formation.MgSiO3     = +0; % #21
process.pyrite_formation.Na2SiO3    = +0; % #22
process.pyrite_formation.K2SiO3     = +0; % #23
process.pyrite_formation.FeSiO3     = +0; % #24
process.pyrite_formation.SiO2_solid = +0; % #25
process.pyrite_formation.CH2O       = +0; % #26
process.pyrite_formation.FeS2       = +1; % #27
process.pyrite_formation.Fe2O3      = -1; % #28
process.pyrite_formation.CaSO4_2H2O = +0; % #29
process.pyrite_formation.NaCl       = +0; % #30
process.pyrite_formation.mantle_CO2 = +0; % #31
process.pyrite_formation.mantle_HCl = +0; % #32
process.pyrite_formation.mantle_H2S = +0; % #33


% reaction #32: gypsum dissolution
process.gypsum_dissolution.ALK        = +0; % #01 
process.gypsum_dissolution.FIC        = +0; % #02
process.gypsum_dissolution.Ca         = +1; % #03
process.gypsum_dissolution.Mg         = +0; % #04
process.gypsum_dissolution.Na         = +0; % #05
process.gypsum_dissolution.K          = +0; % #06
process.gypsum_dissolution.Fe2        = +0; % #07
process.gypsum_dissolution.SiO2_aq    = +0; % #08
process.gypsum_dissolution.O2         = +0; % #09
process.gypsum_dissolution.SO4        = +1; % #10
process.gypsum_dissolution.H2S        = +0; % #11
process.gypsum_dissolution.Cl         = +0; % #12
process.gypsum_dissolution.N2         = +0; % #13
process.gypsum_dissolution.NH4        = +0; % #14
process.gypsum_dissolution.NO3        = +0; % #15
process.gypsum_dissolution.H2O        = +2; % #16
process.gypsum_dissolution.CaCO3      = +0; % #17
process.gypsum_dissolution.CaMgCO32   = +0; % #18
process.gypsum_dissolution.FeCO3      = +0; % #19
process.gypsum_dissolution.CaSiO3     = +0; % #20
process.gypsum_dissolution.MgSiO3     = +0; % #21
process.gypsum_dissolution.Na2SiO3    = +0; % #22
process.gypsum_dissolution.K2SiO3     = +0; % #23
process.gypsum_dissolution.FeSiO3     = +0; % #24
process.gypsum_dissolution.SiO2_solid = +0; % #25
process.gypsum_dissolution.CH2O       = +0; % #26
process.gypsum_dissolution.FeS2       = +0; % #27
process.gypsum_dissolution.Fe2O3      = +0; % #28
process.gypsum_dissolution.CaSO4_2H2O = -1; % #29
process.gypsum_dissolution.NaCl       = +0; % #30
process.gypsum_dissolution.mantle_CO2 = +0; % #31
process.gypsum_dissolution.mantle_HCl = +0; % #32
process.gypsum_dissolution.mantle_H2S = +0; % #33


% reaction #33: gypsum formation
process.gypsum_formation.ALK        = +0; % #01 
process.gypsum_formation.FIC        = +0; % #02
process.gypsum_formation.Ca         = -1; % #03
process.gypsum_formation.Mg         = +0; % #04
process.gypsum_formation.Na         = +0; % #05
process.gypsum_formation.K          = +0; % #06
process.gypsum_formation.Fe2        = +0; % #07
process.gypsum_formation.SiO2_aq    = +0; % #08
process.gypsum_formation.O2         = +0; % #09
process.gypsum_formation.SO4        = -1; % #10
process.gypsum_formation.H2S        = +0; % #11
process.gypsum_formation.Cl         = +0; % #12
process.gypsum_formation.N2         = +0; % #13
process.gypsum_formation.NH4        = +0; % #14
process.gypsum_formation.NO3        = +0; % #15
process.gypsum_formation.H2O        = -2; % #16
process.gypsum_formation.CaCO3      = +0; % #17
process.gypsum_formation.CaMgCO32   = +0; % #18
process.gypsum_formation.FeCO3      = +0; % #19
process.gypsum_formation.CaSiO3     = +0; % #20
process.gypsum_formation.MgSiO3     = +0; % #21
process.gypsum_formation.Na2SiO3    = +0; % #22
process.gypsum_formation.K2SiO3     = +0; % #23
process.gypsum_formation.FeSiO3     = +0; % #24
process.gypsum_formation.SiO2_solid = +0; % #25
process.gypsum_formation.CH2O       = +0; % #26
process.gypsum_formation.FeS2       = +0; % #27
process.gypsum_formation.Fe2O3      = +0; % #28
process.gypsum_formation.CaSO4_2H2O = +1; % #29
process.gypsum_formation.NaCl       = +0; % #30
process.gypsum_formation.mantle_CO2 = +0; % #31
process.gypsum_formation.mantle_HCl = +0; % #32
process.gypsum_formation.mantle_H2S = +0; % #33


% reaction #34: halite dissolution
process.halite_dissolution.ALK        = +0; % #01 
process.halite_dissolution.FIC        = +0; % #02
process.halite_dissolution.Ca         = +0; % #03
process.halite_dissolution.Mg         = +0; % #04
process.halite_dissolution.Na         = +1; % #05
process.halite_dissolution.K          = +0; % #06
process.halite_dissolution.Fe2        = +0; % #07
process.halite_dissolution.SiO2_aq    = +0; % #08
process.halite_dissolution.O2         = +0; % #09
process.halite_dissolution.SO4        = +0; % #10
process.halite_dissolution.H2S        = +0; % #11
process.halite_dissolution.Cl         = +1; % #12
process.halite_dissolution.N2         = +0; % #13
process.halite_dissolution.NH4        = +0; % #14
process.halite_dissolution.NO3        = +0; % #15
process.halite_dissolution.H2O        = +0; % #16
process.halite_dissolution.CaCO3      = +0; % #17
process.halite_dissolution.CaMgCO32   = +0; % #18
process.halite_dissolution.FeCO3      = +0; % #19
process.halite_dissolution.CaSiO3     = +0; % #20
process.halite_dissolution.MgSiO3     = +0; % #21
process.halite_dissolution.Na2SiO3    = +0; % #22
process.halite_dissolution.K2SiO3     = +0; % #23
process.halite_dissolution.FeSiO3     = +0; % #24
process.halite_dissolution.SiO2_solid = +0; % #25
process.halite_dissolution.CH2O       = +0; % #26
process.halite_dissolution.FeS2       = +0; % #27
process.halite_dissolution.Fe2O3      = +0; % #28
process.halite_dissolution.CaSO4_2H2O = +0; % #29
process.halite_dissolution.NaCl       = -1; % #30
process.halite_dissolution.mantle_CO2 = +0; % #31
process.halite_dissolution.mantle_HCl = +0; % #32
process.halite_dissolution.mantle_H2S = +0; % #33


% reaction #35: halite formation
process.halite_formation.ALK        = +0; % #01 
process.halite_formation.FIC        = +0; % #02
process.halite_formation.Ca         = +0; % #03
process.halite_formation.Mg         = +0; % #04
process.halite_formation.Na         = -1; % #05
process.halite_formation.K          = +0; % #06
process.halite_formation.Fe2        = +0; % #07
process.halite_formation.SiO2_aq    = +0; % #08
process.halite_formation.O2         = +0; % #09
process.halite_formation.SO4        = +0; % #10
process.halite_formation.H2S        = +0; % #11
process.halite_formation.Cl         = -1; % #12
process.halite_formation.N2         = +0; % #13
process.halite_formation.NH4        = +0; % #14
process.halite_formation.NO3        = +0; % #15
process.halite_formation.H2O        = +0; % #16
process.halite_formation.CaCO3      = +0; % #17
process.halite_formation.CaMgCO32   = +0; % #18
process.halite_formation.FeCO3      = +0; % #19
process.halite_formation.CaSiO3     = +0; % #20
process.halite_formation.MgSiO3     = +0; % #21
process.halite_formation.Na2SiO3    = +0; % #22
process.halite_formation.K2SiO3     = +0; % #23
process.halite_formation.FeSiO3     = +0; % #24
process.halite_formation.SiO2_solid = +0; % #25
process.halite_formation.CH2O       = +0; % #26
process.halite_formation.FeS2       = +0; % #27
process.halite_formation.Fe2O3      = +0; % #28
process.halite_formation.CaSO4_2H2O = +0; % #29
process.halite_formation.NaCl       = +1; % #30
process.halite_formation.mantle_CO2 = +0; % #31
process.halite_formation.mantle_HCl = +0; % #32
process.halite_formation.mantle_H2S = +0; % #33


% reaction #36: dinitrogen fixation
process.dinitrogen_fixation.ALK        = +4; % #01 
process.dinitrogen_fixation.FIC        = +0; % #02 
process.dinitrogen_fixation.Ca         = +0; % #03
process.dinitrogen_fixation.Mg         = +0; % #04
process.dinitrogen_fixation.Na         = +0; % #05
process.dinitrogen_fixation.K          = +0; % #06
process.dinitrogen_fixation.Fe2        = +0; % #07
process.dinitrogen_fixation.SiO2_aq    = +0; % #08
process.dinitrogen_fixation.O2         = +3; % #09
process.dinitrogen_fixation.SO4        = +0; % #10
process.dinitrogen_fixation.H2S        = +0; % #11
process.dinitrogen_fixation.Cl         = +0; % #12
process.dinitrogen_fixation.N2         = -2; % #13
process.dinitrogen_fixation.NH4        = +4; % #14
process.dinitrogen_fixation.NO3        = +0; % #15
process.dinitrogen_fixation.H2O        = -6; % #16
process.dinitrogen_fixation.CaCO3      = +0; % #17
process.dinitrogen_fixation.CaMgCO32   = +0; % #18
process.dinitrogen_fixation.FeCO3      = +0; % #19
process.dinitrogen_fixation.CaSiO3     = +0; % #20
process.dinitrogen_fixation.MgSiO3     = +0; % #21
process.dinitrogen_fixation.Na2SiO3    = +0; % #22
process.dinitrogen_fixation.K2SiO3     = +0; % #23
process.dinitrogen_fixation.FeSiO3     = +0; % #24
process.dinitrogen_fixation.SiO2_solid = +0; % #25
process.dinitrogen_fixation.CH2O       = +0; % #26
process.dinitrogen_fixation.FeS2       = +0; % #27
process.dinitrogen_fixation.Fe2O3      = +0; % #28
process.dinitrogen_fixation.CaSO4_2H2O = +0; % #29
process.dinitrogen_fixation.NaCl       = +0; % #30
process.dinitrogen_fixation.mantle_CO2 = +0; % #31
process.dinitrogen_fixation.mantle_HCl = +0; % #32
process.dinitrogen_fixation.mantle_H2S = +0; % #33


% reaction #37: nitrification
process.nitrification.ALK        = -2; % #01 
process.nitrification.FIC        = +0; % #02
process.nitrification.Ca         = +0; % #03
process.nitrification.Mg         = +0; % #04
process.nitrification.Na         = +0; % #05
process.nitrification.K          = +0; % #06
process.nitrification.Fe2        = +0; % #07
process.nitrification.SiO2_aq    = +0; % #08
process.nitrification.O2         = -2; % #09
process.nitrification.SO4        = +0; % #10
process.nitrification.H2S        = +0; % #11
process.nitrification.Cl         = +0; % #12
process.nitrification.N2         = +0; % #13
process.nitrification.NH4        = -1; % #14
process.nitrification.NO3        = +1; % #15
process.nitrification.H2O        = +1; % #16
process.nitrification.CaCO3      = +0; % #17
process.nitrification.CaMgCO32   = +0; % #18
process.nitrification.FeCO3      = +0; % #19
process.nitrification.CaSiO3     = +0; % #20
process.nitrification.MgSiO3     = +0; % #21
process.nitrification.Na2SiO3    = +0; % #22
process.nitrification.K2SiO3     = +0; % #23
process.nitrification.FeSiO3     = +0; % #24
process.nitrification.SiO2_solid = +0; % #25
process.nitrification.CH2O       = +0; % #26
process.nitrification.FeS2       = +0; % #27
process.nitrification.Fe2O3      = +0; % #28
process.nitrification.CaSO4_2H2O = +0; % #29
process.nitrification.NaCl       = +0; % #30
process.nitrification.mantle_CO2 = +0; % #31
process.nitrification.mantle_HCl = +0; % #32
process.nitrification.mantle_H2S = +0; % #33


% reaction #38: denitrification
process.denitrification.ALK        = +4; % #01 
process.denitrification.FIC        = +5; % #02
process.denitrification.Ca         = +0; % #03
process.denitrification.Mg         = +0; % #04
process.denitrification.Na         = +0; % #05
process.denitrification.K          = +0; % #06
process.denitrification.Fe2        = +0; % #07
process.denitrification.SiO2_aq    = +0; % #08
process.denitrification.O2         = +0; % #09
process.denitrification.SO4        = +0; % #10
process.denitrification.H2S        = +0; % #11
process.denitrification.Cl         = +0; % #12
process.denitrification.N2         = +2; % #13
process.denitrification.NH4        = +0; % #14
process.denitrification.NO3        = -4; % #15
process.denitrification.H2O        = +7; % #16
process.denitrification.CaCO3      = +0; % #17
process.denitrification.CaMgCO32   = +0; % #18
process.denitrification.FeCO3      = +0; % #19
process.denitrification.CaSiO3     = +0; % #20
process.denitrification.MgSiO3     = +0; % #21
process.denitrification.Na2SiO3    = +0; % #22
process.denitrification.K2SiO3     = +0; % #23
process.denitrification.FeSiO3     = +0; % #24
process.denitrification.SiO2_solid = +0; % #25
process.denitrification.CH2O       = -5; % #26
process.denitrification.FeS2       = +0; % #27
process.denitrification.Fe2O3      = +0; % #28
process.denitrification.CaSO4_2H2O = +0; % #29
process.denitrification.NaCl       = +0; % #30
process.denitrification.mantle_CO2 = +0; % #31
process.denitrification.mantle_HCl = +0; % #32
process.denitrification.mantle_H2S = +0; % #33



%% 2. define vectors containing the stiochiometric coefficients for each biogeochemical processes

% 2.1. define vectors for open set calculations
var_list_open                                = {'1: ALK',                           '2: FIC'};
var_list_open_search                         = {'ALK',                              'FIC'};
process.mantle_CO2.vector_open               = [process.mantle_CO2.ALK               process.mantle_CO2.FIC             ]'; % reaction #1:  mantle degassing of CO2
process.mantle_HCl.vector_open               = [process.mantle_HCl.ALK               process.mantle_HCl.FIC             ]'; % reaction #2:  mantle degassing of HCl
process.mantle_H2S.vector_open               = [process.mantle_H2S.ALK               process.mantle_H2S.FIC             ]'; % reaction #3:  mantle degassing of H2S
process.calcite_metamorphism.vector_open     = [process.calcite_metamorphism.ALK     process.calcite_metamorphism.FIC   ]'; % reaction #4:  calcite metamorphism
process.dolomite_metamorphism.vector_open    = [process.dolomite_metamorphism.ALK    process.dolomite_metamorphism.FIC  ]'; % reaction #5:  dolomite metamorphism
process.siderite_metamorphism.vector_open    = [process.siderite_metamorphism.ALK    process.siderite_metamorphism.FIC  ]'; % reaction #6:  siderite metamorphism
process.Ca_silicate_weathering.vector_open   = [process.Ca_silicate_weathering.ALK   process.Ca_silicate_weathering.FIC ]'; % reaction #7:  Ca-silicate weathering
process.Mg_silicate_weathering.vector_open   = [process.Mg_silicate_weathering.ALK   process.Mg_silicate_weathering.FIC ]'; % reaction #8:  Mg-silicate weathering
process.Na_silicate_weathering.vector_open   = [process.Na_silicate_weathering.ALK   process.Na_silicate_weathering.FIC ]'; % reaction #9:  Na-silicate weathering
process.K_silicate_weathering.vector_open    = [process.K_silicate_weathering.ALK    process.K_silicate_weathering.FIC  ]'; % reaction #10: K-silicate weathering
process.Fe_silicate_weathering.vector_open   = [process.Fe_silicate_weathering.ALK   process.Fe_silicate_weathering.FIC ]'; % reaction #11: Fe-silicate weathering
process.calcite_weathering.vector_open       = [process.calcite_weathering.ALK       process.calcite_weathering.FIC     ]'; % reaction #12: calcite weathering
process.dolomite_weathering.vector_open      = [process.dolomite_weathering.ALK      process.dolomite_weathering.FIC    ]'; % reaction #13: dolomite weathering
process.siderite_weathering.vector_open      = [process.siderite_weathering.ALK      process.siderite_weathering.FIC    ]'; % reaction #14: siderite weathering
process.silica_weathering.vector_open        = [process.silica_weathering.ALK        process.silica_weathering.FIC      ]'; % reaction #15: silica weathering
process.Mg_reverse_weathering.vector_open    = [process.Mg_reverse_weathering.ALK    process.Mg_reverse_weathering.FIC  ]'; % reaction #16: Mg-reverse weathering
process.Na_reverse_weathering.vector_open    = [process.Na_reverse_weathering.ALK    process.Na_reverse_weathering.FIC  ]'; % reaction #17: Na-reverse weathering
process.K_reverse_weathering.vector_open     = [process.K_reverse_weathering.ALK     process.K_reverse_weathering.FIC   ]'; % reaction #18: K-reverse weathering
process.Fe_reverse_weathering.vector_open    = [process.Fe_reverse_weathering.ALK    process.Fe_reverse_weathering.FIC  ]'; % reaction #19: Fe-reverse weathering
process.silica_formation.vector_open         = [process.silica_formation.ALK         process.silica_formation.FIC       ]'; % reaction #20: silica formation
process.calcite_formation.vector_open        = [process.calcite_formation.ALK        process.calcite_formation.FIC      ]'; % reaction #21: calcite formation
process.dolomite_formation.vector_open       = [process.dolomite_formation.ALK       process.dolomite_formation.FIC     ]'; % reaction #22: dolomite formation
process.siderite_formation.vector_open       = [process.siderite_formation.ALK       process.siderite_formation.FIC     ]'; % reaction #23: siderite formation
process.oxygenic_photosynthesis.vector_open  = [process.oxygenic_photosynthesis.ALK  process.oxygenic_photosynthesis.FIC]'; % reaction #24: oxygenic photosynthesis
process.aerobic_respiration.vector_open      = [process.aerobic_respiration.ALK      process.aerobic_respiration.FIC    ]'; % reaction #25: aerobic respiration
process.sulfide_oxidation.vector_open        = [process.sulfide_oxidation.ALK        process.sulfide_oxidation.FIC      ]'; % reaction #26: sulfide oxidation
process.sulfate_reduction.vector_open        = [process.sulfate_reduction.ALK        process.sulfate_reduction.FIC      ]'; % reaction #27: sulfate reduction
process.ferrous_iron_oxidation.vector_open   = [process.ferrous_iron_oxidation.ALK   process.ferrous_iron_oxidation.FIC ]'; % reaction #28: ferrous iron oxidation
process.ferric_iron_reduction.vector_open    = [process.ferric_iron_reduction.ALK    process.ferric_iron_reduction.FIC  ]'; % reaction #29: ferric iron reduction
process.pyrite_oxidation.vector_open         = [process.pyrite_oxidation.ALK         process.pyrite_oxidation.FIC       ]'; % reaction #30: pyrite oxidation
process.pyrite_formation.vector_open         = [process.pyrite_formation.ALK         process.pyrite_formation.FIC       ]'; % reaction #31: pyrite formation
process.gypsum_dissolution.vector_open       = [process.gypsum_dissolution.ALK       process.gypsum_dissolution.FIC     ]'; % reaction #32: gypsum dissolution
process.gypsum_formation.vector_open         = [process.gypsum_formation.ALK         process.gypsum_formation.FIC       ]'; % reaction #33: gypsum formation
process.halite_dissolution.vector_open       = [process.halite_dissolution.ALK       process.halite_dissolution.FIC     ]'; % reaction #34: halite dissolution
process.halite_formation.vector_open         = [process.halite_formation.ALK         process.halite_formation.FIC       ]'; % reaction #35: halite formation
process.dinitrogen_fixation.vector_open      = [process.dinitrogen_fixation.ALK      process.dinitrogen_fixation.FIC    ]'; % reaction #36: dinitrogen fixation
process.nitrification.vector_open            = [process.nitrification.ALK            process.nitrification.FIC          ]'; % reaction #37: nitrification
process.denitrification.vector_open          = [process.denitrification.ALK          process.denitrification.FIC        ]'; % reaction #38: denitrification

% 2.2. define vectors for exchange set calculations
var_list_exchange                                = {'1: ALK',                           '2: FIC',                            '3: Ca',                            '4: Mg',                            '5: Na',                            '6: K',                            '7: Fe2',                             '8: SiO2 (aq)',                          '9: O2',                            '10: SO4',                           '11: H2S',                           '12: Cl',                           '13: N2',                           '14: NH4',                           '15: NO3'};
var_list_exchange_search                         = {'ALK',                              'FIC',                               'Ca',                               'Mg',                               'Na',                               'K',                               'Fe2',                                'SiO2 (aq)',                             'O2',                               'SO4',                               'H2S',                               'Cl',                               'N2',                               'NH4',                               'NO3'};
process.mantle_CO2.vector_exchange               = [process.mantle_CO2.ALK               process.mantle_CO2.FIC               process.mantle_CO2.Ca               process.mantle_CO2.Mg               process.mantle_CO2.Na               process.mantle_CO2.K               process.mantle_CO2.Fe2               process.mantle_CO2.SiO2_aq               process.mantle_CO2.O2               process.mantle_CO2.SO4               process.mantle_CO2.H2S               process.mantle_CO2.Cl               process.mantle_CO2.N2               process.mantle_CO2.NH4               process.mantle_CO2.NO3             ]'; % reaction #1:  mantle degassing of CO2
process.mantle_HCl.vector_exchange               = [process.mantle_HCl.ALK               process.mantle_HCl.FIC               process.mantle_HCl.Ca               process.mantle_HCl.Mg               process.mantle_HCl.Na               process.mantle_HCl.K               process.mantle_HCl.Fe2               process.mantle_HCl.SiO2_aq               process.mantle_HCl.O2               process.mantle_HCl.SO4               process.mantle_HCl.H2S               process.mantle_HCl.Cl               process.mantle_HCl.N2               process.mantle_HCl.NH4               process.mantle_HCl.NO3             ]'; % reaction #2:  mantle degassing of HCl
process.mantle_H2S.vector_exchange               = [process.mantle_H2S.ALK               process.mantle_H2S.FIC               process.mantle_H2S.Ca               process.mantle_H2S.Mg               process.mantle_H2S.Na               process.mantle_H2S.K               process.mantle_H2S.Fe2               process.mantle_H2S.SiO2_aq               process.mantle_H2S.O2               process.mantle_H2S.SO4               process.mantle_H2S.H2S               process.mantle_H2S.Cl               process.mantle_H2S.N2               process.mantle_H2S.NH4               process.mantle_H2S.NO3             ]'; % reaction #3:  mantle degassing of H2S
process.calcite_metamorphism.vector_exchange     = [process.calcite_metamorphism.ALK     process.calcite_metamorphism.FIC     process.calcite_metamorphism.Ca     process.calcite_metamorphism.Mg     process.calcite_metamorphism.Na     process.calcite_metamorphism.K     process.calcite_metamorphism.Fe2     process.calcite_metamorphism.SiO2_aq     process.calcite_metamorphism.O2     process.calcite_metamorphism.SO4     process.calcite_metamorphism.H2S     process.calcite_metamorphism.Cl     process.calcite_metamorphism.N2     process.calcite_metamorphism.NH4     process.calcite_metamorphism.NO3   ]'; % reaction #4:  calcite metamorphism
process.dolomite_metamorphism.vector_exchange    = [process.dolomite_metamorphism.ALK    process.dolomite_metamorphism.FIC    process.dolomite_metamorphism.Ca    process.dolomite_metamorphism.Mg    process.dolomite_metamorphism.Na    process.dolomite_metamorphism.K    process.dolomite_metamorphism.Fe2    process.dolomite_metamorphism.SiO2_aq    process.dolomite_metamorphism.O2    process.dolomite_metamorphism.SO4    process.dolomite_metamorphism.H2S    process.dolomite_metamorphism.Cl    process.dolomite_metamorphism.N2    process.dolomite_metamorphism.NH4    process.dolomite_metamorphism.NO3  ]'; % reaction #5:  dolomite metamorphism
process.siderite_metamorphism.vector_exchange    = [process.siderite_metamorphism.ALK    process.siderite_metamorphism.FIC    process.siderite_metamorphism.Ca    process.siderite_metamorphism.Mg    process.siderite_metamorphism.Na    process.siderite_metamorphism.K    process.siderite_metamorphism.Fe2    process.siderite_metamorphism.SiO2_aq    process.siderite_metamorphism.O2    process.siderite_metamorphism.SO4    process.siderite_metamorphism.H2S    process.siderite_metamorphism.Cl    process.siderite_metamorphism.N2    process.siderite_metamorphism.NH4    process.siderite_metamorphism.NO3  ]'; % reaction #6:  siderite metamorphism
process.Ca_silicate_weathering.vector_exchange   = [process.Ca_silicate_weathering.ALK   process.Ca_silicate_weathering.FIC   process.Ca_silicate_weathering.Ca   process.Ca_silicate_weathering.Mg   process.Ca_silicate_weathering.Na   process.Ca_silicate_weathering.K   process.Ca_silicate_weathering.Fe2   process.Ca_silicate_weathering.SiO2_aq   process.Ca_silicate_weathering.O2   process.Ca_silicate_weathering.SO4   process.Ca_silicate_weathering.H2S   process.Ca_silicate_weathering.Cl   process.Ca_silicate_weathering.N2   process.Ca_silicate_weathering.NH4   process.Ca_silicate_weathering.NO3 ]'; % reaction #7:  Ca-silicate weathering
process.Mg_silicate_weathering.vector_exchange   = [process.Mg_silicate_weathering.ALK   process.Mg_silicate_weathering.FIC   process.Mg_silicate_weathering.Ca   process.Mg_silicate_weathering.Mg   process.Mg_silicate_weathering.Na   process.Mg_silicate_weathering.K   process.Mg_silicate_weathering.Fe2   process.Mg_silicate_weathering.SiO2_aq   process.Mg_silicate_weathering.O2   process.Mg_silicate_weathering.SO4   process.Mg_silicate_weathering.H2S   process.Mg_silicate_weathering.Cl   process.Mg_silicate_weathering.N2   process.Mg_silicate_weathering.NH4   process.Mg_silicate_weathering.NO3 ]'; % reaction #8:  Mg-silicate weathering
process.Na_silicate_weathering.vector_exchange   = [process.Na_silicate_weathering.ALK   process.Na_silicate_weathering.FIC   process.Na_silicate_weathering.Ca   process.Na_silicate_weathering.Mg   process.Na_silicate_weathering.Na   process.Na_silicate_weathering.K   process.Na_silicate_weathering.Fe2   process.Na_silicate_weathering.SiO2_aq   process.Na_silicate_weathering.O2   process.Na_silicate_weathering.SO4   process.Na_silicate_weathering.H2S   process.Na_silicate_weathering.Cl   process.Na_silicate_weathering.N2   process.Na_silicate_weathering.NH4   process.Na_silicate_weathering.NO3 ]'; % reaction #9:  Na-silicate weathering
process.K_silicate_weathering.vector_exchange    = [process.K_silicate_weathering.ALK    process.K_silicate_weathering.FIC    process.K_silicate_weathering.Ca    process.K_silicate_weathering.Mg    process.K_silicate_weathering.Na    process.K_silicate_weathering.K    process.K_silicate_weathering.Fe2    process.K_silicate_weathering.SiO2_aq    process.K_silicate_weathering.O2    process.K_silicate_weathering.SO4    process.K_silicate_weathering.H2S    process.K_silicate_weathering.Cl    process.K_silicate_weathering.N2    process.K_silicate_weathering.NH4    process.K_silicate_weathering.NO3  ]'; % reaction #10: K-silicate weathering
process.Fe_silicate_weathering.vector_exchange   = [process.Fe_silicate_weathering.ALK   process.Fe_silicate_weathering.FIC   process.Fe_silicate_weathering.Ca   process.Fe_silicate_weathering.Mg   process.Fe_silicate_weathering.Na   process.Fe_silicate_weathering.K   process.Fe_silicate_weathering.Fe2   process.Fe_silicate_weathering.SiO2_aq   process.Fe_silicate_weathering.O2   process.Fe_silicate_weathering.SO4   process.Fe_silicate_weathering.H2S   process.Fe_silicate_weathering.Cl   process.Fe_silicate_weathering.N2   process.Fe_silicate_weathering.NH4   process.Fe_silicate_weathering.NO3 ]'; % reaction #11: Fe-silicate weathering
process.calcite_weathering.vector_exchange       = [process.calcite_weathering.ALK       process.calcite_weathering.FIC       process.calcite_weathering.Ca       process.calcite_weathering.Mg       process.calcite_weathering.Na       process.calcite_weathering.K       process.calcite_weathering.Fe2       process.calcite_weathering.SiO2_aq       process.calcite_weathering.O2       process.calcite_weathering.SO4       process.calcite_weathering.H2S       process.calcite_weathering.Cl       process.calcite_weathering.N2       process.calcite_weathering.NH4       process.calcite_weathering.NO3     ]'; % reaction #12: calcite weathering
process.dolomite_weathering.vector_exchange      = [process.dolomite_weathering.ALK      process.dolomite_weathering.FIC      process.dolomite_weathering.Ca      process.dolomite_weathering.Mg      process.dolomite_weathering.Na      process.dolomite_weathering.K      process.dolomite_weathering.Fe2      process.dolomite_weathering.SiO2_aq      process.dolomite_weathering.O2      process.dolomite_weathering.SO4      process.dolomite_weathering.H2S      process.dolomite_weathering.Cl      process.dolomite_weathering.N2      process.dolomite_weathering.NH4      process.dolomite_weathering.NO3    ]'; % reaction #13: dolomite weathering
process.siderite_weathering.vector_exchange      = [process.siderite_weathering.ALK      process.siderite_weathering.FIC      process.siderite_weathering.Ca      process.siderite_weathering.Mg      process.siderite_weathering.Na      process.siderite_weathering.K      process.siderite_weathering.Fe2      process.siderite_weathering.SiO2_aq      process.siderite_weathering.O2      process.siderite_weathering.SO4      process.siderite_weathering.H2S      process.siderite_weathering.Cl      process.siderite_weathering.N2      process.siderite_weathering.NH4      process.siderite_weathering.NO3    ]'; % reaction #14: siderite weathering
process.silica_weathering.vector_exchange        = [process.silica_weathering.ALK        process.silica_weathering.FIC        process.silica_weathering.Ca        process.silica_weathering.Mg        process.silica_weathering.Na        process.silica_weathering.K        process.silica_weathering.Fe2        process.silica_weathering.SiO2_aq        process.silica_weathering.O2        process.silica_weathering.SO4        process.silica_weathering.H2S        process.silica_weathering.Cl        process.silica_weathering.N2        process.silica_weathering.NH4        process.silica_weathering.NO3      ]'; % reaction #15: silica weathering
process.Mg_reverse_weathering.vector_exchange    = [process.Mg_reverse_weathering.ALK    process.Mg_reverse_weathering.FIC    process.Mg_reverse_weathering.Ca    process.Mg_reverse_weathering.Mg    process.Mg_reverse_weathering.Na    process.Mg_reverse_weathering.K    process.Mg_reverse_weathering.Fe2    process.Mg_reverse_weathering.SiO2_aq    process.Mg_reverse_weathering.O2    process.Mg_reverse_weathering.SO4    process.Mg_reverse_weathering.H2S    process.Mg_reverse_weathering.Cl    process.Mg_reverse_weathering.N2    process.Mg_reverse_weathering.NH4    process.Mg_reverse_weathering.NO3  ]'; % reaction #16: Mg-reverse weathering
process.Na_reverse_weathering.vector_exchange    = [process.Na_reverse_weathering.ALK    process.Na_reverse_weathering.FIC    process.Na_reverse_weathering.Ca    process.Na_reverse_weathering.Mg    process.Na_reverse_weathering.Na    process.Na_reverse_weathering.K    process.Na_reverse_weathering.Fe2    process.Na_reverse_weathering.SiO2_aq    process.Na_reverse_weathering.O2    process.Na_reverse_weathering.SO4    process.Na_reverse_weathering.H2S    process.Na_reverse_weathering.Cl    process.Na_reverse_weathering.N2    process.Na_reverse_weathering.NH4    process.Na_reverse_weathering.NO3  ]'; % reaction #17: Na-reverse weathering
process.K_reverse_weathering.vector_exchange     = [process.K_reverse_weathering.ALK     process.K_reverse_weathering.FIC     process.K_reverse_weathering.Ca     process.K_reverse_weathering.Mg     process.K_reverse_weathering.Na     process.K_reverse_weathering.K     process.K_reverse_weathering.Fe2     process.K_reverse_weathering.SiO2_aq     process.K_reverse_weathering.O2     process.K_reverse_weathering.SO4     process.K_reverse_weathering.H2S     process.K_reverse_weathering.Cl     process.K_reverse_weathering.N2     process.K_reverse_weathering.NH4     process.K_reverse_weathering.NO3   ]'; % reaction #18: K-reverse weathering
process.Fe_reverse_weathering.vector_exchange    = [process.Fe_reverse_weathering.ALK    process.Fe_reverse_weathering.FIC    process.Fe_reverse_weathering.Ca    process.Fe_reverse_weathering.Mg    process.Fe_reverse_weathering.Na    process.Fe_reverse_weathering.K    process.Fe_reverse_weathering.Fe2    process.Fe_reverse_weathering.SiO2_aq    process.Fe_reverse_weathering.O2    process.Fe_reverse_weathering.SO4    process.Fe_reverse_weathering.H2S    process.Fe_reverse_weathering.Cl    process.Fe_reverse_weathering.N2    process.Fe_reverse_weathering.NH4    process.Fe_reverse_weathering.NO3  ]'; % reaction #19: Fe-reverse weathering
process.silica_formation.vector_exchange         = [process.silica_formation.ALK         process.silica_formation.FIC         process.silica_formation.Ca         process.silica_formation.Mg         process.silica_formation.Na         process.silica_formation.K         process.silica_formation.Fe2         process.silica_formation.SiO2_aq         process.silica_formation.O2         process.silica_formation.SO4         process.silica_formation.H2S         process.silica_formation.Cl         process.silica_formation.N2         process.silica_formation.NH4         process.silica_formation.NO3       ]'; % reaction #20: silica formation
process.calcite_formation.vector_exchange        = [process.calcite_formation.ALK        process.calcite_formation.FIC        process.calcite_formation.Ca        process.calcite_formation.Mg        process.calcite_formation.Na        process.calcite_formation.K        process.calcite_formation.Fe2        process.calcite_formation.SiO2_aq        process.calcite_formation.O2        process.calcite_formation.SO4        process.calcite_formation.H2S        process.calcite_formation.Cl        process.calcite_formation.N2        process.calcite_formation.NH4        process.calcite_formation.NO3      ]'; % reaction #21: calcite formation
process.dolomite_formation.vector_exchange       = [process.dolomite_formation.ALK       process.dolomite_formation.FIC       process.dolomite_formation.Ca       process.dolomite_formation.Mg       process.dolomite_formation.Na       process.dolomite_formation.K       process.dolomite_formation.Fe2       process.dolomite_formation.SiO2_aq       process.dolomite_formation.O2       process.dolomite_formation.SO4       process.dolomite_formation.H2S       process.dolomite_formation.Cl       process.dolomite_formation.N2       process.dolomite_formation.NH4       process.dolomite_formation.NO3     ]'; % reaction #22: dolomite formation
process.siderite_formation.vector_exchange       = [process.siderite_formation.ALK       process.siderite_formation.FIC       process.siderite_formation.Ca       process.siderite_formation.Mg       process.siderite_formation.Na       process.siderite_formation.K       process.siderite_formation.Fe2       process.siderite_formation.SiO2_aq       process.siderite_formation.O2       process.siderite_formation.SO4       process.siderite_formation.H2S       process.siderite_formation.Cl       process.siderite_formation.N2       process.siderite_formation.NH4       process.siderite_formation.NO3     ]'; % reaction #23: siderite formation
process.oxygenic_photosynthesis.vector_exchange  = [process.oxygenic_photosynthesis.ALK  process.oxygenic_photosynthesis.FIC  process.oxygenic_photosynthesis.Ca  process.oxygenic_photosynthesis.Mg  process.oxygenic_photosynthesis.Na  process.oxygenic_photosynthesis.K  process.oxygenic_photosynthesis.Fe2  process.oxygenic_photosynthesis.SiO2_aq  process.oxygenic_photosynthesis.O2  process.oxygenic_photosynthesis.SO4  process.oxygenic_photosynthesis.H2S  process.oxygenic_photosynthesis.Cl  process.oxygenic_photosynthesis.N2  process.oxygenic_photosynthesis.NH4  process.oxygenic_photosynthesis.NO3]'; % reaction #24: oxygenic photosynthesis
process.aerobic_respiration.vector_exchange      = [process.aerobic_respiration.ALK      process.aerobic_respiration.FIC      process.aerobic_respiration.Ca      process.aerobic_respiration.Mg      process.aerobic_respiration.Na      process.aerobic_respiration.K      process.aerobic_respiration.Fe2      process.aerobic_respiration.SiO2_aq      process.aerobic_respiration.O2      process.aerobic_respiration.SO4      process.aerobic_respiration.H2S      process.aerobic_respiration.Cl      process.aerobic_respiration.N2      process.aerobic_respiration.NH4      process.aerobic_respiration.NO3    ]'; % reaction #25: aerobic respiration
process.sulfide_oxidation.vector_exchange        = [process.sulfide_oxidation.ALK        process.sulfide_oxidation.FIC        process.sulfide_oxidation.Ca        process.sulfide_oxidation.Mg        process.sulfide_oxidation.Na        process.sulfide_oxidation.K        process.sulfide_oxidation.Fe2        process.sulfide_oxidation.SiO2_aq        process.sulfide_oxidation.O2        process.sulfide_oxidation.SO4        process.sulfide_oxidation.H2S        process.sulfide_oxidation.Cl        process.sulfide_oxidation.N2        process.sulfide_oxidation.NH4        process.sulfide_oxidation.NO3      ]'; % reaction #26: sulfide oxidation
process.sulfate_reduction.vector_exchange        = [process.sulfate_reduction.ALK        process.sulfate_reduction.FIC        process.sulfate_reduction.Ca        process.sulfate_reduction.Mg        process.sulfate_reduction.Na        process.sulfate_reduction.K        process.sulfate_reduction.Fe2        process.sulfate_reduction.SiO2_aq        process.sulfate_reduction.O2        process.sulfate_reduction.SO4        process.sulfate_reduction.H2S        process.sulfate_reduction.Cl        process.sulfate_reduction.N2        process.sulfate_reduction.NH4        process.sulfate_reduction.NO3      ]'; % reaction #27: sulfate reduction
process.ferrous_iron_oxidation.vector_exchange   = [process.ferrous_iron_oxidation.ALK   process.ferrous_iron_oxidation.FIC   process.ferrous_iron_oxidation.Ca   process.ferrous_iron_oxidation.Mg   process.ferrous_iron_oxidation.Na   process.ferrous_iron_oxidation.K   process.ferrous_iron_oxidation.Fe2   process.ferrous_iron_oxidation.SiO2_aq   process.ferrous_iron_oxidation.O2   process.ferrous_iron_oxidation.SO4   process.ferrous_iron_oxidation.H2S   process.ferrous_iron_oxidation.Cl   process.ferrous_iron_oxidation.N2   process.ferrous_iron_oxidation.NH4   process.ferrous_iron_oxidation.NO3 ]'; % reaction #28: ferrous iron oxidation
process.ferric_iron_reduction.vector_exchange    = [process.ferric_iron_reduction.ALK    process.ferric_iron_reduction.FIC    process.ferric_iron_reduction.Ca    process.ferric_iron_reduction.Mg    process.ferric_iron_reduction.Na    process.ferric_iron_reduction.K    process.ferric_iron_reduction.Fe2    process.ferric_iron_reduction.SiO2_aq    process.ferric_iron_reduction.O2    process.ferric_iron_reduction.SO4    process.ferric_iron_reduction.H2S    process.ferric_iron_reduction.Cl    process.ferric_iron_reduction.N2    process.ferric_iron_reduction.NH4    process.ferric_iron_reduction.NO3  ]'; % reaction #29: ferric iron reduction
process.pyrite_oxidation.vector_exchange         = [process.pyrite_oxidation.ALK         process.pyrite_oxidation.FIC         process.pyrite_oxidation.Ca         process.pyrite_oxidation.Mg         process.pyrite_oxidation.Na         process.pyrite_oxidation.K         process.pyrite_oxidation.Fe2         process.pyrite_oxidation.SiO2_aq         process.pyrite_oxidation.O2         process.pyrite_oxidation.SO4         process.pyrite_oxidation.H2S         process.pyrite_oxidation.Cl         process.pyrite_oxidation.N2         process.pyrite_oxidation.NH4         process.pyrite_oxidation.NO3       ]'; % reaction #30: pyrite oxidation
process.pyrite_formation.vector_exchange         = [process.pyrite_formation.ALK         process.pyrite_formation.FIC         process.pyrite_formation.Ca         process.pyrite_formation.Mg         process.pyrite_formation.Na         process.pyrite_formation.K         process.pyrite_formation.Fe2         process.pyrite_formation.SiO2_aq         process.pyrite_formation.O2         process.pyrite_formation.SO4         process.pyrite_formation.H2S         process.pyrite_formation.Cl         process.pyrite_formation.N2         process.pyrite_formation.NH4         process.pyrite_formation.NO3       ]'; % reaction #31: pyrite formation
process.gypsum_dissolution.vector_exchange       = [process.gypsum_dissolution.ALK       process.gypsum_dissolution.FIC       process.gypsum_dissolution.Ca       process.gypsum_dissolution.Mg       process.gypsum_dissolution.Na       process.gypsum_dissolution.K       process.gypsum_dissolution.Fe2       process.gypsum_dissolution.SiO2_aq       process.gypsum_dissolution.O2       process.gypsum_dissolution.SO4       process.gypsum_dissolution.H2S       process.gypsum_dissolution.Cl       process.gypsum_dissolution.N2       process.gypsum_dissolution.NH4       process.gypsum_dissolution.NO3     ]'; % reaction #32: gypsum dissolution
process.gypsum_formation.vector_exchange         = [process.gypsum_formation.ALK         process.gypsum_formation.FIC         process.gypsum_formation.Ca         process.gypsum_formation.Mg         process.gypsum_formation.Na         process.gypsum_formation.K         process.gypsum_formation.Fe2         process.gypsum_formation.SiO2_aq         process.gypsum_formation.O2         process.gypsum_formation.SO4         process.gypsum_formation.H2S         process.gypsum_formation.Cl         process.gypsum_formation.N2         process.gypsum_formation.NH4         process.gypsum_formation.NO3       ]'; % reaction #33: gypsum formation
process.halite_dissolution.vector_exchange       = [process.halite_dissolution.ALK       process.halite_dissolution.FIC       process.halite_dissolution.Ca       process.halite_dissolution.Mg       process.halite_dissolution.Na       process.halite_dissolution.K       process.halite_dissolution.Fe2       process.halite_dissolution.SiO2_aq       process.halite_dissolution.O2       process.halite_dissolution.SO4       process.halite_dissolution.H2S       process.halite_dissolution.Cl       process.halite_dissolution.N2       process.halite_dissolution.NH4       process.halite_dissolution.NO3     ]'; % reaction #34: halite dissolution
process.halite_formation.vector_exchange         = [process.halite_formation.ALK         process.halite_formation.FIC         process.halite_formation.Ca         process.halite_formation.Mg         process.halite_formation.Na         process.halite_formation.K         process.halite_formation.Fe2         process.halite_formation.SiO2_aq         process.halite_formation.O2         process.halite_formation.SO4         process.halite_formation.H2S         process.halite_formation.Cl         process.halite_formation.N2         process.halite_formation.NH4         process.halite_formation.NO3       ]'; % reaction #35: halite formation
process.dinitrogen_fixation.vector_exchange      = [process.dinitrogen_fixation.ALK      process.dinitrogen_fixation.FIC      process.dinitrogen_fixation.Ca      process.dinitrogen_fixation.Mg      process.dinitrogen_fixation.Na      process.dinitrogen_fixation.K      process.dinitrogen_fixation.Fe2      process.dinitrogen_fixation.SiO2_aq      process.dinitrogen_fixation.O2      process.dinitrogen_fixation.SO4      process.dinitrogen_fixation.H2S      process.dinitrogen_fixation.Cl      process.dinitrogen_fixation.N2      process.dinitrogen_fixation.NH4      process.dinitrogen_fixation.NO3    ]'; % reaction #36: dinitrogen fixation
process.nitrification.vector_exchange            = [process.nitrification.ALK            process.nitrification.FIC            process.nitrification.Ca            process.nitrification.Mg            process.nitrification.Na            process.nitrification.K            process.nitrification.Fe2            process.nitrification.SiO2_aq            process.nitrification.O2            process.nitrification.SO4            process.nitrification.H2S            process.nitrification.Cl            process.nitrification.N2            process.nitrification.NH4            process.nitrification.NO3          ]'; % reaction #37: nitrification
process.denitrification.vector_exchange          = [process.denitrification.ALK          process.denitrification.FIC          process.denitrification.Ca          process.denitrification.Mg          process.denitrification.Na          process.denitrification.K          process.denitrification.Fe2          process.denitrification.SiO2_aq          process.denitrification.O2          process.denitrification.SO4          process.denitrification.H2S          process.denitrification.Cl          process.denitrification.N2          process.denitrification.NH4          process.denitrification.NO3        ]'; % reaction #38: denitrification

% 2.3. define vectors containing crustal variables
var_list_solid                                   =                                                   {'16: H2O',                          '17: CaCO3',                           '18: CaMgCO32',                           '19: FeCO3',                           '20: CaSiO3',                           '21: MgSiO3',                           '22: Na2SiO3',                           '23: K2SiO3',                           '24: FeSiO3',                           '25: SiO2 (solid)',                         '26: CH2O',                           '27: FeS2',                           '28: Fe2O3',                           '29: CaSO4_2H2O',                           '30: NaCl',                           '31: mantle_CO2',                           '32: mantle_HCl',                           '33: mantle_H2S'};
var_list_solid_search                            =                                                   {'H2O',                              'CaCO3',                               'CaMgCO32',                               'FeCO3',                               'CaSiO3',                               'MgSiO3',                               'Na2SiO3',                               'K2SiO3',                               'FeSiO3',                               'SiO2 (solid)',                             'CH2O',                               'FeS2',                               'Fe2O3',                               'CaSO4_2H2O',                               'NaCl',                               'mantle_CO2',                               'mantle_HCl',                               'mantle_H2S'    };
process.mantle_CO2.vector_closed                 = [process.mantle_CO2.vector_exchange'               process.mantle_CO2.H2O               process.mantle_CO2.CaCO3               process.mantle_CO2.CaMgCO32               process.mantle_CO2.FeCO3               process.mantle_CO2.CaSiO3               process.mantle_CO2.MgSiO3               process.mantle_CO2.Na2SiO3               process.mantle_CO2.K2SiO3               process.mantle_CO2.FeSiO3               process.mantle_CO2.SiO2_solid               process.mantle_CO2.CH2O               process.mantle_CO2.FeS2               process.mantle_CO2.Fe2O3               process.mantle_CO2.CaSO4_2H2O               process.mantle_CO2.NaCl               process.mantle_CO2.mantle_CO2               process.mantle_CO2.mantle_HCl               process.mantle_CO2.mantle_H2S             ]'; % reaction #1:  mantle degassing of CO2
process.mantle_HCl.vector_closed                 = [process.mantle_HCl.vector_exchange'               process.mantle_HCl.H2O               process.mantle_HCl.CaCO3               process.mantle_HCl.CaMgCO32               process.mantle_HCl.FeCO3               process.mantle_HCl.CaSiO3               process.mantle_HCl.MgSiO3               process.mantle_HCl.Na2SiO3               process.mantle_HCl.K2SiO3               process.mantle_HCl.FeSiO3               process.mantle_HCl.SiO2_solid               process.mantle_HCl.CH2O               process.mantle_HCl.FeS2               process.mantle_HCl.Fe2O3               process.mantle_HCl.CaSO4_2H2O               process.mantle_HCl.NaCl               process.mantle_HCl.mantle_CO2               process.mantle_HCl.mantle_HCl               process.mantle_HCl.mantle_H2S             ]'; % reaction #2:  mantle degassing of HCl      
process.mantle_H2S.vector_closed                 = [process.mantle_H2S.vector_exchange'               process.mantle_H2S.H2O               process.mantle_H2S.CaCO3               process.mantle_H2S.CaMgCO32               process.mantle_H2S.FeCO3               process.mantle_H2S.CaSiO3               process.mantle_H2S.MgSiO3               process.mantle_H2S.Na2SiO3               process.mantle_H2S.K2SiO3               process.mantle_H2S.FeSiO3               process.mantle_H2S.SiO2_solid               process.mantle_H2S.CH2O               process.mantle_H2S.FeS2               process.mantle_H2S.Fe2O3               process.mantle_H2S.CaSO4_2H2O               process.mantle_H2S.NaCl               process.mantle_H2S.mantle_CO2               process.mantle_H2S.mantle_HCl               process.mantle_H2S.mantle_H2S             ]'; % reaction #3:  mantle degassing of H2S
process.calcite_metamorphism.vector_closed       = [process.calcite_metamorphism.vector_exchange'     process.calcite_metamorphism.H2O     process.calcite_metamorphism.CaCO3     process.calcite_metamorphism.CaMgCO32     process.calcite_metamorphism.FeCO3     process.calcite_metamorphism.CaSiO3     process.calcite_metamorphism.MgSiO3     process.calcite_metamorphism.Na2SiO3     process.calcite_metamorphism.K2SiO3     process.calcite_metamorphism.FeSiO3     process.calcite_metamorphism.SiO2_solid     process.calcite_metamorphism.CH2O     process.calcite_metamorphism.FeS2     process.calcite_metamorphism.Fe2O3     process.calcite_metamorphism.CaSO4_2H2O     process.calcite_metamorphism.NaCl     process.calcite_metamorphism.mantle_CO2     process.calcite_metamorphism.mantle_HCl     process.calcite_metamorphism.mantle_H2S   ]'; % reaction #4:  calcite metamorphism
process.dolomite_metamorphism.vector_closed      = [process.dolomite_metamorphism.vector_exchange'    process.dolomite_metamorphism.H2O    process.dolomite_metamorphism.CaCO3    process.dolomite_metamorphism.CaMgCO32    process.dolomite_metamorphism.FeCO3    process.dolomite_metamorphism.CaSiO3    process.dolomite_metamorphism.MgSiO3    process.dolomite_metamorphism.Na2SiO3    process.dolomite_metamorphism.K2SiO3    process.dolomite_metamorphism.FeSiO3    process.dolomite_metamorphism.SiO2_solid    process.dolomite_metamorphism.CH2O    process.dolomite_metamorphism.FeS2    process.dolomite_metamorphism.Fe2O3    process.dolomite_metamorphism.CaSO4_2H2O    process.dolomite_metamorphism.NaCl    process.dolomite_metamorphism.mantle_CO2    process.dolomite_metamorphism.mantle_HCl    process.dolomite_metamorphism.mantle_H2S  ]'; % reaction #5:  dolomite metamorphism
process.siderite_metamorphism.vector_closed      = [process.siderite_metamorphism.vector_exchange'    process.siderite_metamorphism.H2O    process.siderite_metamorphism.CaCO3    process.siderite_metamorphism.CaMgCO32    process.siderite_metamorphism.FeCO3    process.siderite_metamorphism.CaSiO3    process.siderite_metamorphism.MgSiO3    process.siderite_metamorphism.Na2SiO3    process.siderite_metamorphism.K2SiO3    process.siderite_metamorphism.FeSiO3    process.siderite_metamorphism.SiO2_solid    process.siderite_metamorphism.CH2O    process.siderite_metamorphism.FeS2    process.siderite_metamorphism.Fe2O3    process.siderite_metamorphism.CaSO4_2H2O    process.siderite_metamorphism.NaCl    process.siderite_metamorphism.mantle_CO2    process.siderite_metamorphism.mantle_HCl    process.siderite_metamorphism.mantle_H2S  ]'; % reaction #6:  siderite metamorphism
process.Ca_silicate_weathering.vector_closed     = [process.Ca_silicate_weathering.vector_exchange'   process.Ca_silicate_weathering.H2O   process.Ca_silicate_weathering.CaCO3   process.Ca_silicate_weathering.CaMgCO32   process.Ca_silicate_weathering.FeCO3   process.Ca_silicate_weathering.CaSiO3   process.Ca_silicate_weathering.MgSiO3   process.Ca_silicate_weathering.Na2SiO3   process.Ca_silicate_weathering.K2SiO3   process.Ca_silicate_weathering.FeSiO3   process.Ca_silicate_weathering.SiO2_solid   process.Ca_silicate_weathering.CH2O   process.Ca_silicate_weathering.FeS2   process.Ca_silicate_weathering.Fe2O3   process.Ca_silicate_weathering.CaSO4_2H2O   process.Ca_silicate_weathering.NaCl   process.Ca_silicate_weathering.mantle_CO2   process.Ca_silicate_weathering.mantle_HCl   process.Ca_silicate_weathering.mantle_H2S ]'; % reaction #7:  Ca-silicate weathering
process.Mg_silicate_weathering.vector_closed     = [process.Mg_silicate_weathering.vector_exchange'   process.Mg_silicate_weathering.H2O   process.Mg_silicate_weathering.CaCO3   process.Mg_silicate_weathering.CaMgCO32   process.Mg_silicate_weathering.FeCO3   process.Mg_silicate_weathering.CaSiO3   process.Mg_silicate_weathering.MgSiO3   process.Mg_silicate_weathering.Na2SiO3   process.Mg_silicate_weathering.K2SiO3   process.Mg_silicate_weathering.FeSiO3   process.Mg_silicate_weathering.SiO2_solid   process.Mg_silicate_weathering.CH2O   process.Mg_silicate_weathering.FeS2   process.Mg_silicate_weathering.Fe2O3   process.Mg_silicate_weathering.CaSO4_2H2O   process.Mg_silicate_weathering.NaCl   process.Mg_silicate_weathering.mantle_CO2   process.Mg_silicate_weathering.mantle_HCl   process.Mg_silicate_weathering.mantle_H2S ]'; % reaction #8:  Mg-silicate weathering
process.Na_silicate_weathering.vector_closed     = [process.Na_silicate_weathering.vector_exchange'   process.Na_silicate_weathering.H2O   process.Na_silicate_weathering.CaCO3   process.Na_silicate_weathering.CaMgCO32   process.Na_silicate_weathering.FeCO3   process.Na_silicate_weathering.CaSiO3   process.Na_silicate_weathering.MgSiO3   process.Na_silicate_weathering.Na2SiO3   process.Na_silicate_weathering.K2SiO3   process.Na_silicate_weathering.FeSiO3   process.Na_silicate_weathering.SiO2_solid   process.Na_silicate_weathering.CH2O   process.Na_silicate_weathering.FeS2   process.Na_silicate_weathering.Fe2O3   process.Na_silicate_weathering.CaSO4_2H2O   process.Na_silicate_weathering.NaCl   process.Na_silicate_weathering.mantle_CO2   process.Na_silicate_weathering.mantle_HCl   process.Na_silicate_weathering.mantle_H2S ]'; % reaction #9:  Na-silicate weathering
process.K_silicate_weathering.vector_closed      = [process.K_silicate_weathering.vector_exchange'    process.K_silicate_weathering.H2O    process.K_silicate_weathering.CaCO3    process.K_silicate_weathering.CaMgCO32    process.K_silicate_weathering.FeCO3    process.K_silicate_weathering.CaSiO3    process.K_silicate_weathering.MgSiO3    process.K_silicate_weathering.Na2SiO3    process.K_silicate_weathering.K2SiO3    process.K_silicate_weathering.FeSiO3    process.K_silicate_weathering.SiO2_solid    process.K_silicate_weathering.CH2O    process.K_silicate_weathering.FeS2    process.K_silicate_weathering.Fe2O3    process.K_silicate_weathering.CaSO4_2H2O    process.K_silicate_weathering.NaCl    process.K_silicate_weathering.mantle_CO2    process.K_silicate_weathering.mantle_HCl    process.K_silicate_weathering.mantle_H2S  ]'; % reaction #10: K-silicate weathering
process.Fe_silicate_weathering.vector_closed     = [process.Fe_silicate_weathering.vector_exchange'   process.Fe_silicate_weathering.H2O   process.Fe_silicate_weathering.CaCO3   process.Fe_silicate_weathering.CaMgCO32   process.Fe_silicate_weathering.FeCO3   process.Fe_silicate_weathering.CaSiO3   process.Fe_silicate_weathering.MgSiO3   process.Fe_silicate_weathering.Na2SiO3   process.Fe_silicate_weathering.K2SiO3   process.Fe_silicate_weathering.FeSiO3   process.Fe_silicate_weathering.SiO2_solid   process.Fe_silicate_weathering.CH2O   process.Fe_silicate_weathering.FeS2   process.Fe_silicate_weathering.Fe2O3   process.Fe_silicate_weathering.CaSO4_2H2O   process.Fe_silicate_weathering.NaCl   process.Fe_silicate_weathering.mantle_CO2   process.Fe_silicate_weathering.mantle_HCl   process.Fe_silicate_weathering.mantle_H2S ]'; % reaction #11: Fe-silicate weathering
process.calcite_weathering.vector_closed         = [process.calcite_weathering.vector_exchange'       process.calcite_weathering.H2O       process.calcite_weathering.CaCO3       process.calcite_weathering.CaMgCO32       process.calcite_weathering.FeCO3       process.calcite_weathering.CaSiO3       process.calcite_weathering.MgSiO3       process.calcite_weathering.Na2SiO3       process.calcite_weathering.K2SiO3       process.calcite_weathering.FeSiO3       process.calcite_weathering.SiO2_solid       process.calcite_weathering.CH2O       process.calcite_weathering.FeS2       process.calcite_weathering.Fe2O3       process.calcite_weathering.CaSO4_2H2O       process.calcite_weathering.NaCl       process.calcite_weathering.mantle_CO2       process.calcite_weathering.mantle_HCl       process.calcite_weathering.mantle_H2S     ]'; % reaction #12: calcite weathering
process.dolomite_weathering.vector_closed        = [process.dolomite_weathering.vector_exchange'      process.dolomite_weathering.H2O      process.dolomite_weathering.CaCO3      process.dolomite_weathering.CaMgCO32      process.dolomite_weathering.FeCO3      process.dolomite_weathering.CaSiO3      process.dolomite_weathering.MgSiO3      process.dolomite_weathering.Na2SiO3      process.dolomite_weathering.K2SiO3      process.dolomite_weathering.FeSiO3      process.dolomite_weathering.SiO2_solid      process.dolomite_weathering.CH2O      process.dolomite_weathering.FeS2      process.dolomite_weathering.Fe2O3      process.dolomite_weathering.CaSO4_2H2O      process.dolomite_weathering.NaCl      process.dolomite_weathering.mantle_CO2      process.dolomite_weathering.mantle_HCl      process.dolomite_weathering.mantle_H2S    ]'; % reaction #13: dolomite weathering
process.siderite_weathering.vector_closed        = [process.siderite_weathering.vector_exchange'      process.siderite_weathering.H2O      process.siderite_weathering.CaCO3      process.siderite_weathering.CaMgCO32      process.siderite_weathering.FeCO3      process.siderite_weathering.CaSiO3      process.siderite_weathering.MgSiO3      process.siderite_weathering.Na2SiO3      process.siderite_weathering.K2SiO3      process.siderite_weathering.FeSiO3      process.siderite_weathering.SiO2_solid      process.siderite_weathering.CH2O      process.siderite_weathering.FeS2      process.siderite_weathering.Fe2O3      process.siderite_weathering.CaSO4_2H2O      process.siderite_weathering.NaCl      process.siderite_weathering.mantle_CO2      process.siderite_weathering.mantle_HCl      process.siderite_weathering.mantle_H2S    ]'; % reaction #14: siderite weathering
process.silica_weathering.vector_closed          = [process.silica_weathering.vector_exchange'        process.silica_weathering.H2O        process.silica_weathering.CaCO3        process.silica_weathering.CaMgCO32        process.silica_weathering.FeCO3        process.silica_weathering.CaSiO3        process.silica_weathering.MgSiO3        process.silica_weathering.Na2SiO3        process.silica_weathering.K2SiO3        process.silica_weathering.FeSiO3        process.silica_weathering.SiO2_solid        process.silica_weathering.CH2O        process.silica_weathering.FeS2        process.silica_weathering.Fe2O3        process.silica_weathering.CaSO4_2H2O        process.silica_weathering.NaCl        process.silica_weathering.mantle_CO2        process.silica_weathering.mantle_HCl        process.silica_weathering.mantle_H2S      ]'; % reaction #15: silica weathering
process.Mg_reverse_weathering.vector_closed      = [process.Mg_reverse_weathering.vector_exchange'    process.Mg_reverse_weathering.H2O    process.Mg_reverse_weathering.CaCO3    process.Mg_reverse_weathering.CaMgCO32    process.Mg_reverse_weathering.FeCO3    process.Mg_reverse_weathering.CaSiO3    process.Mg_reverse_weathering.MgSiO3    process.Mg_reverse_weathering.Na2SiO3    process.Mg_reverse_weathering.K2SiO3    process.Mg_reverse_weathering.FeSiO3    process.Mg_reverse_weathering.SiO2_solid    process.Mg_reverse_weathering.CH2O    process.Mg_reverse_weathering.FeS2    process.Mg_reverse_weathering.Fe2O3    process.Mg_reverse_weathering.CaSO4_2H2O    process.Mg_reverse_weathering.NaCl    process.Mg_reverse_weathering.mantle_CO2    process.Mg_reverse_weathering.mantle_HCl    process.Mg_reverse_weathering.mantle_H2S  ]'; % reaction #16: Mg-reverse weathering
process.Na_reverse_weathering.vector_closed      = [process.Na_reverse_weathering.vector_exchange'    process.Na_reverse_weathering.H2O    process.Na_reverse_weathering.CaCO3    process.Na_reverse_weathering.CaMgCO32    process.Na_reverse_weathering.FeCO3    process.Na_reverse_weathering.CaSiO3    process.Na_reverse_weathering.MgSiO3    process.Na_reverse_weathering.Na2SiO3    process.Na_reverse_weathering.K2SiO3    process.Na_reverse_weathering.FeSiO3    process.Na_reverse_weathering.SiO2_solid    process.Na_reverse_weathering.CH2O    process.Na_reverse_weathering.FeS2    process.Na_reverse_weathering.Fe2O3    process.Na_reverse_weathering.CaSO4_2H2O    process.Na_reverse_weathering.NaCl    process.Na_reverse_weathering.mantle_CO2    process.Na_reverse_weathering.mantle_HCl    process.Na_reverse_weathering.mantle_H2S  ]'; % reaction #17: Na-reverse weathering
process.K_reverse_weathering.vector_closed       = [process.K_reverse_weathering.vector_exchange'     process.K_reverse_weathering.H2O     process.K_reverse_weathering.CaCO3     process.K_reverse_weathering.CaMgCO32     process.K_reverse_weathering.FeCO3     process.K_reverse_weathering.CaSiO3     process.K_reverse_weathering.MgSiO3     process.K_reverse_weathering.Na2SiO3     process.K_reverse_weathering.K2SiO3     process.K_reverse_weathering.FeSiO3     process.K_reverse_weathering.SiO2_solid     process.K_reverse_weathering.CH2O     process.K_reverse_weathering.FeS2     process.K_reverse_weathering.Fe2O3     process.K_reverse_weathering.CaSO4_2H2O     process.K_reverse_weathering.NaCl     process.K_reverse_weathering.mantle_CO2     process.K_reverse_weathering.mantle_HCl     process.K_reverse_weathering.mantle_H2S   ]'; % reaction #18: K-reverse weathering
process.Fe_reverse_weathering.vector_closed      = [process.Fe_reverse_weathering.vector_exchange'    process.Fe_reverse_weathering.H2O    process.Fe_reverse_weathering.CaCO3    process.Fe_reverse_weathering.CaMgCO32    process.Fe_reverse_weathering.FeCO3    process.Fe_reverse_weathering.CaSiO3    process.Fe_reverse_weathering.MgSiO3    process.Fe_reverse_weathering.Na2SiO3    process.Fe_reverse_weathering.K2SiO3    process.Fe_reverse_weathering.FeSiO3    process.Fe_reverse_weathering.SiO2_solid    process.Fe_reverse_weathering.CH2O    process.Fe_reverse_weathering.FeS2    process.Fe_reverse_weathering.Fe2O3    process.Fe_reverse_weathering.CaSO4_2H2O    process.Fe_reverse_weathering.NaCl    process.Fe_reverse_weathering.mantle_CO2    process.Fe_reverse_weathering.mantle_HCl    process.Fe_reverse_weathering.mantle_H2S  ]'; % reaction #19: Fe-reverse weathering
process.silica_formation.vector_closed           = [process.silica_formation.vector_exchange'         process.silica_formation.H2O         process.silica_formation.CaCO3         process.silica_formation.CaMgCO32         process.silica_formation.FeCO3         process.silica_formation.CaSiO3         process.silica_formation.MgSiO3         process.silica_formation.Na2SiO3         process.silica_formation.K2SiO3         process.silica_formation.FeSiO3         process.silica_formation.SiO2_solid         process.silica_formation.CH2O         process.silica_formation.FeS2         process.silica_formation.Fe2O3         process.silica_formation.CaSO4_2H2O         process.silica_formation.NaCl         process.silica_formation.mantle_CO2         process.silica_formation.mantle_HCl         process.silica_formation.mantle_H2S       ]'; % reaction #20: silica formation
process.calcite_formation.vector_closed          = [process.calcite_formation.vector_exchange'        process.calcite_formation.H2O        process.calcite_formation.CaCO3        process.calcite_formation.CaMgCO32        process.calcite_formation.FeCO3        process.calcite_formation.CaSiO3        process.calcite_formation.MgSiO3        process.calcite_formation.Na2SiO3        process.calcite_formation.K2SiO3        process.calcite_formation.FeSiO3        process.calcite_formation.SiO2_solid        process.calcite_formation.CH2O        process.calcite_formation.FeS2        process.calcite_formation.Fe2O3        process.calcite_formation.CaSO4_2H2O        process.calcite_formation.NaCl        process.calcite_formation.mantle_CO2        process.calcite_formation.mantle_HCl        process.calcite_formation.mantle_H2S      ]'; % reaction #21: calcite formation
process.dolomite_formation.vector_closed         = [process.dolomite_formation.vector_exchange'       process.dolomite_formation.H2O       process.dolomite_formation.CaCO3       process.dolomite_formation.CaMgCO32       process.dolomite_formation.FeCO3       process.dolomite_formation.CaSiO3       process.dolomite_formation.MgSiO3       process.dolomite_formation.Na2SiO3       process.dolomite_formation.K2SiO3       process.dolomite_formation.FeSiO3       process.dolomite_formation.SiO2_solid       process.dolomite_formation.CH2O       process.dolomite_formation.FeS2       process.dolomite_formation.Fe2O3       process.dolomite_formation.CaSO4_2H2O       process.dolomite_formation.NaCl       process.dolomite_formation.mantle_CO2       process.dolomite_formation.mantle_HCl       process.dolomite_formation.mantle_H2S     ]'; % reaction #22: dolomite formation
process.siderite_formation.vector_closed         = [process.siderite_formation.vector_exchange'       process.siderite_formation.H2O       process.siderite_formation.CaCO3       process.siderite_formation.CaMgCO32       process.siderite_formation.FeCO3       process.siderite_formation.CaSiO3       process.siderite_formation.MgSiO3       process.siderite_formation.Na2SiO3       process.siderite_formation.K2SiO3       process.siderite_formation.FeSiO3       process.siderite_formation.SiO2_solid       process.siderite_formation.CH2O       process.siderite_formation.FeS2       process.siderite_formation.Fe2O3       process.siderite_formation.CaSO4_2H2O       process.siderite_formation.NaCl       process.siderite_formation.mantle_CO2       process.siderite_formation.mantle_HCl       process.siderite_formation.mantle_H2S     ]'; % reaction #23: siderite formation
process.oxygenic_photosynthesis.vector_closed    = [process.oxygenic_photosynthesis.vector_exchange'  process.oxygenic_photosynthesis.H2O  process.oxygenic_photosynthesis.CaCO3  process.oxygenic_photosynthesis.CaMgCO32  process.oxygenic_photosynthesis.FeCO3  process.oxygenic_photosynthesis.CaSiO3  process.oxygenic_photosynthesis.MgSiO3  process.oxygenic_photosynthesis.Na2SiO3  process.oxygenic_photosynthesis.K2SiO3  process.oxygenic_photosynthesis.FeSiO3  process.oxygenic_photosynthesis.SiO2_solid  process.oxygenic_photosynthesis.CH2O  process.oxygenic_photosynthesis.FeS2  process.oxygenic_photosynthesis.Fe2O3  process.oxygenic_photosynthesis.CaSO4_2H2O  process.oxygenic_photosynthesis.NaCl  process.oxygenic_photosynthesis.mantle_CO2  process.oxygenic_photosynthesis.mantle_HCl  process.oxygenic_photosynthesis.mantle_H2S]'; % reaction #24: oxygenic photosynthesis
process.aerobic_respiration.vector_closed        = [process.aerobic_respiration.vector_exchange'      process.aerobic_respiration.H2O      process.aerobic_respiration.CaCO3      process.aerobic_respiration.CaMgCO32      process.aerobic_respiration.FeCO3      process.aerobic_respiration.CaSiO3      process.aerobic_respiration.MgSiO3      process.aerobic_respiration.Na2SiO3      process.aerobic_respiration.K2SiO3      process.aerobic_respiration.FeSiO3      process.aerobic_respiration.SiO2_solid      process.aerobic_respiration.CH2O      process.aerobic_respiration.FeS2      process.aerobic_respiration.Fe2O3      process.aerobic_respiration.CaSO4_2H2O      process.aerobic_respiration.NaCl      process.aerobic_respiration.mantle_CO2      process.aerobic_respiration.mantle_HCl      process.aerobic_respiration.mantle_H2S    ]'; % reaction #25: aerobic respiration
process.sulfide_oxidation.vector_closed          = [process.sulfide_oxidation.vector_exchange'        process.sulfide_oxidation.H2O        process.sulfide_oxidation.CaCO3        process.sulfide_oxidation.CaMgCO32        process.sulfide_oxidation.FeCO3        process.sulfide_oxidation.CaSiO3        process.sulfide_oxidation.MgSiO3        process.sulfide_oxidation.Na2SiO3        process.sulfide_oxidation.K2SiO3        process.sulfide_oxidation.FeSiO3        process.sulfide_oxidation.SiO2_solid        process.sulfide_oxidation.CH2O        process.sulfide_oxidation.FeS2        process.sulfide_oxidation.Fe2O3        process.sulfide_oxidation.CaSO4_2H2O        process.sulfide_oxidation.NaCl        process.sulfide_oxidation.mantle_CO2        process.sulfide_oxidation.mantle_HCl        process.sulfide_oxidation.mantle_H2S      ]'; % reaction #26: sulfide oxidation
process.sulfate_reduction.vector_closed          = [process.sulfate_reduction.vector_exchange'        process.sulfate_reduction.H2O        process.sulfate_reduction.CaCO3        process.sulfate_reduction.CaMgCO32        process.sulfate_reduction.FeCO3        process.sulfate_reduction.CaSiO3        process.sulfate_reduction.MgSiO3        process.sulfate_reduction.Na2SiO3        process.sulfate_reduction.K2SiO3        process.sulfate_reduction.FeSiO3        process.sulfate_reduction.SiO2_solid        process.sulfate_reduction.CH2O        process.sulfate_reduction.FeS2        process.sulfate_reduction.Fe2O3        process.sulfate_reduction.CaSO4_2H2O        process.sulfate_reduction.NaCl        process.sulfate_reduction.mantle_CO2        process.sulfate_reduction.mantle_HCl        process.sulfate_reduction.mantle_H2S      ]'; % reaction #27: sulfate reduction
process.ferrous_iron_oxidation.vector_closed     = [process.ferrous_iron_oxidation.vector_exchange'   process.ferrous_iron_oxidation.H2O   process.ferrous_iron_oxidation.CaCO3   process.ferrous_iron_oxidation.CaMgCO32   process.ferrous_iron_oxidation.FeCO3   process.ferrous_iron_oxidation.CaSiO3   process.ferrous_iron_oxidation.MgSiO3   process.ferrous_iron_oxidation.Na2SiO3   process.ferrous_iron_oxidation.K2SiO3   process.ferrous_iron_oxidation.FeSiO3   process.ferrous_iron_oxidation.SiO2_solid   process.ferrous_iron_oxidation.CH2O   process.ferrous_iron_oxidation.FeS2   process.ferrous_iron_oxidation.Fe2O3   process.ferrous_iron_oxidation.CaSO4_2H2O   process.ferrous_iron_oxidation.NaCl   process.ferrous_iron_oxidation.mantle_CO2   process.ferrous_iron_oxidation.mantle_HCl   process.ferrous_iron_oxidation.mantle_H2S ]'; % reaction #28: ferrous iron oxidation
process.ferric_iron_reduction.vector_closed      = [process.ferric_iron_reduction.vector_exchange'    process.ferric_iron_reduction.H2O    process.ferric_iron_reduction.CaCO3    process.ferric_iron_reduction.CaMgCO32    process.ferric_iron_reduction.FeCO3    process.ferric_iron_reduction.CaSiO3    process.ferric_iron_reduction.MgSiO3    process.ferric_iron_reduction.Na2SiO3    process.ferric_iron_reduction.K2SiO3    process.ferric_iron_reduction.FeSiO3    process.ferric_iron_reduction.SiO2_solid    process.ferric_iron_reduction.CH2O    process.ferric_iron_reduction.FeS2    process.ferric_iron_reduction.Fe2O3    process.ferric_iron_reduction.CaSO4_2H2O    process.ferric_iron_reduction.NaCl    process.ferric_iron_reduction.mantle_CO2    process.ferric_iron_reduction.mantle_HCl    process.ferric_iron_reduction.mantle_H2S  ]'; % reaction #29: ferric iron reduction
process.pyrite_oxidation.vector_closed           = [process.pyrite_oxidation.vector_exchange'         process.pyrite_oxidation.H2O         process.pyrite_oxidation.CaCO3         process.pyrite_oxidation.CaMgCO32         process.pyrite_oxidation.FeCO3         process.pyrite_oxidation.CaSiO3         process.pyrite_oxidation.MgSiO3         process.pyrite_oxidation.Na2SiO3         process.pyrite_oxidation.K2SiO3         process.pyrite_oxidation.FeSiO3         process.pyrite_oxidation.SiO2_solid         process.pyrite_oxidation.CH2O         process.pyrite_oxidation.FeS2         process.pyrite_oxidation.Fe2O3         process.pyrite_oxidation.CaSO4_2H2O         process.pyrite_oxidation.NaCl         process.pyrite_oxidation.mantle_CO2         process.pyrite_oxidation.mantle_HCl         process.pyrite_oxidation.mantle_H2S       ]'; % reaction #30: pyrite oxidation
process.pyrite_formation.vector_closed           = [process.pyrite_formation.vector_exchange'         process.pyrite_formation.H2O         process.pyrite_formation.CaCO3         process.pyrite_formation.CaMgCO32         process.pyrite_formation.FeCO3         process.pyrite_formation.CaSiO3         process.pyrite_formation.MgSiO3         process.pyrite_formation.Na2SiO3         process.pyrite_formation.K2SiO3         process.pyrite_formation.FeSiO3         process.pyrite_formation.SiO2_solid         process.pyrite_formation.CH2O         process.pyrite_formation.FeS2         process.pyrite_formation.Fe2O3         process.pyrite_formation.CaSO4_2H2O         process.pyrite_formation.NaCl         process.pyrite_formation.mantle_CO2         process.pyrite_formation.mantle_HCl         process.pyrite_formation.mantle_H2S       ]'; % reaction #31: pyrite formation
process.gypsum_dissolution.vector_closed         = [process.gypsum_dissolution.vector_exchange'       process.gypsum_dissolution.H2O       process.gypsum_dissolution.CaCO3       process.gypsum_dissolution.CaMgCO32       process.gypsum_dissolution.FeCO3       process.gypsum_dissolution.CaSiO3       process.gypsum_dissolution.MgSiO3       process.gypsum_dissolution.Na2SiO3       process.gypsum_dissolution.K2SiO3       process.gypsum_dissolution.FeSiO3       process.gypsum_dissolution.SiO2_solid       process.gypsum_dissolution.CH2O       process.gypsum_dissolution.FeS2       process.gypsum_dissolution.Fe2O3       process.gypsum_dissolution.CaSO4_2H2O       process.gypsum_dissolution.NaCl       process.gypsum_dissolution.mantle_CO2       process.gypsum_dissolution.mantle_HCl       process.gypsum_dissolution.mantle_H2S     ]'; % reaction #32: gypsum dissolution
process.gypsum_formation.vector_closed           = [process.gypsum_formation.vector_exchange'         process.gypsum_formation.H2O         process.gypsum_formation.CaCO3         process.gypsum_formation.CaMgCO32         process.gypsum_formation.FeCO3         process.gypsum_formation.CaSiO3         process.gypsum_formation.MgSiO3         process.gypsum_formation.Na2SiO3         process.gypsum_formation.K2SiO3         process.gypsum_formation.FeSiO3         process.gypsum_formation.SiO2_solid         process.gypsum_formation.CH2O         process.gypsum_formation.FeS2         process.gypsum_formation.Fe2O3         process.gypsum_formation.CaSO4_2H2O         process.gypsum_formation.NaCl         process.gypsum_formation.mantle_CO2         process.gypsum_formation.mantle_HCl         process.gypsum_formation.mantle_H2S       ]'; % reaction #33: gypsum formation
process.halite_dissolution.vector_closed         = [process.halite_dissolution.vector_exchange'       process.halite_dissolution.H2O       process.halite_dissolution.CaCO3       process.halite_dissolution.CaMgCO32       process.halite_dissolution.FeCO3       process.halite_dissolution.CaSiO3       process.halite_dissolution.MgSiO3       process.halite_dissolution.Na2SiO3       process.halite_dissolution.K2SiO3       process.halite_dissolution.FeSiO3       process.halite_dissolution.SiO2_solid       process.halite_dissolution.CH2O       process.halite_dissolution.FeS2       process.halite_dissolution.Fe2O3       process.halite_dissolution.CaSO4_2H2O       process.halite_dissolution.NaCl       process.halite_dissolution.mantle_CO2       process.halite_dissolution.mantle_HCl       process.halite_dissolution.mantle_H2S     ]'; % reaction #34: halite dissolution
process.halite_formation.vector_closed           = [process.halite_formation.vector_exchange'         process.halite_formation.H2O         process.halite_formation.CaCO3         process.halite_formation.CaMgCO32         process.halite_formation.FeCO3         process.halite_formation.CaSiO3         process.halite_formation.MgSiO3         process.halite_formation.Na2SiO3         process.halite_formation.K2SiO3         process.halite_formation.FeSiO3         process.halite_formation.SiO2_solid         process.halite_formation.CH2O         process.halite_formation.FeS2         process.halite_formation.Fe2O3         process.halite_formation.CaSO4_2H2O         process.halite_formation.NaCl         process.halite_formation.mantle_CO2         process.halite_formation.mantle_HCl         process.halite_formation.mantle_H2S       ]'; % reaction #35: halite formation
process.dinitrogen_fixation.vector_closed        = [process.dinitrogen_fixation.vector_exchange'      process.dinitrogen_fixation.H2O      process.dinitrogen_fixation.CaCO3      process.dinitrogen_fixation.CaMgCO32      process.dinitrogen_fixation.FeCO3      process.dinitrogen_fixation.CaSiO3      process.dinitrogen_fixation.MgSiO3      process.dinitrogen_fixation.Na2SiO3      process.dinitrogen_fixation.K2SiO3      process.dinitrogen_fixation.FeSiO3      process.dinitrogen_fixation.SiO2_solid      process.dinitrogen_fixation.CH2O      process.dinitrogen_fixation.FeS2      process.dinitrogen_fixation.Fe2O3      process.dinitrogen_fixation.CaSO4_2H2O      process.dinitrogen_fixation.NaCl      process.dinitrogen_fixation.mantle_CO2      process.dinitrogen_fixation.mantle_HCl      process.dinitrogen_fixation.mantle_H2S    ]'; % reaction #36: dinitrogen fixation
process.nitrification.vector_closed              = [process.nitrification.vector_exchange'            process.nitrification.H2O            process.nitrification.CaCO3            process.nitrification.CaMgCO32            process.nitrification.FeCO3            process.nitrification.CaSiO3            process.nitrification.MgSiO3            process.nitrification.Na2SiO3            process.nitrification.K2SiO3            process.nitrification.FeSiO3            process.nitrification.SiO2_solid            process.nitrification.CH2O            process.nitrification.FeS2            process.nitrification.Fe2O3            process.nitrification.CaSO4_2H2O            process.nitrification.NaCl            process.nitrification.mantle_CO2            process.nitrification.mantle_HCl            process.nitrification.mantle_H2S          ]'; % reaction #37: nitrification
process.denitrification.vector_closed            = [process.denitrification.vector_exchange'          process.denitrification.H2O          process.denitrification.CaCO3          process.denitrification.CaMgCO32          process.denitrification.FeCO3          process.denitrification.CaSiO3          process.denitrification.MgSiO3          process.denitrification.Na2SiO3          process.denitrification.K2SiO3          process.denitrification.FeSiO3          process.denitrification.SiO2_solid          process.denitrification.CH2O          process.denitrification.FeS2          process.denitrification.Fe2O3          process.denitrification.CaSO4_2H2O          process.denitrification.NaCl          process.denitrification.mantle_CO2          process.denitrification.mantle_HCl          process.denitrification.mantle_H2S        ]'; % reaction #38: denitrification

%  combine the variable lists into aggregated lists
var_list_closed        = cat(2,var_list_exchange,var_list_solid);
var_list_search_closed = cat(2,var_list_exchange_search,var_list_solid_search);
clear var_list;          var_list = struct;
var_list.open            = var_list_open;            clear var_list_open;
var_list.exchange        = var_list_exchange;        clear var_list_exchange;
var_list.solid           = var_list_solid;           clear var_list_solid;
var_list.closed          = var_list_closed;          clear var_list_closed;
var_list.search_open     = var_list_open_search;     clear var_list_open_search;
var_list.search_exchange = var_list_exchange_search; clear var_list_exchange_search;
var_list.search_solid    = var_list_solid_search;    clear var_list_solid_search;
var_list.search_closed   = var_list_search_closed;   clear var_list_search_closed;


%% 3. assemble the closed, exchange, and open matricies
Aopen        = []; % for building Aopen
Aexchange    = []; % for building Aexchange
Aclosed      = []; % for building Aclosed
process_list = {}; % accumulating list of process names
count        = 1;  % counter

% for each process, augment the growing Aopen, Aexchange, and Aclosed matricies
Aopen = [Aopen process.mantle_CO2.vector_open];               Aexchange = [Aexchange process.mantle_CO2.vector_exchange];               Aclosed = [Aclosed process.mantle_CO2.vector_closed];               process_list{1,count} = sprintf('%s: mantle_CO2',num2str(count));              count = count+1; % reaction #1:  mantle degassing of CO2
Aopen = [Aopen process.mantle_HCl.vector_open];               Aexchange = [Aexchange process.mantle_HCl.vector_exchange];               Aclosed = [Aclosed process.mantle_HCl.vector_closed];               process_list{1,count} = sprintf('%s: mantle_HCl',num2str(count));              count = count+1; % reaction #2:  mantle degassing of HCl
Aopen = [Aopen process.mantle_H2S.vector_open];               Aexchange = [Aexchange process.mantle_H2S.vector_exchange];               Aclosed = [Aclosed process.mantle_H2S.vector_closed];               process_list{1,count} = sprintf('%s: mantle_H2S',num2str(count));              count = count+1; % reaction #3:  mantle degassing of H2S
Aopen = [Aopen process.calcite_metamorphism.vector_open];     Aexchange = [Aexchange process.calcite_metamorphism.vector_exchange];     Aclosed = [Aclosed process.calcite_metamorphism.vector_closed];     process_list{1,count} = sprintf('%s: calcite_metamorphism',num2str(count));    count = count+1; % reaction #4:  calcite metamorphism
Aopen = [Aopen process.dolomite_metamorphism.vector_open];    Aexchange = [Aexchange process.dolomite_metamorphism.vector_exchange];    Aclosed = [Aclosed process.dolomite_metamorphism.vector_closed];    process_list{1,count} = sprintf('%s: dolomite_metamorphism',num2str(count));   count = count+1; % reaction #5:  dolomite metamorphism
Aopen = [Aopen process.siderite_metamorphism.vector_open];    Aexchange = [Aexchange process.siderite_metamorphism.vector_exchange];    Aclosed = [Aclosed process.siderite_metamorphism.vector_closed];    process_list{1,count} = sprintf('%s: siderite_metamorphism',num2str(count));   count = count+1; % reaction #6:  siderite metamorphism
Aopen = [Aopen process.Ca_silicate_weathering.vector_open];   Aexchange = [Aexchange process.Ca_silicate_weathering.vector_exchange];   Aclosed = [Aclosed process.Ca_silicate_weathering.vector_closed];   process_list{1,count} = sprintf('%s: Ca_silicate_weathering',num2str(count));  count = count+1; % reaction #7:  Ca-silicate weathering
Aopen = [Aopen process.Mg_silicate_weathering.vector_open];   Aexchange = [Aexchange process.Mg_silicate_weathering.vector_exchange];   Aclosed = [Aclosed process.Mg_silicate_weathering.vector_closed];   process_list{1,count} = sprintf('%s: Mg_silicate_weathering',num2str(count));  count = count+1; % reaction #8:  Mg-silicate weathering
Aopen = [Aopen process.Na_silicate_weathering.vector_open];   Aexchange = [Aexchange process.Na_silicate_weathering.vector_exchange];   Aclosed = [Aclosed process.Na_silicate_weathering.vector_closed];   process_list{1,count} = sprintf('%s: Na_silicate_weathering',num2str(count));  count = count+1; % reaction #9:  Na-silicate weathering
Aopen = [Aopen process.K_silicate_weathering.vector_open];    Aexchange = [Aexchange process.K_silicate_weathering.vector_exchange];    Aclosed = [Aclosed process.K_silicate_weathering.vector_closed];    process_list{1,count} = sprintf('%s: K_silicate_weathering',num2str(count));   count = count+1; % reaction #10: K-silicate weathering
Aopen = [Aopen process.Fe_silicate_weathering.vector_open];   Aexchange = [Aexchange process.Fe_silicate_weathering.vector_exchange];   Aclosed = [Aclosed process.Fe_silicate_weathering.vector_closed];   process_list{1,count} = sprintf('%s: Fe_silicate_weathering',num2str(count));  count = count+1; % reaction #11: Fe-silicate weathering
Aopen = [Aopen process.calcite_weathering.vector_open];       Aexchange = [Aexchange process.calcite_weathering.vector_exchange];       Aclosed = [Aclosed process.calcite_weathering.vector_closed];       process_list{1,count} = sprintf('%s: calcite_weathering',num2str(count));      count = count+1; % reaction #12: calcite weathering
Aopen = [Aopen process.dolomite_weathering.vector_open];      Aexchange = [Aexchange process.dolomite_weathering.vector_exchange];      Aclosed = [Aclosed process.dolomite_weathering.vector_closed];      process_list{1,count} = sprintf('%s: dolomite_weathering',num2str(count));     count = count+1; % reaction #13: dolomite weathering
Aopen = [Aopen process.siderite_weathering.vector_open];      Aexchange = [Aexchange process.siderite_weathering.vector_exchange];      Aclosed = [Aclosed process.siderite_weathering.vector_closed];      process_list{1,count} = sprintf('%s: siderite_weathering',num2str(count));     count = count+1; % reaction #14: siderite weathering
Aopen = [Aopen process.silica_weathering.vector_open];        Aexchange = [Aexchange process.silica_weathering.vector_exchange];        Aclosed = [Aclosed process.silica_weathering.vector_closed];        process_list{1,count} = sprintf('%s: silica_weathering',num2str(count));       count = count+1; % reaction #15: silica weathering
Aopen = [Aopen process.Mg_reverse_weathering.vector_open];    Aexchange = [Aexchange process.Mg_reverse_weathering.vector_exchange];    Aclosed = [Aclosed process.Mg_reverse_weathering.vector_closed];    process_list{1,count} = sprintf('%s: Mg_reverse_weathering',num2str(count));   count = count+1; % reaction #16: Mg-reverse weathering
Aopen = [Aopen process.Na_reverse_weathering.vector_open];    Aexchange = [Aexchange process.Na_reverse_weathering.vector_exchange];    Aclosed = [Aclosed process.Na_reverse_weathering.vector_closed];    process_list{1,count} = sprintf('%s: Na_reverse_weathering',num2str(count));   count = count+1; % reaction #17: Na-reverse weathering
Aopen = [Aopen process.K_reverse_weathering.vector_open];     Aexchange = [Aexchange process.K_reverse_weathering.vector_exchange];     Aclosed = [Aclosed process.K_reverse_weathering.vector_closed];     process_list{1,count} = sprintf('%s: K_reverse_weathering',num2str(count));    count = count+1; % reaction #18: K-reverse weathering
Aopen = [Aopen process.Fe_reverse_weathering.vector_open];    Aexchange = [Aexchange process.Fe_reverse_weathering.vector_exchange];    Aclosed = [Aclosed process.Fe_reverse_weathering.vector_closed];    process_list{1,count} = sprintf('%s: Fe_reverse_weathering',num2str(count));   count = count+1; % reaction #19: Fe-reverse weathering
Aopen = [Aopen process.silica_formation.vector_open];         Aexchange = [Aexchange process.silica_formation.vector_exchange];         Aclosed = [Aclosed process.silica_formation.vector_closed];         process_list{1,count} = sprintf('%s: silica_formation',num2str(count));        count = count+1; % reaction #20: silica formation
Aopen = [Aopen process.calcite_formation.vector_open];        Aexchange = [Aexchange process.calcite_formation.vector_exchange];        Aclosed = [Aclosed process.calcite_formation.vector_closed];        process_list{1,count} = sprintf('%s: calcite_formation',num2str(count));       count = count+1; % reaction #21: calcite formation
Aopen = [Aopen process.dolomite_formation.vector_open];       Aexchange = [Aexchange process.dolomite_formation.vector_exchange];       Aclosed = [Aclosed process.dolomite_formation.vector_closed];       process_list{1,count} = sprintf('%s: dolomite_formation',num2str(count));      count = count+1; % reaction #22: dolomite formation
Aopen = [Aopen process.siderite_formation.vector_open];       Aexchange = [Aexchange process.siderite_formation.vector_exchange];       Aclosed = [Aclosed process.siderite_formation.vector_closed];       process_list{1,count} = sprintf('%s: siderite_formation',num2str(count));      count = count+1; % reaction #23: siderite formation
Aopen = [Aopen process.oxygenic_photosynthesis.vector_open];  Aexchange = [Aexchange process.oxygenic_photosynthesis.vector_exchange];  Aclosed = [Aclosed process.oxygenic_photosynthesis.vector_closed];  process_list{1,count} = sprintf('%s: oxygenic_photosynthesis',num2str(count)); count = count+1; % reaction #24: oxygenic photosynthesis
Aopen = [Aopen process.aerobic_respiration.vector_open];      Aexchange = [Aexchange process.aerobic_respiration.vector_exchange];      Aclosed = [Aclosed process.aerobic_respiration.vector_closed];      process_list{1,count} = sprintf('%s: aerobic_respiration',num2str(count));     count = count+1; % reaction #25: aerobic respiration
Aopen = [Aopen process.sulfide_oxidation.vector_open];        Aexchange = [Aexchange process.sulfide_oxidation.vector_exchange];        Aclosed = [Aclosed process.sulfide_oxidation.vector_closed];        process_list{1,count} = sprintf('%s: sulfide_oxidation',num2str(count));       count = count+1; % reaction #26: sulfide oxidation
Aopen = [Aopen process.sulfate_reduction.vector_open];        Aexchange = [Aexchange process.sulfate_reduction.vector_exchange];        Aclosed = [Aclosed process.sulfate_reduction.vector_closed];        process_list{1,count} = sprintf('%s: sulfate_reduction',num2str(count));       count = count+1; % reaction #27: sulfate reduction
Aopen = [Aopen process.ferrous_iron_oxidation.vector_open];   Aexchange = [Aexchange process.ferrous_iron_oxidation.vector_exchange];   Aclosed = [Aclosed process.ferrous_iron_oxidation.vector_closed];   process_list{1,count} = sprintf('%s: ferrous_iron_oxidation',num2str(count));  count = count+1; % reaction #28: ferrous iron oxidation
Aopen = [Aopen process.ferric_iron_reduction.vector_open];    Aexchange = [Aexchange process.ferric_iron_reduction.vector_exchange];    Aclosed = [Aclosed process.ferric_iron_reduction.vector_closed];    process_list{1,count} = sprintf('%s: ferric_iron_reduction',num2str(count));   count = count+1; % reaction #29: ferric iron reduction
Aopen = [Aopen process.pyrite_oxidation.vector_open];         Aexchange = [Aexchange process.pyrite_oxidation.vector_exchange];         Aclosed = [Aclosed process.pyrite_oxidation.vector_closed];         process_list{1,count} = sprintf('%s: pyrite_oxidation',num2str(count));        count = count+1; % reaction #30: pyrite oxidation
Aopen = [Aopen process.pyrite_formation.vector_open];         Aexchange = [Aexchange process.pyrite_formation.vector_exchange];         Aclosed = [Aclosed process.pyrite_formation.vector_closed];         process_list{1,count} = sprintf('%s: pyrite_formation',num2str(count));        count = count+1; % reaction #31: pyrite formation
Aopen = [Aopen process.gypsum_dissolution.vector_open];       Aexchange = [Aexchange process.gypsum_dissolution.vector_exchange];       Aclosed = [Aclosed process.gypsum_dissolution.vector_closed];       process_list{1,count} = sprintf('%s: gypsum_dissolution',num2str(count));      count = count+1; % reaction #32: gypsum dissolution
Aopen = [Aopen process.gypsum_formation.vector_open];         Aexchange = [Aexchange process.gypsum_formation.vector_exchange];         Aclosed = [Aclosed process.gypsum_formation.vector_closed];         process_list{1,count} = sprintf('%s: gypsum_formation',num2str(count));        count = count+1; % reaction #33: gypsum formation
Aopen = [Aopen process.halite_dissolution.vector_open];       Aexchange = [Aexchange process.halite_dissolution.vector_exchange];       Aclosed = [Aclosed process.halite_dissolution.vector_closed];       process_list{1,count} = sprintf('%s: halite_dissolution',num2str(count));      count = count+1; % reaction #34: halite dissolution
Aopen = [Aopen process.halite_formation.vector_open];         Aexchange = [Aexchange process.halite_formation.vector_exchange];         Aclosed = [Aclosed process.halite_formation.vector_closed];         process_list{1,count} = sprintf('%s: halite_formation',num2str(count));        count = count+1; % reaction #35: halite formation
Aopen = [Aopen process.dinitrogen_fixation.vector_open];      Aexchange = [Aexchange process.dinitrogen_fixation.vector_exchange];      Aclosed = [Aclosed process.dinitrogen_fixation.vector_closed];      process_list{1,count} = sprintf('%s: nitrogen_fixation',num2str(count));       count = count+1; % reaction #36: dinitrogen fixation
Aopen = [Aopen process.nitrification.vector_open];            Aexchange = [Aexchange process.nitrification.vector_exchange];            Aclosed = [Aclosed process.nitrification.vector_closed];            process_list{1,count} = sprintf('%s: nitrification',num2str(count));           count = count+1; % reaction #37: nitrification
Aopen = [Aopen process.denitrification.vector_open];          Aexchange = [Aexchange process.denitrification.vector_exchange];          Aclosed = [Aclosed process.denitrification.vector_closed];          process_list{1,count} = sprintf('%s: denitrification',num2str(count));         count = count+1; % reaction #38: denitrification

clear count;

