%% PrimaryScript
% this is the primary script that organizes the analysis for Kemeny et al. (2024)
% "Balance and imbalance in biogeochemical cycles: closed, exchange, and open sets".
% contact Preston Cosslett Kemeny with any questions at preston.kemeny@gmail.com
% last edit February 5, 2024

clc; clearvars; close all;  % clear all variables
calculate_A_matricies;      % define the biogeochemical processes and make matrices
calculate_reactions;        % solve for chemical reactions
calculate_null_spaces;      % calculate the null spaces of Aclosed, Aexchange, and Aopen
calculate_table2_equations; % calculate the chemical reactions for Table 2
calculate_results;          % calculate results cited in the manuscript
plotting_vector_diagrams;   % plot vector diagrams (Figs. 3-6)