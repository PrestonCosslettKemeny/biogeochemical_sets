%% calculate_table2_equations
% this script calculates the chemical 
% reactions in table 2 of the main text.
clear reactants;       reactants       = struct; 
clear varnames;        varnames        = struct;
clear reactant_values; reactant_values = struct; 
clear reactions;       reactions       = struct; 

%% (1) calculate the change in chemical species for each vector
reactants.n19_degassing_Urey     = Aclosed*x.exchange.ex19_degassing_Urey;
reactants.n20_halite_build       = Aclosed*x.exchange.ex20_halite_build;
reactants.n21_pyrite_mantle      = Aclosed*x.exchange.ex21_pyrite_mantle;
reactants.n22_CaMg_switch        = Aclosed*x.exchange.ex22_CaMg_switch;
reactants.n23_CaFe_switch        = Aclosed*x.exchange.ex23_CaFe_switch;
reactants.n24_couple_CS          = Aclosed*x.exchange.ex24_couple_CS;
reactants.n25_couple_CFe         = Aclosed*x.exchange.ex25_couple_CFe;

reactants.FeCaMg_sub             = Aclosed*x.exchange.FeCaMg_sub;
reactants.couple_CS_reverse      = Aclosed*x.exchange.couple_CS_reverse;
reactants.couple_CFe_reverse     = Aclosed*x.exchange.couple_CFe_reverse;
reactants.couple_CFe2            = Aclosed*x.exchange.couple_CFe2;
reactants.couple_SFe             = Aclosed*x.exchange.couple_SFe;
               
reactants.n26_BK15_FeCO3_Fe2O3   = Aclosed*x.open.op26_BK15_FeCO3_Fe2O3;
reactants.n27_sulfox             = Aclosed*x.open.op27_sulfox;
reactants.n28_catswitch          = Aclosed*x.open.op28_catswitch;
reactants.n29_mantle_H2S         = Aclosed*x.open.op29_mantle_H2S;
reactants.n30_Ca_silicate        = Aclosed*x.open.op30_Ca_silicate;
reactants.n31_Na_silicate        = Aclosed*x.open.op31_Na_silicate;
reactants.n32_K_silicate         = Aclosed*x.open.op32_K_silicate;
reactants.n33_Fe_silicate        = Aclosed*x.open.op33_Fe_silicate;
reactants.n34_Si_weathering      = Aclosed*x.open.op34_Si_weathering;
reactants.n35_N2_fixation        = Aclosed*x.open.op35_N2_fixation;
reactants.n36_nitrification      = Aclosed*x.open.op36_nitrification;
        
reactants.BK15_FeCO3_FeSiO3      = Aclosed*x.open.BK15_FeCO3_FeSiO3;
reactants.BK15_CaMgCO3_MgSiO3    = Aclosed*x.open.BK15_CaMgCO3_MgSiO3;


%% (2) isolate only the variables that change
varnames.n19_degassing_Urey      = var_list.closed(reactants.n19_degassing_Urey~=0)';     reactant_values.n19_degassing_Urey     = reactants.n19_degassing_Urey(reactants.n19_degassing_Urey~=0);   
varnames.n20_halite_build        = var_list.closed(reactants.n20_halite_build~=0)';       reactant_values.n20_halite_build       = reactants.n20_halite_build(reactants.n20_halite_build~=0);   
varnames.n21_pyrite_mantle       = var_list.closed(reactants.n21_pyrite_mantle~=0)';      reactant_values.n21_pyrite_mantle      = reactants.n21_pyrite_mantle(reactants.n21_pyrite_mantle~=0);   
varnames.n22_CaMg_switch         = var_list.closed(reactants.n22_CaMg_switch~=0)';        reactant_values.n22_CaMg_switch        = reactants.n22_CaMg_switch(reactants.n22_CaMg_switch~=0);   
varnames.n23_CaFe_switch         = var_list.closed(reactants.n23_CaFe_switch~=0)';        reactant_values.n23_CaFe_switch        = reactants.n23_CaFe_switch(reactants.n23_CaFe_switch~=0);   
varnames.n24_couple_CS           = var_list.closed(reactants.n24_couple_CS~=0)';          reactant_values.n24_couple_CS          = reactants.n24_couple_CS(reactants.n24_couple_CS~=0);   
varnames.n25_couple_CFe          = var_list.closed(reactants.n25_couple_CFe~=0)';         reactant_values.n25_couple_CFe         = reactants.n25_couple_CFe(reactants.n25_couple_CFe~=0);   

varnames.FeCaMg_sub              = var_list.closed(reactants.FeCaMg_sub~=0)';             reactant_values.FeCaMg_sub             = reactants.FeCaMg_sub(reactants.FeCaMg_sub~=0);   
varnames.couple_CS_reverse       = var_list.closed(reactants.couple_CS_reverse~=0)';      reactant_values.couple_CS_reverse      = reactants.couple_CS_reverse(reactants.couple_CS_reverse~=0); 
varnames.couple_CFe_reverse      = var_list.closed(reactants.couple_CFe_reverse~=0)';     reactant_values.couple_CFe_reverse     = reactants.couple_CFe_reverse(reactants.couple_CFe_reverse~=0);   
varnames.couple_CFe2             = var_list.closed(reactants.couple_CFe2~=0)';            reactant_values.couple_CFe2            = reactants.couple_CFe2(reactants.couple_CFe2~=0);   
varnames.couple_SFe              = var_list.closed(reactants.couple_SFe~=0)';             reactant_values.couple_SFe             = reactants.couple_SFe(reactants.couple_SFe~=0);   

varnames.n26_BK15_FeCO3_Fe2O3    = var_list.closed(reactants.n26_BK15_FeCO3_Fe2O3~=0)';   reactant_values.n26_BK15_FeCO3_Fe2O3   = reactants.n26_BK15_FeCO3_Fe2O3(reactants.n26_BK15_FeCO3_Fe2O3~=0);   
varnames.n27_sulfox              = var_list.closed(reactants.n27_sulfox~=0)';             reactant_values.n27_sulfox             = reactants.n27_sulfox(reactants.n27_sulfox~=0);   
varnames.n28_catswitch           = var_list.closed(reactants.n28_catswitch~=0)';          reactant_values.n28_catswitch          = reactants.n28_catswitch(reactants.n28_catswitch~=0);   
varnames.n29_mantle_H2S          = var_list.closed(reactants.n29_mantle_H2S~=0)';         reactant_values.n29_mantle_H2S         = reactants.n29_mantle_H2S(reactants.n29_mantle_H2S~=0);   
varnames.n30_Ca_silicate         = var_list.closed(reactants.n30_Ca_silicate~=0)';        reactant_values.n30_Ca_silicate        = reactants.n30_Ca_silicate(reactants.n30_Ca_silicate~=0);   
varnames.n31_Na_silicate         = var_list.closed(reactants.n31_Na_silicate~=0)';        reactant_values.n31_Na_silicate        = reactants.n31_Na_silicate(reactants.n31_Na_silicate~=0);   
varnames.n32_K_silicate          = var_list.closed(reactants.n32_K_silicate~=0)';         reactant_values.n32_K_silicate         = reactants.n32_K_silicate(reactants.n32_K_silicate~=0);   
varnames.n33_Fe_silicate         = var_list.closed(reactants.n33_Fe_silicate~=0)';        reactant_values.n33_Fe_silicate        = reactants.n33_Fe_silicate(reactants.n33_Fe_silicate~=0);   
varnames.n34_Si_weathering       = var_list.closed(reactants.n34_Si_weathering~=0)';      reactant_values.n34_Si_weathering      = reactants.n34_Si_weathering(reactants.n34_Si_weathering~=0);   
varnames.n35_N2_fixation         = var_list.closed(reactants.n35_N2_fixation~=0)';        reactant_values.n35_N2_fixation        = reactants.n35_N2_fixation(reactants.n35_N2_fixation~=0);   
varnames.n36_nitrification       = var_list.closed(reactants.n36_nitrification~=0)';      reactant_values.n36_nitrification      = reactants.n36_nitrification(reactants.n36_nitrification~=0);          

varnames.BK15_FeCO3_FeSiO3       = var_list.closed(reactants.BK15_FeCO3_FeSiO3~=0)';      reactant_values.BK15_FeCO3_FeSiO3      = reactants.BK15_FeCO3_FeSiO3(reactants.BK15_FeCO3_FeSiO3~=0);   
varnames.BK15_CaMgCO3_MgSiO3     = var_list.closed(reactants.BK15_CaMgCO3_MgSiO3~=0)';    reactant_values.BK15_CaMgCO3_MgSiO3    = reactants.BK15_CaMgCO3_MgSiO3(reactants.BK15_CaMgCO3_MgSiO3~=0);   


%% (3) expand for ease of writing each chemical reaction
reactions.n19_degassing_Urey    = nullCellExpand({varnames.n19_degassing_Urey    reactant_values.n19_degassing_Urey}); 
reactions.n20_halite_build      = nullCellExpand({varnames.n20_halite_build      reactant_values.n20_halite_build}); 
reactions.n21_pyrite_mantle     = nullCellExpand({varnames.n21_pyrite_mantle     reactant_values.n21_pyrite_mantle}); 
reactions.n22_CaMg_switch       = nullCellExpand({varnames.n22_CaMg_switch       reactant_values.n22_CaMg_switch}); 
reactions.n23_CaFe_switch       = nullCellExpand({varnames.n23_CaFe_switch       reactant_values.n23_CaFe_switch}); 
reactions.FeCaMg_sub            = nullCellExpand({varnames.FeCaMg_sub            reactant_values.FeCaMg_sub}); 

reactions.n24_couple_CS         = nullCellExpand({varnames.n24_couple_CS         reactant_values.n24_couple_CS}); 
reactions.couple_CS_reverse     = nullCellExpand({varnames.couple_CS_reverse     reactant_values.couple_CS_reverse}); 
reactions.n25_couple_CFe        = nullCellExpand({varnames.n25_couple_CFe        reactant_values.n25_couple_CFe}); 
reactions.couple_CFe_reverse    = nullCellExpand({varnames.couple_CFe_reverse    reactant_values.couple_CFe_reverse});
reactions.couple_CFe2           = nullCellExpand({varnames.couple_CFe2           reactant_values.couple_CFe2}); 
reactions.couple_SFe            = nullCellExpand({varnames.couple_SFe            reactant_values.couple_SFe}); 

reactions.n26_BK15_FeCO3_Fe2O3  = nullCellExpand({varnames.n26_BK15_FeCO3_Fe2O3  reactant_values.n26_BK15_FeCO3_Fe2O3}); 
reactions.BK15_FeCO3_FeSiO3     = nullCellExpand({varnames.BK15_FeCO3_FeSiO3     reactant_values.BK15_FeCO3_FeSiO3}); 
reactions.BK15_CaMgCO3_MgSiO3   = nullCellExpand({varnames.BK15_CaMgCO3_MgSiO3   reactant_values.BK15_CaMgCO3_MgSiO3}); 

reactions.n27_sulfox            = nullCellExpand({varnames.n27_sulfox            reactant_values.n27_sulfox}); 
reactions.n28_catswitch         = nullCellExpand({varnames.n28_catswitch         reactant_values.n28_catswitch}); 
reactions.n29_mantle_H2S        = nullCellExpand({varnames.n29_mantle_H2S        reactant_values.n29_mantle_H2S}); 
reactions.n30_Ca_silicate       = nullCellExpand({varnames.n30_Ca_silicate       reactant_values.n30_Ca_silicate}); 
reactions.n31_Na_silicate       = nullCellExpand({varnames.n31_Na_silicate       reactant_values.n31_Na_silicate}); 
reactions.n32_K_silicate        = nullCellExpand({varnames.n32_K_silicate        reactant_values.n32_K_silicate}); 
reactions.n33_Fe_silicate       = nullCellExpand({varnames.n33_Fe_silicate       reactant_values.n33_Fe_silicate}); 
reactions.n34_Si_weathering     = nullCellExpand({varnames.n34_Si_weathering     reactant_values.n34_Si_weathering}); 
reactions.n35_N2_fixation       = nullCellExpand({varnames.n35_N2_fixation       reactant_values.n35_N2_fixation}); 
reactions.n36_nitrification     = nullCellExpand({varnames.n36_nitrification     reactant_values.n36_nitrification}); 


%% (4) clean up the workspace
clear reactants*
clear reactant_values*
clear varnames*


