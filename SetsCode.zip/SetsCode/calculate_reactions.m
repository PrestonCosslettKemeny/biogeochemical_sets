%% calculate_prior_reactions
% this script calculates how to reach specific reactions from
% combinations of the biogeochemical processes considered in Table 1. 

% clear variables for manual exchange reaction definitions
clear t; t  = struct; % target change in chemical reservoirs
clear b; b  = struct; % actual change in chemical reservoirs
clear x; x  = struct; % vector of process magnitudes 

%% exchange: Urey degassing
% CO2 (mantle) + CaSiO3 --> CaCO3 + SiO2 (solid) 
t.manual.exchange_degassing_Urey                                                    = zeros(33,1); 
t.manual.exchange_degassing_Urey(ismember(var_list.search_closed,'mantle_CO2'),1)   = -1;
t.manual.exchange_degassing_Urey(ismember(var_list.search_closed,'CaSiO3'),1)       = -1;
t.manual.exchange_degassing_Urey(ismember(var_list.search_closed,'CaCO3'),1)        = +1;
t.manual.exchange_degassing_Urey(ismember(var_list.search_closed,'SiO2 (solid)'),1) = +1;

UreyDegassing_01 = process.mantle_CO2.vector_closed*1;
UreyDegassing_07 = process.Ca_silicate_weathering.vector_closed*1; 
UreyDegassing_20 = process.silica_formation.vector_closed*1;
UreyDegassing_21 = process.calcite_formation.vector_closed*1;
b.manual.exchange_degassing_Urey = UreyDegassing_01+UreyDegassing_07+UreyDegassing_20+UreyDegassing_21; clear UreyDegassing*;

x.manual.exchange_degassing_Urey = zeros(38,1); 
x.manual.exchange_degassing_Urey(01) = 1;
x.manual.exchange_degassing_Urey(07) = 1;
x.manual.exchange_degassing_Urey(20) = 1;
x.manual.exchange_degassing_Urey(21) = 1;

if ~(isequal(t.manual.exchange_degassing_Urey,b.manual.exchange_degassing_Urey) & isequal(t.manual.exchange_degassing_Urey,Aclosed*x.manual.exchange_degassing_Urey))
    disp('problem with reaction exchange_degassing_Urey in the script "calculate_prior_reactions"'); end


%% exchange: halite formation
% 2HCl (mantle) + Na2SiO3 --> 2NaCl + SiO2 (solid) + H2O 
t.manual.exchange_halite_formation                                                    = zeros(33,1); 
t.manual.exchange_halite_formation(ismember(var_list.search_closed,'mantle_HCl'),1)   = -2;
t.manual.exchange_halite_formation(ismember(var_list.search_closed,'Na2SiO3'),1)      = -1;
t.manual.exchange_halite_formation(ismember(var_list.search_closed,'NaCl'),1)         = +2;
t.manual.exchange_halite_formation(ismember(var_list.search_closed,'SiO2 (solid)'),1) = +1;
t.manual.exchange_halite_formation(ismember(var_list.search_closed,'H2O'),1)          = +1;

HaliteForm_02 = process.mantle_HCl.vector_closed*2;
HaliteForm_09 = process.Na_silicate_weathering.vector_closed*1; 
HaliteForm_20 = process.silica_formation.vector_closed*1;
HaliteForm_35 = process.halite_formation.vector_closed*2;
b.manual.exchange_halite_formation = HaliteForm_02+HaliteForm_09+HaliteForm_20+HaliteForm_35; clear HaliteForm*;

x.manual.exchange_halite_formation = zeros(38,1); 
x.manual.exchange_halite_formation(02) = 2;
x.manual.exchange_halite_formation(09) = 1;
x.manual.exchange_halite_formation(20) = 1;
x.manual.exchange_halite_formation(35) = 2;

if ~(isequal(t.manual.exchange_halite_formation,b.manual.exchange_halite_formation) & isequal(t.manual.exchange_halite_formation,Aclosed*x.manual.exchange_halite_formation))
    disp('problem with reaction exchange_halite_formation in the script "calculate_prior_reactions"'); end


%% exchange: pyrite formation
% 2H2S (mantle) + Fe2O3 + SiO2 (solid) --> FeS2 + FeSiO3 + 2H2O 
t.manual.exchange_pyrite_mantle                                                    = zeros(33,1); 
t.manual.exchange_pyrite_mantle(ismember(var_list.search_closed,'mantle_H2S'),1)   = -2;
t.manual.exchange_pyrite_mantle(ismember(var_list.search_closed,'Fe2O3'),1)        = -1;
t.manual.exchange_pyrite_mantle(ismember(var_list.search_closed,'SiO2 (solid)'),1) = -1;
t.manual.exchange_pyrite_mantle(ismember(var_list.search_closed,'FeS2'),1)         = +1;
t.manual.exchange_pyrite_mantle(ismember(var_list.search_closed,'FeSiO3'),1)       = +1;
t.manual.exchange_pyrite_mantle(ismember(var_list.search_closed,'H2O'),1)          = +2;

pyrite_mantle_03 = process.mantle_H2S.vector_closed*2;
pyrite_mantle_15 = process.silica_weathering.vector_closed*1;
pyrite_mantle_19 = process.Fe_reverse_weathering.vector_closed*1; 
pyrite_mantle_31 = process.pyrite_formation.vector_closed*1;
b.manual.exchange_pyrite_mantle = pyrite_mantle_03+pyrite_mantle_15+pyrite_mantle_19+pyrite_mantle_31; clear pyrite_mantle*;

x.manual.exchange_pyrite_mantle = zeros(38,1); 
x.manual.exchange_pyrite_mantle(03) = 2;
x.manual.exchange_pyrite_mantle(15) = 1;
x.manual.exchange_pyrite_mantle(19) = 1;
x.manual.exchange_pyrite_mantle(31) = 1;

if ~(isequal(t.manual.exchange_pyrite_mantle,b.manual.exchange_pyrite_mantle) & isequal(t.manual.exchange_pyrite_mantle,Aclosed*x.manual.exchange_pyrite_mantle))
    disp('problem with reaction exchange_pyrite_mantle in the script "calculate_prior_reactions"'); end


%% exchange: carbonate and silicate, CaSiO3 and dolomite
% CaSiO3 + CaMg(CO3)2 --> 2CaCO3 + MgSiO3
t.manual.exchange_CaMg_sub                                                = zeros(33,1); 
t.manual.exchange_CaMg_sub(ismember(var_list.search_closed,'CaSiO3'),1)   = -1;
t.manual.exchange_CaMg_sub(ismember(var_list.search_closed,'CaMgCO32'),1) = -1;
t.manual.exchange_CaMg_sub(ismember(var_list.search_closed,'CaCO3'),1)    = +2;
t.manual.exchange_CaMg_sub(ismember(var_list.search_closed,'MgSiO3'),1)   = +1;

CaMg_sub_07 = process.Ca_silicate_weathering.vector_closed*1;
CaMg_sub_13 = process.dolomite_weathering.vector_closed*1; 
CaMg_sub_16 = process.Mg_reverse_weathering.vector_closed*1;
CaMg_sub_21 = process.calcite_formation.vector_closed*2;
b.manual.exchange_CaMg_sub = CaMg_sub_07+CaMg_sub_13+CaMg_sub_16+CaMg_sub_21; clear CaMg_sub*;

x.manual.exchange_CaMg_sub = zeros(38,1); 
x.manual.exchange_CaMg_sub(07) = 1;
x.manual.exchange_CaMg_sub(13) = 1;
x.manual.exchange_CaMg_sub(16) = 1;
x.manual.exchange_CaMg_sub(21) = 2;

if ~(isequal(t.manual.exchange_CaMg_sub,b.manual.exchange_CaMg_sub) & isequal(t.manual.exchange_CaMg_sub,Aclosed*x.manual.exchange_CaMg_sub))
    disp('problem with reaction exchange_CaMg_sub in the script "calculate_prior_reactions"'); end


%% exchange: carbonate and silicate, CaSiO3 and siderite
% CaSiO3 + FeCO3 --> CaCO3 + FeSiO3 
t.manual.exchange_CaFe_sub                                              = zeros(33,1); 
t.manual.exchange_CaFe_sub(ismember(var_list.search_closed,'CaSiO3'),1) = -1;
t.manual.exchange_CaFe_sub(ismember(var_list.search_closed,'FeCO3'),1)  = -1;
t.manual.exchange_CaFe_sub(ismember(var_list.search_closed,'CaCO3'),1)  = +1;
t.manual.exchange_CaFe_sub(ismember(var_list.search_closed,'FeSiO3'),1) = +1;

CaFe_sub_07 = process.Ca_silicate_weathering.vector_closed*1;
CaFe_sub_14 = process.siderite_weathering.vector_closed*1; 
CaFe_sub_19 = process.Fe_reverse_weathering.vector_closed*1;
CaFe_sub_21 = process.calcite_formation.vector_closed*1;
b.manual.exchange_CaFe_sub = CaFe_sub_07+CaFe_sub_14+CaFe_sub_19+CaFe_sub_21; clear CaFe_sub*;

x.manual.exchange_CaFe_sub = zeros(38,1); 
x.manual.exchange_CaFe_sub(07) = 1;
x.manual.exchange_CaFe_sub(14) = 1;
x.manual.exchange_CaFe_sub(19) = 1;
x.manual.exchange_CaFe_sub(21) = 1;

if ~(isequal(t.manual.exchange_CaFe_sub,b.manual.exchange_CaFe_sub) & isequal(t.manual.exchange_CaFe_sub,Aclosed*x.manual.exchange_CaFe_sub))
    disp('problem with reaction exchange_CaFe_sub in the script "calculate_prior_reactions"'); end


%% exchange: carbonate and silicate, Fe and dolomite
% FeSiO3 + CaMg(CO3)2 --> CaCO3 + FeCO3 + MgSiO3 
t.manual.exchange_FeCaMg_sub                                                = zeros(33,1); 
t.manual.exchange_FeCaMg_sub(ismember(var_list.search_closed,'FeSiO3'),1)   = -1;
t.manual.exchange_FeCaMg_sub(ismember(var_list.search_closed,'CaMgCO32'),1) = -1;
t.manual.exchange_FeCaMg_sub(ismember(var_list.search_closed,'CaCO3'),1)    = +1;
t.manual.exchange_FeCaMg_sub(ismember(var_list.search_closed,'FeCO3'),1)    = +1;
t.manual.exchange_FeCaMg_sub(ismember(var_list.search_closed,'MgSiO3'),1)   = +1;

FeCaMg_sub_11 = process.Fe_silicate_weathering.vector_closed*1;
FeCaMg_sub_13 = process.dolomite_weathering.vector_closed*1; 
FeCaMg_sub_16 = process.Mg_reverse_weathering.vector_closed*1;
FeCaMg_sub_21 = process.calcite_formation.vector_closed*1;
FeCaMg_sub_23 = process.siderite_formation.vector_closed*1;
b.manual.exchange_FeCaMg_sub = FeCaMg_sub_11+FeCaMg_sub_13+FeCaMg_sub_16+FeCaMg_sub_21+FeCaMg_sub_23; clear FeCaMg_sub*;
 
x.manual.exchange_FeCaMg_sub = zeros(38,1); 
x.manual.exchange_FeCaMg_sub(11) = 1;
x.manual.exchange_FeCaMg_sub(13) = 1;
x.manual.exchange_FeCaMg_sub(16) = 1;
x.manual.exchange_FeCaMg_sub(21) = 1;
x.manual.exchange_FeCaMg_sub(23) = 1;

if ~(isequal(t.manual.exchange_FeCaMg_sub,b.manual.exchange_FeCaMg_sub) & isequal(t.manual.exchange_FeCaMg_sub,Aclosed*x.manual.exchange_FeCaMg_sub))
    disp('problem with reaction exchange_FeCaMg_sub in the script "calculate_prior_reactions"'); end


%% exchange: carbon/sulfur coupling, after Garrels and Lerman (1981, 1984)
% 4FeS2 +  CaCO3 + 7CaMg(CO3)2 + 7SiO2 (solid) + 31H2O --> 15CH2O + 2Fe2O3 + 7MgSiO3 + 8(CaSO4*2H2O) 
t.manual.exchange_couple_CS                                                    = zeros(33,1); 
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'FeS2'),1)         = -4;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'CaCO3'),1)        = -1;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'CaMgCO32'),1)     = -7;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'SiO2 (solid)'),1) = -7;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'H2O'),1)          = -31;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'CH2O'),1)         = +15;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'Fe2O3'),1)        = +2;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'MgSiO3'),1)       = +7;
t.manual.exchange_couple_CS(ismember(var_list.search_closed,'CaSO4_2H2O'),1)   = +8;

CS_12 = process.calcite_weathering.vector_closed*1;      
CS_13 = process.dolomite_weathering.vector_closed*7;     
CS_15 = process.silica_weathering.vector_closed*7;       
CS_16 = process.Mg_reverse_weathering.vector_closed*7;   
CS_24 = process.oxygenic_photosynthesis.vector_closed*15;
CS_30 = process.pyrite_oxidation.vector_closed*1;        
CS_33 = process.gypsum_formation.vector_closed*8;
b.manual.exchange_couple_CS = CS_12+CS_13+CS_15+CS_16+CS_24+CS_30+CS_33; clear CS*;

x.manual.exchange_couple_CS     = zeros(38,1); 
x.manual.exchange_couple_CS(12) =  1;
x.manual.exchange_couple_CS(13) =  7;
x.manual.exchange_couple_CS(15) =  7;
x.manual.exchange_couple_CS(16) =  7;
x.manual.exchange_couple_CS(24) =  15;
x.manual.exchange_couple_CS(30) =  1;
x.manual.exchange_couple_CS(33) =  8;

if ~(isequal(t.manual.exchange_couple_CS,b.manual.exchange_couple_CS) & isequal(t.manual.exchange_couple_CS,Aclosed*x.manual.exchange_couple_CS))
    disp('problem with reaction exchange_couple_CS in the script "calculate_prior_reactions"'); end


%% exchange: carbon/sulfur coupling in reverse (after Garrels and Lerman (1984))
% 15CH2O + 2Fe2O3 + 7MgSiO3 + 8(CaSO4*2H2O) --> 4FeS2 + CaCO3 + 7CaMg(CO3)2 + 7SiO2 (solid) + 31H2O
t.manual.exchange_couple_CS_reverse                                                    = zeros(33,1); 
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'CH2O'),1)         = -15;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'Fe2O3'),1)        = -2;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'MgSiO3'),1)       = -7;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'CaSO4_2H2O'),1)   = -8;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'FeS2'),1)         = +4;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'CaCO3'),1)        = +1;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'CaMgCO32'),1)     = +7;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'SiO2 (solid)'),1) = +7;
t.manual.exchange_couple_CS_reverse(ismember(var_list.search_closed,'H2O'),1)          = +31;

CS_r_08 = process.Mg_silicate_weathering.vector_closed*7;
CS_r_20 = process.silica_formation.vector_closed*7;
CS_r_21 = process.calcite_formation.vector_closed*1;
CS_r_22 = process.dolomite_formation.vector_closed*7;
CS_r_24 = process.oxygenic_photosynthesis.vector_closed*1;
CS_r_27 = process.sulfate_reduction.vector_closed*8;
CS_r_28 = process.ferrous_iron_oxidation.vector_closed*1;
CS_r_31 = process.pyrite_formation.vector_closed*4;
CS_r_32 = process.gypsum_dissolution.vector_closed*8;
b.manual.exchange_couple_CS_reverse = CS_r_08+CS_r_20+CS_r_21+CS_r_22+CS_r_24+CS_r_27+CS_r_28+CS_r_31+CS_r_32; clear CS_r*;

x.manual.exchange_couple_CS_reverse     = zeros(38,1); 
x.manual.exchange_couple_CS_reverse(08) = 7;
x.manual.exchange_couple_CS_reverse(20) = 7;
x.manual.exchange_couple_CS_reverse(21) = 1;
x.manual.exchange_couple_CS_reverse(22) = 7;
x.manual.exchange_couple_CS_reverse(24) = 1;
x.manual.exchange_couple_CS_reverse(27) = 8;
x.manual.exchange_couple_CS_reverse(28) = 1;
x.manual.exchange_couple_CS_reverse(31) = 4;
x.manual.exchange_couple_CS_reverse(32) = 8;

if ~(isequal(t.manual.exchange_couple_CS_reverse,b.manual.exchange_couple_CS_reverse) & isequal(t.manual.exchange_couple_CS_reverse,Aclosed*x.manual.exchange_couple_CS_reverse))
    disp('problem with reaction exchange_couple_CS_reverse in the script "calculate_prior_reactions"'); end


%% exchange: carbon/iron coupling 1
% 3FeSiO3 + FeCO3 + H2O --> CH2O + 2Fe2O3 + 3SiO2 (solid) 
t.manual.exchange_couple_CFe                                                    = zeros(33,1); 
t.manual.exchange_couple_CFe(ismember(var_list.search_closed,'FeSiO3'),1)       = -3;
t.manual.exchange_couple_CFe(ismember(var_list.search_closed,'FeCO3'),1)        = -1;
t.manual.exchange_couple_CFe(ismember(var_list.search_closed,'H2O'),1)          = -1;
t.manual.exchange_couple_CFe(ismember(var_list.search_closed,'CH2O'),1)         = +1;
t.manual.exchange_couple_CFe(ismember(var_list.search_closed,'Fe2O3'),1)        = +2;
t.manual.exchange_couple_CFe(ismember(var_list.search_closed,'SiO2 (solid)'),1) = +3;

CFe_11 = process.Fe_silicate_weathering.vector_closed*3;
CFe_14 = process.siderite_weathering.vector_closed*1;
CFe_20 = process.silica_formation.vector_closed*3;
CFe_24 = process.oxygenic_photosynthesis.vector_closed*1;
CFe_28 = process.ferrous_iron_oxidation.vector_closed*1;
b.manual.exchange_couple_CFe = CFe_11+CFe_14+CFe_20+CFe_24+CFe_28; clear CFe*;

x.manual.exchange_couple_CFe = zeros(38,1); 
x.manual.exchange_couple_CFe(11) = 3;
x.manual.exchange_couple_CFe(14) = 1;
x.manual.exchange_couple_CFe(20) = 3;
x.manual.exchange_couple_CFe(24) = 1;
x.manual.exchange_couple_CFe(28) = 1;

if ~(isequal(t.manual.exchange_couple_CFe,b.manual.exchange_couple_CFe) & isequal(t.manual.exchange_couple_CFe,Aclosed*x.manual.exchange_couple_CFe))
    disp('problem with reaction exchange_couple_CFe in the script "calculate_prior_reactions"'); end


%% exchange: carbon/iron coupling reverse
% CH2O + 2Fe2O3 + 3SiO2 (solid)  --> 3FeSiO3 + FeCO3 + H2O
t.manual.exchange_couple_CFe_reverse                                                    = zeros(33,1); 
t.manual.exchange_couple_CFe_reverse(ismember(var_list.search_closed,'CH2O'),1)         = -1;
t.manual.exchange_couple_CFe_reverse(ismember(var_list.search_closed,'Fe2O3'),1)        = -2;
t.manual.exchange_couple_CFe_reverse(ismember(var_list.search_closed,'SiO2 (solid)'),1) = -3;
t.manual.exchange_couple_CFe_reverse(ismember(var_list.search_closed,'FeSiO3'),1)       = +3;
t.manual.exchange_couple_CFe_reverse(ismember(var_list.search_closed,'FeCO3'),1)        = +1;
t.manual.exchange_couple_CFe_reverse(ismember(var_list.search_closed,'H2O'),1)          = +1;

CFe_1_r_15 = process.silica_weathering.vector_closed*3;
CFe_1_r_19 = process.Fe_reverse_weathering.vector_closed*3;
CFe_1_r_23 = process.siderite_formation.vector_closed*1;
CFe_1_r_29 = process.ferric_iron_reduction.vector_closed*1;
b.manual.exchange_couple_CFe_reverse = CFe_1_r_15+CFe_1_r_19+CFe_1_r_23+CFe_1_r_29; clear CFe_1_r*;

x.manual.exchange_couple_CFe_reverse = zeros(38,1); 
x.manual.exchange_couple_CFe_reverse(15) = 3;
x.manual.exchange_couple_CFe_reverse(19) = 3;
x.manual.exchange_couple_CFe_reverse(23) = 1;
x.manual.exchange_couple_CFe_reverse(29) = 1;

if ~(isequal(t.manual.exchange_couple_CFe_reverse,b.manual.exchange_couple_CFe_reverse) & isequal(t.manual.exchange_couple_CFe_reverse,Aclosed*x.manual.exchange_couple_CFe_reverse))
    disp('problem with reaction exchange_couple_CFe_reverse in the script "calculate_prior_reactions"'); end


%% exchange: carbon/iron coupling 2: Garrels and Perry eq. 2
% CaMg(CO3)2 + 4FeSiO3 + H2O --> CaCO3 + MgSiO3 + 3SiO2 (solid) + 2Fe2O3 + CH2O
t.manual.exchange_couple_CFe2                                                    = zeros(33,1); 
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'CaMgCO32'),1)     = -1;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'FeSiO3'),1)       = -4;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'H2O'),1)          = -1;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'CaCO3'),1)        = +1;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'MgSiO3'),1)       = +1;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'SiO2 (solid)'),1) = +3;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'Fe2O3'),1)        = +2;
t.manual.exchange_couple_CFe2(ismember(var_list.search_closed,'CH2O'),1)         = +1;

CFe2_11 = process.Fe_silicate_weathering.vector_closed*4;
CFe2_13 = process.dolomite_weathering.vector_closed*1;
CFe2_16 = process.Mg_reverse_weathering.vector_closed*1;
CFe2_20 = process.silica_formation.vector_closed*3;
CFe2_21 = process.calcite_formation.vector_closed*1;
CFe2_24 = process.oxygenic_photosynthesis.vector_closed*1;
CFe2_28 = process.ferrous_iron_oxidation.vector_closed*1;
b.manual.exchange_couple_CFe2 = CFe2_11+CFe2_13+CFe2_16+CFe2_20+CFe2_21+CFe2_24+CFe2_28; clear CFe2*;

x.manual.exchange_couple_CFe2 = zeros(38,1); 
x.manual.exchange_couple_CFe2(11) = 4;
x.manual.exchange_couple_CFe2(13) = 1;
x.manual.exchange_couple_CFe2(16) = 1;
x.manual.exchange_couple_CFe2(20) = 3;
x.manual.exchange_couple_CFe2(21) = 1;
x.manual.exchange_couple_CFe2(24) = 1;
x.manual.exchange_couple_CFe2(28) = 1;

if ~(isequal(t.manual.exchange_couple_CFe2,b.manual.exchange_couple_CFe2) & isequal(t.manual.exchange_couple_CFe2,Aclosed*x.manual.exchange_couple_CFe2))
    disp('problem with reaction exchange_couple_CFe2 in the script "calculate_prior_reactions"'); end


%% exchange: sulfur/iron coupling
% 13SiO2 (solid) + 7Fe2O3 + FeS2 + 2CaSiO3 + 4H2O --> 15FeSiO3 + 2(CaSO4x2H2O)
t.manual.exchange_couple_SFe                                                    = zeros(33,1); 
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'SiO2 (solid)'),1) = -13;
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'Fe2O3'),1)        = -7;
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'FeS2'),1)         = -1;
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'CaSiO3'),1)       = -2;
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'H2O'),1)          = -4;
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'FeSiO3'),1)       = +15;
t.manual.exchange_couple_SFe(ismember(var_list.search_closed,'CaSO4_2H2O'),1)   = +2;

SFe_07 = process.Ca_silicate_weathering.vector_closed*2;
SFe_15 = process.silica_weathering.vector_closed*13;
SFe_19 = process.Fe_reverse_weathering.vector_closed*15;
SFe_24 = process.oxygenic_photosynthesis.vector_closed*3.75;
SFe_29 = process.ferric_iron_reduction.vector_closed*3.75;
SFe_30 = process.pyrite_oxidation.vector_closed*0.25;
SFe_33 = process.gypsum_formation.vector_closed*2;
b.manual.exchange_couple_SFe = SFe_07+SFe_15+SFe_19+SFe_24+SFe_29+SFe_30+SFe_33;  clear SFe*;

x.manual.exchange_couple_SFe = zeros(38,1); 
x.manual.exchange_couple_SFe(07) = 2;
x.manual.exchange_couple_SFe(15) = 13;
x.manual.exchange_couple_SFe(19) = 15;
x.manual.exchange_couple_SFe(24) = 3.75;
x.manual.exchange_couple_SFe(29) = 3.75;
x.manual.exchange_couple_SFe(30) = 0.25;
x.manual.exchange_couple_SFe(33) = 2;

if ~(isequal(t.manual.exchange_couple_SFe,b.manual.exchange_couple_SFe) & isequal(t.manual.exchange_couple_SFe,Aclosed*x.manual.exchange_couple_SFe))
    disp('problem with reaction exchange_couple_SFe in the script "calculate_prior_reactions"'); end


%% open: Bachan and Kump (2015) 
% 4FeCO3 + 4H2O --> 2Fe2O3 + 4CH2O + 3O2
t.manual.open_BK15_FeCO3_Fe2O3                                              = zeros(33,1); 
t.manual.open_BK15_FeCO3_Fe2O3(ismember(var_list.search_closed,'FeCO3'),1)  = -4;
t.manual.open_BK15_FeCO3_Fe2O3(ismember(var_list.search_closed,'H2O'),1)    = -4;
t.manual.open_BK15_FeCO3_Fe2O3(ismember(var_list.search_closed,'Fe2O3'),1)  = +2;
t.manual.open_BK15_FeCO3_Fe2O3(ismember(var_list.search_closed,'CH2O'),1)   = +4;
t.manual.open_BK15_FeCO3_Fe2O3(ismember(var_list.search_closed,'O2'),1)     = +3;

BK15_14 = process.siderite_weathering.vector_closed*4;    
BK15_24 = process.oxygenic_photosynthesis.vector_closed*4;
BK15_28 = process.ferrous_iron_oxidation.vector_closed*1; 
b.manual.open_BK15_FeCO3_Fe2O3 = BK15_14+BK15_24+BK15_28; clear BK15*;

x.manual.open_BK15_FeCO3_Fe2O3 = zeros(38,1); 
x.manual.open_BK15_FeCO3_Fe2O3(14) =  4;
x.manual.open_BK15_FeCO3_Fe2O3(24) =  4;
x.manual.open_BK15_FeCO3_Fe2O3(28) =  1;

if ~(isequal(t.manual.open_BK15_FeCO3_Fe2O3,b.manual.open_BK15_FeCO3_Fe2O3) & isequal(t.manual.open_BK15_FeCO3_Fe2O3,Aclosed*x.manual.open_BK15_FeCO3_Fe2O3))
    disp('problem with reaction open_BK15_FeCO3_Fe2O3 in the script "calculate_prior_reactions"'); end


%% open: O2 from siderite, with FeSiO3
% FeCO3 + H2O + SiO2 (aq) --> O2 + CH2O + FeSiO3
t.manual.open_BK15_FeCO3_FeSiO3                                                   = zeros(33,1); 
t.manual.open_BK15_FeCO3_FeSiO3(ismember(var_list.search_closed,'FeCO3'),1)       = -1;
t.manual.open_BK15_FeCO3_FeSiO3(ismember(var_list.search_closed,'H2O'),1)         = -1;
t.manual.open_BK15_FeCO3_FeSiO3(ismember(var_list.search_closed,'SiO2 (aq)'),1)   = -1;
t.manual.open_BK15_FeCO3_FeSiO3(ismember(var_list.search_closed,'O2'),1)          = +1;
t.manual.open_BK15_FeCO3_FeSiO3(ismember(var_list.search_closed,'CH2O'),1)        = +1;
t.manual.open_BK15_FeCO3_FeSiO3(ismember(var_list.search_closed,'FeSiO3'),1)      = +1;

BK15alt1_14 = process.siderite_weathering.vector_closed*1;
BK15alt1_19 = process.Fe_reverse_weathering.vector_closed*1;
BK15alt1_24 = process.oxygenic_photosynthesis.vector_closed*1;
b.manual.open_BK15_FeCO3_FeSiO3 = BK15alt1_14+BK15alt1_19+BK15alt1_24; clear BK15alt1*;

x.manual.open_BK15_FeCO3_FeSiO3 = zeros(38,1); 
x.manual.open_BK15_FeCO3_FeSiO3(14) =  1;
x.manual.open_BK15_FeCO3_FeSiO3(19) =  1;
x.manual.open_BK15_FeCO3_FeSiO3(24) =  1;

if ~(isequal(t.manual.open_BK15_FeCO3_FeSiO3,b.manual.open_BK15_FeCO3_FeSiO3) & isequal(t.manual.open_BK15_FeCO3_FeSiO3,Aclosed*x.manual.open_BK15_FeCO3_FeSiO3))
    disp('problem with reaction open_BK15_FeCO3_FeSiO3 in the script "calculate_prior_reactions"'); end


%% open: O2 from dolomite, with MgSiO3
% CaMg(CO3)2 + H2O + SiO2 (aq) --> O2 + CH2O + CaCO3 + MgSiO3 
t.manual.open_BK15_CaMgCO3_MgSiO3                                                 = zeros(33,1); 
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'CaMgCO32'),1)  = -1;
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'H2O'),1)       = -1;
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'SiO2 (aq)'),1) = -1;
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'O2'),1)        = +1;
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'CH2O'),1)      = +1;
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'CaCO3'),1)     = +1;
t.manual.open_BK15_CaMgCO3_MgSiO3(ismember(var_list.search_closed,'MgSiO3'),1)    = +1;

BK15alt2_13 = process.dolomite_weathering.vector_closed*1;     
BK15alt2_16 = process.Mg_reverse_weathering.vector_closed*1;   
BK15alt2_21 = process.calcite_formation.vector_closed*1;        
BK15alt2_24 = process.oxygenic_photosynthesis.vector_closed*1; 
b.manual.open_BK15_CaMgCO3_MgSiO3 = BK15alt2_13+BK15alt2_16+BK15alt2_21+BK15alt2_24; clear BK15alt2*;

x.manual.open_BK15_CaMgCO3_MgSiO3 = zeros(38,1); 
x.manual.open_BK15_CaMgCO3_MgSiO3(13) =  1;
x.manual.open_BK15_CaMgCO3_MgSiO3(16) =  1;
x.manual.open_BK15_CaMgCO3_MgSiO3(21) =  1;
x.manual.open_BK15_CaMgCO3_MgSiO3(24) =  1;

if ~(isequal(t.manual.open_BK15_CaMgCO3_MgSiO3,b.manual.open_BK15_CaMgCO3_MgSiO3) & isequal(t.manual.open_BK15_CaMgCO3_MgSiO3,Aclosed*x.manual.open_BK15_CaMgCO3_MgSiO3))
    disp('problem with reaction open_BK15_CaMgCO3_MgSiO3 in the script "calculate_prior_reactions"'); end


%% open: sulfide oxidation and silicate weathering
% 15O2 + 4FeS2 + 8CaSiO3 --> 8Ca2+ + 8SO42- + 2Fe2O3 + 8SiO2 (aq)
t.manual.open_sulfox                                                 = zeros(33,1); 
t.manual.open_sulfox(ismember(var_list.search_closed,'O2'),1)        = -15;
t.manual.open_sulfox(ismember(var_list.search_closed,'FeS2'),1)      = -4;
t.manual.open_sulfox(ismember(var_list.search_closed,'CaSiO3'),1)    = -8;
t.manual.open_sulfox(ismember(var_list.search_closed,'Ca'),1)        = +8;
t.manual.open_sulfox(ismember(var_list.search_closed,'SO4'),1)       = +8;
t.manual.open_sulfox(ismember(var_list.search_closed,'Fe2O3'),1)     = +2;
t.manual.open_sulfox(ismember(var_list.search_closed,'SiO2 (aq)'),1) = +8;

sulfox_7  = process.Ca_silicate_weathering.vector_closed*8;
sulfox_30 = process.pyrite_oxidation.vector_closed*1;
b.manual.open_sulfox = sulfox_7+sulfox_30; clear sulfox*;

x.manual.open_sulfox = zeros(38,1); 
x.manual.open_sulfox(7)  =  8;
x.manual.open_sulfox(30) =  1;

if ~(isequal(t.manual.open_sulfox,b.manual.open_sulfox) & isequal(t.manual.open_sulfox,Aclosed*x.manual.open_sulfox))
    disp('problem with reaction open_sulfox in the script "calculate_prior_reactions"'); end


%% open: carbonate cation switching
% CaMg(CO3)2 + Ca2+ --> 2CaCO3 + Mg2+ 
t.manual.open_catswitch                                                = zeros(33,1); 
t.manual.open_catswitch(ismember(var_list.search_closed,'CaMgCO32'),1) = -1;
t.manual.open_catswitch(ismember(var_list.search_closed,'Ca'),1)       = -1;
t.manual.open_catswitch(ismember(var_list.search_closed,'CaCO3'),1)    = +2;
t.manual.open_catswitch(ismember(var_list.search_closed,'Mg'),1)       = +1;

revweath_13 = process.dolomite_weathering.vector_closed*1;     
revweath_21 = process.calcite_formation.vector_closed*2;       
b.manual.open_catswitch = revweath_13+revweath_21; clear revweath*;

x.manual.open_catswitch = zeros(38,1); 
x.manual.open_catswitch(13) =  1;
x.manual.open_catswitch(21) =  2;

if ~(isequal(t.manual.open_catswitch,b.manual.open_catswitch) & isequal(t.manual.open_catswitch,Aclosed*x.manual.open_catswitch))
    disp('problem with reaction open_catswitch in the script "calculate_prior_reactions"'); end


%% open: mantle H2S
% H2S (mantle) --> H2S
t.manual.open_mantle_H2S                                                  = zeros(33,1); 
t.manual.open_mantle_H2S(ismember(var_list.search_closed,'mantle_H2S'),1) = -1;
t.manual.open_mantle_H2S(ismember(var_list.search_closed,'H2S'),1)        = +1;

mantleH2S_3 = process.mantle_H2S.vector_closed*1;       
b.manual.open_mantle_H2S = mantleH2S_3; clear mantleH2S*;

x.manual.open_mantle_H2S     = zeros(38,1); 
x.manual.open_mantle_H2S(3)  = 1;

if ~(isequal(t.manual.open_mantle_H2S,b.manual.open_mantle_H2S) & isequal(t.manual.open_mantle_H2S,Aclosed*x.manual.open_mantle_H2S))
    disp('problem with reaction open_mantle_H2S in the script "calculate_prior_reactions"'); end


%% open: Ca-silicate
% 2HCl (mantle) + CaSiO3 --> Ca2+ + SiO2 (aq) + 2Cl- + H2O
t.manual.open_Ca_silicate                                                  = zeros(33,1); 
t.manual.open_Ca_silicate(ismember(var_list.search_closed,'mantle_HCl'),1) = -2;
t.manual.open_Ca_silicate(ismember(var_list.search_closed,'CaSiO3'),1)     = -1;
t.manual.open_Ca_silicate(ismember(var_list.search_closed,'Ca'),1)         = +1;
t.manual.open_Ca_silicate(ismember(var_list.search_closed,'SiO2 (aq)'),1)  = +1;
t.manual.open_Ca_silicate(ismember(var_list.search_closed,'Cl'),1)         = +2;
t.manual.open_Ca_silicate(ismember(var_list.search_closed,'H2O'),1)        = +1;

openCasilicate_2 = process.mantle_HCl.vector_closed*2;       
openCasilicate_7 = process.Ca_silicate_weathering.vector_closed*1;       
b.manual.open_Ca_silicate = openCasilicate_2 + openCasilicate_7; clear openCasilicate_*;

x.manual.open_Ca_silicate        = zeros(38,1); 
x.manual.open_Ca_silicate(2)     = 2;
x.manual.open_Ca_silicate(7)     = 1;

if ~(isequal(t.manual.open_Ca_silicate,b.manual.open_Ca_silicate) & isequal(t.manual.open_Ca_silicate,Aclosed*x.manual.open_Ca_silicate))
    disp('problem with reaction open_Ca_silicate in the script "calculate_prior_reactions"'); end


%% open: Na-silicate
% 2HCl (mantle) + Na2SiO3 --> 2Na+ + SiO2 (aq) + 2Cl- + H2O
t.manual.open_Na_silicate                                                  = zeros(33,1); 
t.manual.open_Na_silicate(ismember(var_list.search_closed,'mantle_HCl'),1) = -2;
t.manual.open_Na_silicate(ismember(var_list.search_closed,'Na2SiO3'),1)    = -1;
t.manual.open_Na_silicate(ismember(var_list.search_closed,'Na'),1)         = +2;
t.manual.open_Na_silicate(ismember(var_list.search_closed,'SiO2 (aq)'),1)  = +1;
t.manual.open_Na_silicate(ismember(var_list.search_closed,'Cl'),1)         = +2;
t.manual.open_Na_silicate(ismember(var_list.search_closed,'H2O'),1)        = +1;

openNasilicate_2 = process.mantle_HCl.vector_closed*2;       
openNasilicate_9 = process.Na_silicate_weathering.vector_closed*1;       
b.manual.open_Na_silicate = openNasilicate_2 + openNasilicate_9; clear openNasilicate_*;

x.manual.open_Na_silicate        = zeros(38,1); 
x.manual.open_Na_silicate(2)     = 2;
x.manual.open_Na_silicate(9)     = 1;

if ~(isequal(t.manual.open_Na_silicate,b.manual.open_Na_silicate) & isequal(t.manual.open_Na_silicate,Aclosed*x.manual.open_Na_silicate))
    disp('problem with reaction open_Na_silicate in the script "calculate_prior_reactions"'); end


%% open: K-silicate
% 2HCl (mantle) + K2SiO3 --> 2K+ + SiO2 (aq) + 2Cl- + H2O
t.manual.open_K_silicate                                                  = zeros(33,1); 
t.manual.open_K_silicate(ismember(var_list.search_closed,'mantle_HCl'),1) = -2;
t.manual.open_K_silicate(ismember(var_list.search_closed,'K2SiO3'),1)     = -1;
t.manual.open_K_silicate(ismember(var_list.search_closed,'K'),1)          = +2;
t.manual.open_K_silicate(ismember(var_list.search_closed,'SiO2 (aq)'),1)  = +1;
t.manual.open_K_silicate(ismember(var_list.search_closed,'Cl'),1)         = +2;
t.manual.open_K_silicate(ismember(var_list.search_closed,'H2O'),1)        = +1;

openKsilicate_2 = process.mantle_HCl.vector_closed*2;       
openKsilicate_10 = process.K_silicate_weathering.vector_closed*1;       
b.manual.open_K_silicate = openKsilicate_2 + openKsilicate_10; clear openKsilicate_*;

x.manual.open_K_silicate         = zeros(38,1); 
x.manual.open_K_silicate(2)      = 2;
x.manual.open_K_silicate(10)     = 1;

if ~(isequal(t.manual.open_K_silicate,b.manual.open_K_silicate) & isequal(t.manual.open_K_silicate,Aclosed*x.manual.open_K_silicate))
    disp('problem with reaction open_K_silicate in the script "calculate_prior_reactions"'); end


%% open: Fe-silicate
% 2HCl (mantle) + FeSiO3 --> Fe2+ + SiO2 (aq) + 2Cl- + H2O
t.manual.open_Fe_silicate                                                  = zeros(33,1); 
t.manual.open_Fe_silicate(ismember(var_list.search_closed,'mantle_HCl'),1) = -2;
t.manual.open_Fe_silicate(ismember(var_list.search_closed,'FeSiO3'),1)     = -1;
t.manual.open_Fe_silicate(ismember(var_list.search_closed,'Fe2'),1)        = +1;
t.manual.open_Fe_silicate(ismember(var_list.search_closed,'SiO2 (aq)'),1)  = +1;
t.manual.open_Fe_silicate(ismember(var_list.search_closed,'Cl'),1)         = +2;
t.manual.open_Fe_silicate(ismember(var_list.search_closed,'H2O'),1)        = +1;

openFesilicate_2  = process.mantle_HCl.vector_closed*2;       
openFesilicate_11 = process.Fe_silicate_weathering.vector_closed*1;       
b.manual.open_Fe_silicate = openFesilicate_2 + openFesilicate_11; clear openFesilicate_*;

x.manual.open_Fe_silicate      = zeros(38,1); 
x.manual.open_Fe_silicate(2)   = 2;
x.manual.open_Fe_silicate(11)  = 1;

if ~(isequal(t.manual.open_Fe_silicate,b.manual.open_Fe_silicate) & isequal(t.manual.open_Fe_silicate,Aclosed*x.manual.open_Fe_silicate))
    disp('problem with reaction open_Fe_silicate in the script "calculate_prior_reactions"'); end


%% open: Si weathering
% SiO2 (solid) --> SiO2 (aq)
t.manual.open_Si_weathering                                                    = zeros(33,1); 
t.manual.open_Si_weathering(ismember(var_list.search_closed,'SiO2 (solid)'),1) = -1;
t.manual.open_Si_weathering(ismember(var_list.search_closed,'SiO2 (aq)'),1)    = +1;

Siweath_15 = process.silica_weathering.vector_closed*1;       
b.manual.open_Si_weathering = Siweath_15; clear Siweath*;

x.manual.open_Si_weathering      = zeros(38,1); 
x.manual.open_Si_weathering(15)  = 1;

if ~(isequal(t.manual.open_Si_weathering,b.manual.open_Si_weathering) & isequal(t.manual.open_Si_weathering,Aclosed*x.manual.open_Si_weathering))
    disp('problem with reaction open_Si_weathering in the script "calculate_prior_reactions"'); end


%% open: N2 fixation
% 4HCl (mantle) + 6H2O + 2N2 --> 4NH4+ + 4Cl- + 3O2
t.manual.open_N2_fixation                                                    = zeros(33,1); 
t.manual.open_N2_fixation(ismember(var_list.search_closed,'mantle_HCl'),1)   = -4;
t.manual.open_N2_fixation(ismember(var_list.search_closed,'H2O'),1)          = -6;
t.manual.open_N2_fixation(ismember(var_list.search_closed,'N2'),1)           = -2;
t.manual.open_N2_fixation(ismember(var_list.search_closed,'NH4'),1)          = +4;
t.manual.open_N2_fixation(ismember(var_list.search_closed,'Cl'),1)           = +4;
t.manual.open_N2_fixation(ismember(var_list.search_closed,'O2'),1)           = +3;

N2Fix_2  = process.mantle_HCl.vector_closed*4;       
N2Fix_36 = process.dinitrogen_fixation.vector_closed*1;       
b.manual.open_N2_fixation = N2Fix_2+N2Fix_36; clear N2Fix*;

x.manual.open_N2_fixation        = zeros(38,1); 
x.manual.open_N2_fixation(2)     = 4;
x.manual.open_N2_fixation(36)    = 1;

if ~(isequal(t.manual.open_N2_fixation,b.manual.open_N2_fixation) & isequal(t.manual.open_N2_fixation,Aclosed*x.manual.open_N2_fixation))
    disp('problem with reaction open_N2_fixation in the script "calculate_prior_reactions"'); end


%% open: nitrification
% 4H2O + 2N2 + O2 --> 2NH4 + 2NO3
t.manual.open_nitrification                                            = zeros(33,1); 
t.manual.open_nitrification(ismember(var_list.search_closed,'H2O'),1)  = -4;
t.manual.open_nitrification(ismember(var_list.search_closed,'N2'),1)   = -2;
t.manual.open_nitrification(ismember(var_list.search_closed,'O2'),1)   = -1;
t.manual.open_nitrification(ismember(var_list.search_closed,'NH4'),1)  = +2;
t.manual.open_nitrification(ismember(var_list.search_closed,'NO3'),1)  = +2;

Nitrif_36 = process.dinitrogen_fixation.vector_closed*1;
Nitrif_37 = process.nitrification.vector_closed*2;
b.manual.open_nitrification = Nitrif_36+Nitrif_37; clear Nitrif*;

x.manual.open_nitrification      = zeros(38,1); 
x.manual.open_nitrification(36)  = 1;
x.manual.open_nitrification(37)  = 2;

if ~(isequal(t.manual.open_nitrification,b.manual.open_nitrification) & isequal(t.manual.open_nitrification,Aclosed*x.manual.open_nitrification))
    disp('problem with reaction open_nitrification in the script "calculate_prior_reactions"'); end

